# Night Overtake 3D

Browser racing game built with React 19, Vite, Three.js and Zustand. The 3D simulation and four vehicle models come from the supplied **Ночной обгон 3D.zip**. The original archive remains untouched in the project folder.

Requires Node.js 20.19+ or 22.12+.

## Run

```bash
npm install
npm run dev
```

Open the address shown by Vite, normally [http://localhost:5173](http://localhost:5173).

```bash
npm run build
npm run preview
```

The production files are in `dist/`. They can also be served with:

```bash
cd dist
python -m http.server 8000
```

Open [http://localhost:8000](http://localhost:8000). Loading the HTML directly from `file://` will not load the models reliably.

## Controls

| Action | Desktop | Touch |
| --- | --- | --- |
| Steer | A/D or ←/→ | Wheel, buttons or device tilt |
| Accelerate | W or ↑ | Gas |
| Brake and handbrake | S, ↓ or Space | Brake or handbrake |
| Nitro | Shift | Nitro |
| Pause | Escape | Pause button |
| Camera | Camera button | Camera button |

The car has an arcade pace even without holding the accelerator; holding it gives full throttle. Tilt controls ask for sensor permission where the browser requires it.

## Modes

- **Classic:** endless traffic overtaking, near miss rewards, combo and nitro; a collision ends the run.
- **Extreme:** denser traffic, faster oncoming cars and lane changes. Overtakes pay double. Vehicle counts are capped according to device quality to protect frame rate.
- **Drift:** 90 second session. Points require speed and actual slip angle, and a collision cancels the current slide.
- **Chase:** 180 second pursuit with two AI targets. Stay close or make contact to catch them. Higher levels unlock after wins.
- **Test Drive:** 60 second temporary use of any garage car. It gives no permanent ownership or currency.

The garage supports purchase, selection, paint, finish, lamp color and intensity, underglow, rim color, orbit and zoom. Purchases and customization persist. Settings include control type, steering sensitivity, measured auto quality, resolution, pixel ratio limit, particles, draw distance, traffic density, lighting, shadows, antialiasing, FPS cap, track, audio mix and font choice. Antialiasing changes restart the game because the WebGL context must be recreated.

## LAN multiplayer

The LAN server serves the production frontend and WebSocket endpoint from the same port. Build once, then run the server on the host PC:

```powershell
npm install
npm run build
npm run server
```

The server listens on all network interfaces at port `3000` and prints its LAN addresses at startup. On another PC or an Android phone connected to the same Wi-Fi, open `http://<host-LAN-IP>:3000` in a browser. For example, if the server prints `192.168.1.5`, open `http://192.168.1.5:3000`. Do not use `localhost` on the other device; that would point to that device itself. Android works best in landscape orientation.

If Windows Firewall prompts when Node.js starts, allow access on **Private networks**. If the prompt was dismissed, create an inbound TCP rule for port 3000 from an elevated PowerShell window:

```powershell
New-NetFirewallRule -DisplayName "Night Overtake LAN" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3000 -Profile Private
```

Remove that rule when it is no longer needed:

```powershell
Remove-NetFirewallRule -DisplayName "Night Overtake LAN"
```

Both devices must be on the same reachable local network; guest Wi-Fi and client isolation can prevent devices from connecting. If needed, set another port before starting the host server:

```powershell
$env:PORT = "3100"
npm run server
```

Use that port in the client URL as well. `npm run server` serves `dist/`, so run `npm run build` after frontend changes and before starting the server. The game itself loads its models and runtime dependencies from the local build; no public CDN or matchmaking service is used.

LAN mode supports up to four players. The host creates a room and shares its room link/code; players select a car and ready up before the host starts. Traffic collisions and overtakes are evaluated on the server; a completed overtake earns 100 points and a near miss adds 250 bonus points. If every survivor is eliminated during the same server simulation step, the result is a draw. Disconnects can reconnect to the same session for up to 60 seconds. Once that grace period expires, the disconnected player forfeits the current race.

## Source layout

- `src/main.jsx`: React screens, HUD, garage, settings and touch controls.
- `src/store.js`: Zustand UI state.
- `src/engine/preload.js`: model download and real byte progress.
- `src/engine/legacy.js`: retained Three.js simulation and game mechanics, with a narrow UI API at `window.__night`.
- `src/engine/legacy-dom.html`: hidden compatibility nodes used by the retained engine during incremental migration.
- `src/audio/soundscape.js`: lightweight synthesized music bed and interface sound.
- `src/multiplayer/`: WebSocket client, LAN screens and shared vehicle rules.
- `server/`: same-port HTTP and WebSocket host with authoritative rooms and traffic.
- `src/styles/`: original engine styling and new UI styling.
- `public/models/`: four original JSON files containing base64 encoded GLB models.
- `public/fonts/`: supplied MostWasted font and its license.

There is one WebGL renderer and one simulation loop. React receives snapshots about seven times per second; vehicle physics and animation run outside React. Traffic meshes are reused from a small pool. Auto quality adjusts pixel ratio and effects according to measured frame rate.

## Checks

With `npm run dev` running, use:

```bash
npm run test:smoke
npm run test:extreme
npm run test:mobile
npm run test:economy
npm run test:graphics
npm run test:lan
```

These browser checks use Chrome through `playwright-core`. On another machine set `CHROME_PATH` to the Chrome executable. The checks cover loading, menus, all four main modes, dense moving traffic, pause and results, keyboard steering, simultaneous touch inputs, purchase and persistence, and graphics controls.

After `npm run build` and `npm run preview`, `npm run test:production` checks the built game at port 4173.

For LAN protocol and four-client browser checks, first run `npm run build` and `npm run server` in one terminal, then run:

```powershell
$env:LAN_TEST_URL = "http://127.0.0.1:3000"
npm run test:lan:protocol
npm run test:lan:browser
npm run test:lan:shutdown
```

The browser check uses Chrome and exercises a four-player room, nicknames, car selection, room capacity, synchronized traffic, lobby reconnection and the race outcome. The protocol check also reconnects during an active race. The unit check covers spectator target selection, including switching and automatic retargeting. The shutdown check starts a separate server, stops it, and verifies the connection-lost screen. Set `CHROME_PATH` if Chrome is installed outside the default Windows location. Physical Android devices and multi-device Wi-Fi behavior still require manual testing.

## Fixed during migration

- Removed dependence on CDN hosted Three.js scripts.
- Added model validation, real loading progress, retry and load errors.
- Preserved the old save key and migrated existing progress into version 3 data.
- Replaced the distance ended pursuit with a three minute objective.
- Added bounded drift sessions, test drives, pause, restart and race results.
- Added pointer capture and release handling for multitouch controls.
- Added live lighting and rim customization and prevented test drives from awarding currency.
- Added traffic object reuse, adaptive rendering and visibility pause.

## Known limits

- The original simulation remains a large module. It was retained to preserve its working vehicle, scenery, pursuit and audio systems while the UI and loading code moved to React modules.
- The four original models total about 21 MB before network compression, so a first load can take time on mobile data.
- Automated touch was checked in Chrome device emulation. Physical Android performance and tilt sensor permission still need device testing.
- LAN rendering uses interpolated authoritative snapshots. Local driving input is server controlled; client-side prediction is not enabled, so noticeable network latency can make steering feel delayed.
- Music and UI sounds are synthesized in the browser; no third party soundtrack was supplied.
