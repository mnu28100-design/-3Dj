# LAN integration plan

Audit: React 19/Vite owns menus and HUD; `src/engine/legacy.js` owns the single Three.js renderer, vehicle models, traffic pool, physics, keyboard/touch state, save data and frame loop. The engine publishes a small `window.__night` API. Single-player simulation is coupled to its camera and road-relative coordinates.

1. Preserve the current project in `Night_Overtake_3D_pre_LAN.zip`.
2. Add a shared, balanced LAN vehicle step and an authoritative Node.js server. The server alone owns room membership, traffic, collisions, elimination and rankings.
3. Add a React lobby, LAN HUD, spectator controls and results, backed by one WebSocket client.
4. Extend the existing engine with a LAN branch in its existing frame loop. Reuse original vehicle models, road, camera and pooled traffic meshes. Keep single-player branches intact.
5. Verify room rules and simulation with automated tests, then run browser clients and existing single-player checks. Build and package the production frontend and server.

The LAN world uses absolute distance along the highway. Each client renders that shared world relative to its own car or spectator target. Vehicle inputs go to the server; client position and collision claims are ignored. Player-versus-player collision is absent from the server collision loop, and remote meshes have no local physical response.
