import { randomBytes } from 'node:crypto'
import { LANES, LAN_CARS, PLAYER_WIDTH, PLAYER_LENGTH, TICK, createVehicle, stepVehicle, trafficDifficulty } from '../src/multiplayer/shared.js'

const COLORS = ['#c9d1db', '#b83c3c', '#d99b2b', '#3f8f6d', '#6a5ad6', '#d8d2c4']
const KINDS = ['sedan', 'suv', 'hatch', 'coupe', 'truck']
const ROOM_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
export const send = (session, data) => {
  if (session.ws?.readyState === 1) session.ws.send(JSON.stringify(data))
}
export const roomCode = () => Array.from(randomBytes(6), (byte) => ROOM_ALPHABET[byte % ROOM_ALPHABET.length]).join('')
const graphemes = (value) => [...new Intl.Segmenter('ru', { granularity: 'grapheme' }).segment(value)].length
export function validateNickname(value) {
  if (typeof value !== 'string') return null
  const name = value.trim().replace(/\s+/gu, ' ')
  if (/[\p{Cc}\p{Cf}]/u.test(name) || graphemes(name) < 2 || graphemes(name) > 16) return null
  return name
}
const cleanText = (value, max = 32) => typeof value === 'string' && !/[\p{Cc}\p{Cf}]/u.test(value) ? [...value.trim()].slice(0, max).join('') : ''
const carOrDefault = (id) => LAN_CARS.includes(id) ? id : 'm4'

export class GameRoom {
  constructor(code, host, name = 'Ночная трасса') {
    this.code = code
    this.name = cleanText(name) || 'Ночная трасса'
    this.hostId = host.id
    this.players = new Map()
    this.stage = 'lobby'
    this.config = { difficulty: 1, density: 1, nitro: true, countdown: 3, maxPlayers: 4 }
    this.countdownAt = 0
    this.elapsed = 0
    this.traffic = []
    this.nextTrafficId = 1
    this.spawnIn = 1.5
    this.tickCount = 0
    this.results = null
    this.add(host)
  }
  add(session) {
    if (this.stage !== 'lobby') return 'Заезд уже начался'
    if (this.players.size >= this.config.maxPlayers) return 'Комната заполнена'
    if (session.room) return 'Вы уже в комнате'
    let name = session.nickname
    let suffix = 2
    const names = new Set([...this.players.values()].map((p) => p.nickname.toLocaleLowerCase()))
    while (names.has(name.toLocaleLowerCase())) name = [...session.nickname].slice(0, 12).join('') + ` (${suffix++})`
    session.nickname = name
    session.room = this
    session.ready = false
    session.car = carOrDefault(session.car)
    session.color ||= '#9cbd0a'
    session.light ||= '#fff4dc'
    this.players.set(session.id, session)
    this.broadcastRoom()
    return null
  }
  publicRoom() {
    return { code: this.code, name: this.name, stage: this.stage, hostId: this.hostId,
      config: { ...this.config }, players: [...this.players.values()].map((p) => ({
        id: p.id, nickname: p.nickname, car: p.car, color: p.color, light: p.light,
        ready: !!p.ready, connected: !!p.connected, host: p.id === this.hostId,
      })) }
  }
  broadcast(data) { for (const p of this.players.values()) send(p, data) }
  broadcastRoom() { this.broadcast({ type: 'room', room: this.publicRoom() }) }
  configure(session, config) {
    if (session.id !== this.hostId || this.stage !== 'lobby') return false
    if (!config || typeof config !== 'object') return false
    const out = { ...this.config }
    if (config.difficulty !== undefined) {
      if (![0.8, 1, 1.2, 1.4].includes(config.difficulty)) return false
      out.difficulty = config.difficulty
    }
    if (config.density !== undefined) {
      if (![0.8, 1, 1.2, 1.4].includes(config.density)) return false
      out.density = config.density
    }
    if (config.nitro !== undefined) {
      if (typeof config.nitro !== 'boolean') return false
      out.nitro = config.nitro
    }
    if (config.countdown !== undefined) {
      if (![3, 5, 10].includes(config.countdown)) return false
      out.countdown = config.countdown
    }
    if (config.maxPlayers !== undefined) {
      if (![2, 3, 4].includes(config.maxPlayers) || config.maxPlayers < this.players.size) return false
      out.maxPlayers = config.maxPlayers
    }
    this.config = out
    this.broadcastRoom()
    return true
  }
  ready(session, value) {
    if (this.stage !== 'lobby' || !this.players.has(session.id) || typeof value !== 'boolean') return false
    session.ready = value
    this.broadcastRoom()
    return true
  }
  select(session, car, color, light) {
    if (this.stage !== 'lobby' || !this.players.has(session.id) || !LAN_CARS.includes(car)) return false
    if (color !== undefined && !/^#[\da-fA-F]{6}$/.test(color)) return false
    if (light !== undefined && !/^#[\da-fA-F]{6}$/.test(light)) return false
    session.car = car
    if (color) session.color = color
    if (light) session.light = light
    session.ready = false
    this.broadcastRoom()
    return true
  }
  start(session, now = Date.now()) {
    if (session.id !== this.hostId || this.stage !== 'lobby' || this.players.size < 2 ||
        [...this.players.values()].some((p) => !p.ready || !p.connected)) return false
    this.stage = 'countdown'
    this.countdownAt = now + this.config.countdown * 1000
    this.broadcastRoom()
    this.broadcast({ type: 'countdown', startAt: this.countdownAt })
    return true
  }
  startRace() {
    this.stage = 'race'
    this.elapsed = 0
    this.traffic = []
    this.nextTrafficId = 1
    this.spawnIn = 1.5 / this.config.density
    this.tickCount = 0
    this.results = null
    let index = 0
    for (const p of this.players.values()) {
      p.vehicle = createVehicle(index++)
      p.ready = false
    }
    this.broadcastRoom()
    this.broadcast({ type: 'raceStart', state: this.snapshot() })
  }
  input(session, input) {
    const v = session.vehicle
    if (this.stage !== 'race' || !session.connected || !v?.alive ||
        !Number.isSafeInteger(input.sequence) || input.sequence <= v.lastSequence ||
        !['steering', 'throttle', 'brake'].every((key) => typeof input[key] === 'number' && Number.isFinite(input[key])) ||
        Math.abs(input.steering) > 1 || input.throttle < 0 || input.throttle > 1 ||
        input.brake < 0 || input.brake > 1 || typeof input.nitro !== 'boolean') return false
    v.lastSequence = input.sequence
    v.input = { steering: input.steering, throttle: input.throttle, brake: input.brake, nitro: input.nitro }
    return true
  }
  spawnTraffic() {
    const info = trafficDifficulty(this.elapsed, this.config.difficulty * this.config.density)
    if (this.traffic.length >= info.maxTraffic) return
    const leader = Math.max(...[...this.players.values()].filter((p) => p.vehicle?.alive).map((p) => p.vehicle.d))
    if (!Number.isFinite(leader)) return
    const d = leader + 195 + Math.random() * 25
    const blocked = new Set(this.traffic.filter((t) => Math.abs(t.d - d) < 28).map((t) => t.lane))
    if (blocked.size >= 3) return // always keep a full lane-sized route through each traffic band
    const available = [0, 1, 2, 3].filter((lane) => !this.traffic.some((t) => t.lane === lane && Math.abs(t.d - d) < 42))
    if (!available.length) return
    const lane = available[Math.floor(Math.random() * available.length)]
    const truck = Math.random() < 0.12 + info.stage * 0.015
    const kind = truck ? 'truck' : KINDS[Math.floor(Math.random() * 4)]
    this.traffic.push({ id: this.nextTrafficId++, lane, x: LANES[lane], d,
      speed: truck ? 58 + Math.random() * 22 : 55 + Math.random() * (55 + info.stage * 3),
      kind, color: COLORS[Math.floor(Math.random() * COLORS.length)],
      width: truck ? 2.45 : 1.9, length: truck ? 8 : 4.5, passed: new Set() })
  }
  eliminate(session, reason = 'traffic') {
    if (!session.vehicle?.alive) return
    session.vehicle.alive = false
    session.vehicle.survival = this.elapsed
    session.vehicle.input = { steering: 0, throttle: 0, brake: 1, nitro: false }
    this.broadcast({ type: 'eliminated', id: session.id, nickname: session.nickname, survival: this.elapsed, reason })
  }
  advance(dt = TICK, now = Date.now()) {
    if (this.stage === 'countdown' && now >= this.countdownAt) this.startRace()
    if (this.stage !== 'race') return
    this.elapsed += dt
    this.tickCount++
    const alive = [...this.players.values()].filter((p) => p.vehicle?.alive)
    for (const p of alive) {
      if (!p.connected) p.vehicle.input = { steering: 0, throttle: 0, brake: 1, nitro: false }
      stepVehicle(p.vehicle, p.vehicle.input, dt, this.config.nitro)
    }
    for (const t of this.traffic) t.d += t.speed / 3.6 * dt
    this.spawnIn -= dt
    if (this.spawnIn <= 0) {
      this.spawnTraffic()
      this.spawnIn = trafficDifficulty(this.elapsed, this.config.difficulty * this.config.density).spawnInterval
    }
    // Only PLAYER versus TRAFFIC is checked. Player meshes never collide with each other.
    for (const p of alive) {
      const v = p.vehicle
      for (const t of this.traffic) {
        const dz = t.d - v.d, dx = Math.abs(t.x - v.x)
        if (Math.abs(dz) < (t.length + PLAYER_LENGTH) * 0.43 && dx < (t.width + PLAYER_WIDTH) * 0.46) {
          this.eliminate(p)
          break
        }
        if (dz < -(t.length + PLAYER_LENGTH) / 2 && !t.passed.has(p.id)) {
          t.passed.add(p.id)
          v.overtakes++
          v.score += 100
          if (dx < (t.width + PLAYER_WIDTH) / 2 + 0.8) {
            v.nearMisses++
            v.score += 250
          }
        }
      }
    }
    const active = [...this.players.values()].filter((p) => p.vehicle?.alive)
    const tail = Math.min(...active.map((p) => p.vehicle.d))
    this.traffic = this.traffic.filter((t) => t.d > tail - 65 && t.d < Math.max(...active.map((p) => p.vehicle.d), tail) + 300)
    if (active.length <= 1) this.finish()
    else if (this.tickCount % 2 === 0) this.broadcast({ type: 'state', state: this.snapshot() })
  }
  snapshot() {
    return { stage: this.stage, elapsed: this.elapsed, difficulty: trafficDifficulty(this.elapsed, this.config.difficulty).stage,
      survivors: [...this.players.values()].filter((p) => p.vehicle?.alive).length,
      players: [...this.players.values()].map((p) => ({ id: p.id, nickname: p.nickname, car: p.car, color: p.color, light: p.light,
        connected: p.connected, ...(p.vehicle ? { x: p.vehicle.x, vx: p.vehicle.vx, d: p.vehicle.d,
          speed: p.vehicle.speed, nitro: p.vehicle.nitro, alive: p.vehicle.alive,
          survival: p.vehicle.survival, maxSpeed: p.vehicle.maxSpeed,
          overtakes: p.vehicle.overtakes, nearMisses: p.vehicle.nearMisses } : {}) })),
      traffic: this.traffic.map((t) => ({ id: t.id, x: t.x, d: t.d, speed: t.speed, kind: t.kind, color: t.color })) }
  }
  finish() {
    if (this.stage !== 'race') return
    this.stage = 'results'
    const alive = [...this.players.values()].filter((p) => p.vehicle?.alive)
    const winnerId = alive.length === 1 ? alive[0].id : null
    const sorted = [...this.players.values()].sort((a, b) => Number(b.vehicle.alive) - Number(a.vehicle.alive) || b.vehicle.survival - a.vehicle.survival || a.id.localeCompare(b.id))
    this.results = { winnerId, draw: winnerId === null, elapsed: this.elapsed,
      ranking: sorted.map((p, i) => ({ rank: i + 1, id: p.id, nickname: p.nickname, car: p.car,
        survival: p.vehicle.alive ? this.elapsed : p.vehicle.survival,
        maxSpeed: Math.round(p.vehicle.maxSpeed), overtakes: p.vehicle.overtakes,
        nearMisses: p.vehicle.nearMisses, score: p.vehicle.score })) }
    this.broadcast({ type: 'results', results: this.results })
    this.broadcastRoom()
  }
  rematch(session) {
    if (session.id !== this.hostId || this.stage !== 'results') return false
    this.stage = 'lobby'
    this.results = null
    this.traffic = []
    for (const p of [...this.players.values()]) if (!p.connected) this.players.delete(p.id)
    for (const p of this.players.values()) { p.vehicle = null; p.ready = false }
    this.broadcastRoom()
    return true
  }
  disconnect(session, now = Date.now()) {
    session.connected = false
    session.disconnectUntil = now + 60000
    if (this.stage === 'lobby') this.transferHost()
    this.broadcastRoom()
  }
  expireDisconnected(now = Date.now()) {
    let changed = false
    for (const p of [...this.players.values()]) {
      if (p.connected || !p.disconnectUntil || now < p.disconnectUntil) continue
      if (this.stage === 'race') {
        this.eliminate(p, 'disconnect')
        this.players.set(p.id, { ...p, ws: null, connected: false, disconnectUntil: 0 })
        p.room = null
        changed = true
        continue
      }
      this.players.delete(p.id)
      p.room = null
      changed = true
    }
    if (!changed) return
    this.transferHost()
    if (this.stage === 'race' && [...this.players.values()].filter((p) => p.vehicle?.alive).length <= 1) this.finish()
    this.broadcastRoom()
  }
  transferHost() {
    if (this.players.get(this.hostId)?.connected) return
    const next = [...this.players.values()].find((p) => p.connected)
    if (next) this.hostId = next.id
  }
  leave(session) {
    if (this.stage === 'race') {
      this.eliminate(session, 'left')
      this.players.set(session.id, { ...session, ws: null, connected: false, room: this })
    } else this.players.delete(session.id)
    session.room = null
    session.vehicle = null
    this.transferHost()
    if (this.stage === 'race' && [...this.players.values()].filter((p) => p.vehicle?.alive).length <= 1) this.finish()
    this.broadcastRoom()
  }
}
