import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { randomBytes, randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { WebSocketServer } from 'ws'
import { GameRoom, roomCode, send, validateNickname } from './game.js'

const base = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const dist = path.join(base, 'dist')
const port = Number(process.env.PORT) || 3000
const rooms = new Map()
const sessions = new Map()
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.ttf': 'font/ttf', '.png': 'image/png', '.ico': 'image/x-icon' }

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return }
  let pathname
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname) }
  catch { res.writeHead(400).end(); return }
  if (pathname.includes('\0')) { res.writeHead(400).end(); return }
  let file = path.resolve(dist, '.' + pathname)
  if (file !== dist && !file.startsWith(dist + path.sep)) { res.writeHead(403).end(); return }
  if (pathname === '/' || !path.extname(file)) file = path.join(dist, 'index.html')
  fs.stat(file, (error, stat) => {
    if (error || !stat.isFile()) { res.writeHead(404).end('Not found'); return }
    res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream',
      'Content-Length': stat.size, 'Cache-Control': path.extname(file) === '.html' ? 'no-cache' : 'public, max-age=3600' })
    if (req.method === 'HEAD') { res.end(); return }
    fs.createReadStream(file).pipe(res)
  })
})
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 2048, perMessageDeflate: false })

function fail(session, message) { send(session, { type: 'error', message }) }
function handle(session, message) {
  const room = session.room
  switch (message.type) {
    case 'create': {
      if (room) return fail(session, 'Сначала покиньте текущую комнату')
      const nickname = validateNickname(message.nickname)
      if (!nickname) return fail(session, 'Ник: от 2 до 16 видимых символов')
      session.nickname = nickname
      let code
      do { code = roomCode() } while (rooms.has(code))
      const made = new GameRoom(code, session, message.name)
      rooms.set(code, made)
      return
    }
    case 'join': {
      if (room) return fail(session, 'Сначала покиньте текущую комнату')
      if (Date.now() - session.joinWindow > 10000) { session.joinWindow = Date.now(); session.joinCount = 0 }
      if (++session.joinCount > 6) return fail(session, 'Слишком много попыток. Подождите 10 секунд')
      const nickname = validateNickname(message.nickname)
      if (!nickname) return fail(session, 'Ник: от 2 до 16 видимых символов')
      const code = typeof message.code === 'string' ? message.code.trim().toUpperCase() : ''
      if (!/^[A-Z2-9]{6}$/.test(code)) return fail(session, 'Неверный код комнаты')
      const target = rooms.get(code)
      if (!target) return fail(session, 'Комната не найдена')
      session.nickname = nickname
      const error = target.add(session)
      if (error) fail(session, error)
      return
    }
    case 'leave': {
      if (!room) return
      room.leave(session)
      if (!room.players.size) rooms.delete(room.code)
      send(session, { type: 'left' })
      return
    }
    case 'ready':
      if (!room?.ready(session, message.value)) fail(session, 'Нельзя изменить готовность')
      return
    case 'select':
      if (!room?.select(session, message.car, message.color, message.light)) fail(session, 'Неверный выбор машины')
      return
    case 'config':
      if (!room?.configure(session, message.config)) fail(session, 'Неверные настройки комнаты')
      return
    case 'start':
      if (!room?.start(session)) fail(session, 'Нужно 2–4 готовых игрока; стартует только хост')
      return
    case 'input':
      if (!room) return
      if (Date.now() - session.inputWindow > 1000) { session.inputWindow = Date.now(); session.inputCount = 0 }
      if (++session.inputCount > 40) return
      room.input(session, message)
      return
    case 'rematch':
      if (!room?.rematch(session)) fail(session, 'Повторный заезд запускает хост после результата')
      return
    case 'ping':
      if (Number.isSafeInteger(message.sent)) send(session, { type: 'pong', sent: message.sent, now: Date.now() })
      return
    default: fail(session, 'Неизвестная команда')
  }
}

wss.on('connection', (ws, req) => {
  const token = new URL(req.url, 'http://localhost').searchParams.get('token')
  let session = token ? sessions.get(token) : null
  if (session?.connected) {
    ws.close(4001, 'Session already connected')
    return
  }
  if (session && Date.now() > session.disconnectUntil) {
    ws.close(4003, 'Session expired')
    return
  }
  if (!session) {
    session = { id: randomUUID(), token: randomBytes(24).toString('hex'), nickname: '', car: 'm4',
      color: '#9cbd0a', light: '#fff4dc', ready: false, room: null, vehicle: null,
      connected: false, joinWindow: 0, joinCount: 0, inputWindow: 0, inputCount: 0, messageWindow: 0, messageCount: 0 }
    sessions.set(session.token, session)
  }
  session.ws = ws
  session.connected = true
  session.disconnectUntil = 0
  send(session, { type: 'welcome', id: session.id, token: session.token })
  if (session.room) {
    session.room.broadcastRoom()
    if (session.room.stage === 'race') send(session, { type: 'state', state: session.room.snapshot() })
    if (session.room.stage === 'results') send(session, { type: 'results', results: session.room.results })
  }
  ws.on('message', (data) => {
    if (Date.now() - session.messageWindow > 1000) { session.messageWindow = Date.now(); session.messageCount = 0 }
    if (++session.messageCount > 60) { ws.close(1008, 'Rate limit'); return }
    let message
    try { message = JSON.parse(data.toString()) } catch { fail(session, 'Повреждённое сообщение'); return }
    if (!message || Array.isArray(message) || typeof message !== 'object' || typeof message.type !== 'string') {
      fail(session, 'Неверное сообщение'); return
    }
    handle(session, message)
  })
  ws.on('close', () => {
    if (session.ws !== ws) return
    session.ws = null
    session.connected = false
    session.disconnectUntil = Date.now() + 60000
    if (session.room) session.room.disconnect(session)
  })
})

setInterval(() => {
  const now = Date.now()
  for (const room of rooms.values()) room.advance(1 / 30, now)
}, 1000 / 30)
setInterval(() => {
  const now = Date.now()
  for (const [code, room] of rooms) {
    room.expireDisconnected(now)
    if (!room.players.size) rooms.delete(code)
  }
  for (const [token, session] of sessions) if (!session.connected && !session.room && session.disconnectUntil < now) sessions.delete(token)
}, 1000)

server.listen(port, '0.0.0.0', () => {
  console.log(`Night Overtake LAN server on port ${port}`)
  console.log(`Local: http://localhost:${port}`)
  for (const list of Object.values(os.networkInterfaces())) for (const address of list || []) {
    if (address.family === 'IPv4' && !address.internal) console.log(`LAN: http://${address.address}:${port}`)
  }
})
