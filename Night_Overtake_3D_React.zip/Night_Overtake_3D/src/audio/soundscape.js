class Soundscape {
  context = null
  master = null
  music = null
  settings = { sound: true, master: 1, music: .2, ui: 1 }

  activate() {
    if (this.context) {
      if (this.context.state === 'suspended') this.context.resume().catch(() => {})
      return
    }
    const AudioContext = window.AudioContext || window.webkitAudioContext
    if (!AudioContext) return
    const ctx = this.context = new AudioContext()
    this.master = ctx.createGain()
    this.music = ctx.createGain()
    const filter = ctx.createBiquadFilter()
    filter.type = 'lowpass'
    filter.frequency.value = 240
    this.music.connect(filter)
    filter.connect(this.master)
    this.master.connect(ctx.destination)
    for (const [frequency, wave] of [[55, 'sine'], [82.41, 'triangle']]) {
      const oscillator = ctx.createOscillator()
      oscillator.type = wave
      oscillator.frequency.value = frequency
      oscillator.connect(this.music)
      oscillator.start()
    }
    const lfo = ctx.createOscillator()
    lfo.frequency.value = .13
    const lfoGain = ctx.createGain()
    lfoGain.gain.value = .008
    lfo.connect(lfoGain)
    lfoGain.connect(this.music.gain)
    lfo.start()
    this.set(this.settings)
  }

  set(settings) {
    this.settings = { ...this.settings, ...settings }
    if (!this.context) return
    const now = this.context.currentTime
    this.master.gain.setTargetAtTime(this.settings.sound ? this.settings.master : 0, now, .04)
    this.music.gain.setTargetAtTime(this.settings.music * .025, now, .15)
  }

  click() {
    if (!this.context || !this.settings.sound || this.settings.ui <= 0) return
    const now = this.context.currentTime
    const osc = this.context.createOscillator()
    const gain = this.context.createGain()
    osc.type = 'triangle'
    osc.frequency.setValueAtTime(660, now)
    osc.frequency.exponentialRampToValueAtTime(1040, now + .055)
    gain.gain.setValueAtTime(.018 * this.settings.ui, now)
    gain.gain.exponentialRampToValueAtTime(.001, now + .085)
    osc.connect(gain)
    gain.connect(this.master)
    osc.start(now)
    osc.stop(now + .09)
    osc.onended = () => { osc.disconnect(); gain.disconnect() }
  }
}

export const soundscape = new Soundscape()
