import { useGame } from '../store'
import { spectatorTarget } from './shared'

const update = (patch) => useGame.getState().setLan(patch)
const screen = (name) => useGame.getState().setScreen(name)
const engine = () => useGame.getState().engine

class LanClient {
  constructor() {
    this.ws = null
    this.id = null
    this.tokenKey = `night-lan-token-${location.host}`
    this.token = localStorage.getItem(this.tokenKey) || ''
    this.seq = 0
    this.spectatorId = null
    this.inRace = false
    this.manual = false
    this.retry = 0
    this.inputTimer = null
    this.pingTimer = null
    this.reconnectTimer = null
    this.pendingPings = new Map()
    this.pingSent = 0
    this.pingReceived = 0
    this.readyAfterRematch = false
  }
  connect() {
    if (this.ws?.readyState === WebSocket.OPEN || this.ws?.readyState === WebSocket.CONNECTING) return
    this.manual = false
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:'
    const query = this.token ? `?token=${encodeURIComponent(this.token)}` : ''
    const ws = new WebSocket(`${protocol}//${location.host}/ws${query}`)
    this.ws = ws
    update({ status: this.retry ? 'reconnecting' : 'connecting', error: '' })
    ws.onopen = () => {
      this.retry = 0
      update({ status: 'connected', error: '' })
      this.startTimers()
    }
    ws.onmessage = (event) => {
      let data
      try { data = JSON.parse(event.data) } catch { return }
      this.receive(data)
    }
    ws.onerror = () => { update({ status: 'reconnecting' }) }
    ws.onclose = (event) => {
      if (this.ws !== ws) return
      this.ws = null
      this.stopTimers()
      if (this.manual) return
      if (event.code === 4003 && this.token) {
        this.token = ''; localStorage.removeItem(this.tokenKey)
        localStorage.removeItem('night-lan-inroom')
        engine()?.lanLeave(); this.inRace = false; this.spectatorId = null
        update({ status: 'lost', room: null, snapshot: null, results: null, error: 'Сессия истекла. Войдите в комнату снова.' })
        screen('lanLost')
        return
      }
      this.retry++
      if (this.retry > 5) {
        engine()?.lanLeave(); this.inRace = false
        update({ status: 'lost', error: 'Соединение с LAN сервером потеряно' }); screen('lanLost'); return
      }
      update({ status: 'reconnecting', error: `Переподключение: попытка ${this.retry}` })
      this.reconnectTimer = setTimeout(() => this.connect(), Math.min(4000, 500 * 2 ** this.retry))
    }
  }
  startTimers() {
    this.stopTimers()
    this.inputTimer = setInterval(() => {
      const local = useGame.getState().lan.snapshot?.players.find((p) => p.id === this.id)
      if (!local?.alive || !this.inRace || !engine()) return
      this.send({ type: 'input', sequence: ++this.seq, ...engine().lanInput() })
    }, 50)
    this.pingTimer = setInterval(() => {
      const now = Date.now()
      for (const [sent] of this.pendingPings) if (now - sent > 5000) this.pendingPings.delete(sent)
      this.pendingPings.set(now, true)
      this.pingSent++
      this.send({ type: 'ping', sent: now })
      update({ loss: Math.max(0, Math.round((1 - this.pingReceived / Math.max(1, this.pingSent)) * 100)) })
    }, 2000)
  }
  stopTimers() {
    clearInterval(this.inputTimer)
    clearInterval(this.pingTimer)
    clearTimeout(this.reconnectTimer)
    this.inputTimer = this.pingTimer = this.reconnectTimer = null
  }
  send(data) { if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(data)) }
  receive(data) {
    switch (data.type) {
      case 'welcome':
        this.id = data.id
        this.token = data.token
        localStorage.setItem(this.tokenKey, this.token)
        update({ id: this.id, status: 'connected' })
        break
      case 'room':
        localStorage.setItem('night-lan-inroom', '1')
        update({ room: data.room, error: '' })
        if (data.room.stage === 'lobby' || data.room.stage === 'countdown') {
          if (this.inRace) { engine()?.lanLeave(); this.inRace = false }
          if (engine()) screen('lanRoom')
          if (data.room.stage === 'lobby' && this.readyAfterRematch) {
            this.readyAfterRematch = false
            this.ready(true)
          }
        }
        break
      case 'countdown':
        update({ countdownAt: data.startAt })
        break
      case 'raceStart':
      case 'state': {
        const state = data.state
        if (!state || !Array.isArray(state.players) || !Array.isArray(state.traffic)) break
        if (!this.inRace) {
          this.inRace = true
          this.spectatorId = null
          engine()?.lanEnter(state, this.id)
          if (engine()) screen('lanPlay')
        }
        const local = state.players.find((p) => p.id === this.id)
        if (local && !local.alive) {
          this.spectatorId = spectatorTarget(state.players, this.spectatorId)
        }
        engine()?.lanUpdate(state, this.id, this.spectatorId)
        update({ snapshot: state, spectatorId: this.spectatorId })
        break
      }
      case 'eliminated':
        if (data.id === this.id) engine()?.lanImpact()
        update({ notice: `${data.nickname} выбыл · ${Math.round(data.survival)} с` })
        setTimeout(() => { if (useGame.getState().lan.notice?.startsWith(data.nickname)) update({ notice: null }) }, 4000)
        break
      case 'results':
        this.inRace = false
        try {
          const previous = JSON.parse(localStorage.getItem('night-lan-record') || '{}')
          const mine = data.results?.ranking?.find((p) => p.id === this.id)
          if (mine) localStorage.setItem('night-lan-record', JSON.stringify({
            best: Math.max(previous.best || 0, mine.survival),
            difficulty: Math.max(previous.difficulty || 0, useGame.getState().lan.snapshot?.difficulty || 1),
          }))
        } catch {}
        update({ results: data.results, snapshot: useGame.getState().lan.snapshot })
        if (engine()) screen('lanResults')
        break
      case 'left':
        localStorage.removeItem('night-lan-inroom')
        engine()?.lanLeave()
        this.inRace = false
        this.spectatorId = null
        update({ room: null, snapshot: null, results: null, spectatorId: null, notice: null })
        screen('lanMenu')
        break
      case 'error': update({ error: data.message || 'Ошибка LAN' }); break
      case 'pong': {
        if (!this.pendingPings.has(data.sent)) break
        this.pendingPings.delete(data.sent)
        this.pingReceived++
        update({ ping: Date.now() - data.sent, loss: Math.max(0, Math.round((1 - this.pingReceived / Math.max(1, this.pingSent)) * 100)) })
        break
      }
    }
  }
  create(nickname, name) { this.send({ type: 'create', nickname, name }) }
  join(nickname, code) { this.send({ type: 'join', nickname, code }) }
  select(car, color, light) { this.send({ type: 'select', car, color, light }) }
  ready(value) { this.send({ type: 'ready', value }) }
  configure(config) { this.send({ type: 'config', config }) }
  start() { this.send({ type: 'start' }) }
  rematch() { this.send({ type: 'rematch' }) }
  playAgain() { this.readyAfterRematch = true; this.rematch() }
  leave() { this.send({ type: 'leave' }) }
  switchSpectator(delta) {
    const state = useGame.getState().lan.snapshot
    if (!state) return
    this.spectatorId = spectatorTarget(state.players, this.spectatorId, delta)
    if (!this.spectatorId) return
    engine()?.lanSpectate(this.spectatorId)
    update({ spectatorId: this.spectatorId })
  }
  restoreView() {
    const lan = useGame.getState().lan
    if (lan.status === 'lost') { screen('lanLost'); return }
    if (lan.results) { screen('lanResults'); return }
    if (this.inRace && lan.snapshot) {
      engine()?.lanEnter(lan.snapshot, this.id)
      engine()?.lanUpdate(lan.snapshot, this.id, this.spectatorId)
      screen('lanPlay')
      return
    }
    if (lan.room) { screen('lanRoom'); return }
    screen('lanMenu')
  }
  disconnect() {
    this.manual = true
    localStorage.removeItem('night-lan-inroom')
    this.stopTimers()
    this.ws?.close(1000)
    this.ws = null
    engine()?.lanLeave()
    this.inRace = false
    update({ status: 'offline', room: null, snapshot: null, results: null, error: '' })
  }
}

export const lanClient = new LanClient()
