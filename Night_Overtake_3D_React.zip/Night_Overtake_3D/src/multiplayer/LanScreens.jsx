import React, { useEffect, useState } from 'react'
import { useGame } from '../store'
import { lanClient } from './client'

const fmt = (seconds = 0) => `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${Math.floor(seconds % 60).toString().padStart(2, '0')}`
const carName = (id) => ({ m4: 'BMW M4', g63: 'Mercedes G 63', r34: 'Nissan R34', '911': 'Porsche 911' })[id] || id

function LanHeader({ title, back }) {
  return <header className="topbar"><button className="back-button" onClick={back}>← НАЗАД</button><div className="top-title">{title}</div><div className="brand-mini">LAN <span>3D</span></div></header>
}

export function LanMenu() {
  const lan = useGame((s) => s.lan)
  const setScreen = useGame((s) => s.setScreen)
  const [tab, setTab] = useState('create')
  const [nickname, setNickname] = useState(localStorage.getItem('night-lan-nickname') || '')
  const [roomName, setRoomName] = useState('Ночная трасса')
  const [code, setCode] = useState(new URLSearchParams(location.search).get('room') || '')
  const record = (() => { try { return JSON.parse(localStorage.getItem('night-lan-record') || '{}') } catch { return {} } })()
  useEffect(() => { lanClient.connect() }, [])
  const submit = () => {
    const name = nickname.trim().replace(/\s+/gu, ' ')
    const visibleLength = [...new Intl.Segmenter('ru', { granularity: 'grapheme' }).segment(name)].length
    if (/[\p{Cc}\p{Cf}]/u.test(name) || visibleLength < 2 || visibleLength > 16) {
      useGame.getState().setLan({ error: 'Ник: от 2 до 16 видимых символов' }); return
    }
    localStorage.setItem('night-lan-nickname', name)
    if (tab === 'create') lanClient.create(name, roomName)
    else lanClient.join(name, code)
  }
  return <div className="screen panel-screen lan-screen"><LanHeader title="LAN MULTIPLAYER" back={() => { lanClient.disconnect(); setScreen('menu') }} />
    <div className="lan-panel glass"><div className="eyebrow">ЛОКАЛЬНАЯ СЕТЬ · ДО 4 ИГРОКОВ</div><h1>ИГРАЙТЕ ВМЕСТЕ</h1>
      <p>Все устройства подключаются к одному серверу по Wi-Fi. Адрес этого сервера: <strong>{location.origin}</strong></p>
      <div className="lan-tabs"><button className={tab === 'create' ? 'selected' : ''} onClick={() => setTab('create')}>СОЗДАТЬ КОМНАТУ</button><button className={tab === 'join' ? 'selected' : ''} onClick={() => setTab('join')}>ПРИСОЕДИНИТЬСЯ</button></div>
      <label>ВАШ НИК<input maxLength={32} value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="Никнейм" autoComplete="nickname" /></label>
      {tab === 'create' ? <label>НАЗВАНИЕ КОМНАТЫ<input maxLength={32} value={roomName} onChange={(e) => setRoomName(e.target.value)} /></label> : <label>КОД КОМНАТЫ<input maxLength={6} value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="ABC234" autoCapitalize="characters" /></label>}
      <div className="lan-status">● {({ connected: 'Сервер подключён', connecting: 'Подключение...', reconnecting: 'Переподключение...', lost: 'Сервер недоступен', offline: 'Не подключено' })[lan.status]}{lan.ping !== null && ` · ${lan.ping} мс`}</div>
      <small>Личный рекорд: {fmt(record.best)} · уровень потока {record.difficulty || 0}</small>
      {lan.error && <p className="error" role="alert">{lan.error}</p>}
      <button className="primary" disabled={lan.status !== 'connected'} onClick={submit}>{tab === 'create' ? 'СОЗДАТЬ' : 'ВОЙТИ'}</button>
      <button className="secondary" onClick={() => { lanClient.disconnect(); setScreen('menu') }}>НАЗАД</button>
    </div>
  </div>
}

export function LanLobby() {
  const lan = useGame((s) => s.lan)
  const state = useGame((s) => s.state)
  const room = lan.room
  const [now, setNow] = useState(Date.now())
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 100); return () => clearInterval(timer) }, [])
  if (!room) return null
  const me = room.players.find((p) => p.id === lan.id)
  const host = room.hostId === lan.id
  const canStart = room.players.length >= 2 && room.players.every((p) => p.ready && p.connected)
  const share = `${location.origin}/?room=${room.code}`
  const paints = useGame.getState().engine?.paints || []
  const selectedColor = me?.color || paints[state?.colors?.[me?.car] || 0]?.color || '#9cbd0a'
  return <div className="screen panel-screen lan-screen"><LanHeader title="LAN КОМНАТА" back={() => lanClient.leave()} />
    <div className="lan-lobby">
      <section className="glass lan-lobby-main"><div className="eyebrow">{room.name}</div><h1>КОМНАТА {room.code}</h1><p className="lan-share">Поделитесь адресом: <strong>{share}</strong></p>
        <div className="lan-players">{room.players.map((p) => <div key={p.id} className="lan-player-row"><b>{p.nickname}{p.host && <small> ХОСТ</small>}</b><span>{carName(p.car)}</span><em className={p.ready ? 'ready' : ''}>{!p.connected ? 'НЕТ СВЯЗИ' : p.ready ? 'ГОТОВ' : 'ОЖИДАЕТ'}</em></div>)}{Array.from({ length: Math.max(0, room.config.maxPlayers - room.players.length) }, (_, i) => <div key={`empty-${i}`} className="lan-player-row empty">СВОБОДНОЕ МЕСТО</div>)}</div>
        <h3>ВЫБЕРИТЕ МАШИНУ · ВСЕ ОТКРЫТЫ</h3><div className="lan-cars">{['m4', 'g63', 'r34', '911'].map((id) => <button key={id} className={me?.car === id ? 'selected' : ''} onClick={() => lanClient.select(id, selectedColor, me?.light)}>{carName(id)}</button>)}</div>
        <div className="lan-swatches">{paints.map((paint) => <button key={paint.color} title={paint.name} aria-label={paint.name} className={selectedColor === paint.color ? 'selected' : ''} style={{ background: paint.color }} onClick={() => lanClient.select(me?.car || 'm4', paint.color, me?.light)} />)}</div>
        <label className="lan-light">Цвет фар <input type="color" value={me?.light || '#fff4dc'} onChange={(e) => lanClient.select(me?.car || 'm4', selectedColor, e.target.value)} /></label>
        {lan.error && <p className="error" role="alert">{lan.error}</p>}
        {room.stage === 'countdown' ? <div className="lan-countdown">{Math.max(1, Math.ceil((lan.countdownAt - now) / 1000))}</div> : <div className="lan-actions"><button className="primary" onClick={() => lanClient.ready(!me?.ready)}>{me?.ready ? 'ОТМЕНИТЬ ГОТОВНОСТЬ' : 'Я ГОТОВ'}</button>{host && <button className="primary" disabled={!canStart} onClick={() => lanClient.start()}>НАЧАТЬ ЗАЕЗД</button>}<button className="secondary" onClick={() => lanClient.leave()}>ПОКИНУТЬ</button></div>}
      </section>
      {host && <section className="glass lan-config"><h2>НАСТРОЙКИ ХОСТА</h2>{[['difficulty', 'Сложность'], ['density', 'Плотность потока']].map(([key, label]) => <label key={key}>{label}<select value={room.config[key]} onChange={(e) => lanClient.configure({ [key]: Number(e.target.value) })}>{[0.8, 1, 1.2, 1.4].map((n) => <option key={n} value={n}>{Math.round(n * 100)}%</option>)}</select></label>)}<label>Максимум игроков<select value={room.config.maxPlayers} onChange={(e) => lanClient.configure({ maxPlayers: Number(e.target.value) })}>{[2, 3, 4].map((n) => <option key={n} value={n}>{n}</option>)}</select></label><label>Отсчёт<select value={room.config.countdown} onChange={(e) => lanClient.configure({ countdown: Number(e.target.value) })}>{[3, 5, 10].map((n) => <option key={n} value={n}>{n} с</option>)}</select></label><label className="check"><input type="checkbox" checked={room.config.nitro} onChange={(e) => lanClient.configure({ nitro: e.target.checked })} /> Нитро</label></section>}
    </div>
  </div>
}

export function LanResults() {
  const lan = useGame((s) => s.lan)
  const results = lan.results
  const host = lan.room?.hostId === lan.id
  if (!results) return null
  const winner = results.ranking.find((p) => p.id === results.winnerId)
  return <div className="screen results-screen lan-results"><div className="results-panel glass"><div className="eyebrow">LAN SURVIVAL · РЕЗУЛЬТАТ</div><h1>{winner ? `ПОБЕДИЛ ${winner.nickname}` : 'НИЧЬЯ'}</h1><p>{winner ? carName(winner.car) : 'Все оставшиеся игроки выбыли одновременно'} · {fmt(results.elapsed)}</p>
    <div className="lan-ranking">{results.ranking.map((p) => <div key={p.id}><b>#{p.rank} {p.nickname}</b><span>{carName(p.car)}</span><span>{fmt(p.survival)}</span><small>{p.score} очков · {p.maxSpeed} км/ч · {p.overtakes} обгонов · {p.nearMisses} впритык</small></div>)}</div>
    <div className="dialog-actions">{host && <><button className="primary" onClick={() => lanClient.playAgain()}>ЕЩЁ РАЗ</button><button className="secondary" onClick={() => lanClient.rematch()}>В ЛОББИ</button></>}<button className="secondary" onClick={() => lanClient.leave()}>ПОКИНУТЬ КОМНАТУ</button></div>
    {!host && <p>Хост может запустить повторный заезд.</p>}</div></div>
}

export function LanLost() {
  const lan = useGame((s) => s.lan)
  const setScreen = useGame((s) => s.setScreen)
  return <div className="screen results-screen"><div className="results-panel glass"><div className="eyebrow">LAN MULTIPLAYER</div><h1>СВЯЗЬ ПОТЕРЯНА</h1><p>{lan.error || 'Сервер недоступен. Матч без него не продолжается.'}</p><div className="dialog-actions"><button className="primary" onClick={() => { lanClient.retry = 0; lanClient.connect(); setScreen('lanMenu') }}>ПОВТОРИТЬ</button><button className="secondary" onClick={() => { lanClient.disconnect(); setScreen('menu') }}>В МЕНЮ</button></div></div></div>
}

export { fmt as lanTime }
