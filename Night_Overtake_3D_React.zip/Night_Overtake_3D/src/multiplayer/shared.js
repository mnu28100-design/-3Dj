// The same balanced LAN movement rules run on the server and in client prediction.
export const LAN_CARS = ['m4', 'g63', '911', 'r34']
export const LANES = [-5.4, -1.8, 1.8, 5.4]
export const PLAYER_WIDTH = 1.9
export const PLAYER_LENGTH = 4.5
export const TICK = 1 / 30
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

export function spectatorTarget(players, currentId, delta = 0) {
  const alive = players.filter((player) => player.alive)
  if (!alive.length) return null
  const current = alive.findIndex((player) => player.id === currentId)
  if (!delta) return current >= 0 ? currentId : alive[0].id
  return alive[(current + delta + alive.length) % alive.length].id
}

export function createVehicle(index = 0) {
  return { x: LANES[index % LANES.length], vx: 0, d: 0, speed: 130, nitro: 1,
    alive: true, survival: 0, maxSpeed: 130, overtakes: 0, nearMisses: 0, score: 0,
    input: { steering: 0, throttle: 0, brake: 0, nitro: false }, lastSequence: -1 }
}

export function stepVehicle(vehicle, input, dt, nitroEnabled = true) {
  const boost = !!input.nitro && nitroEnabled && vehicle.nitro > 0.02
  const target = 105 + input.throttle * 135 - input.brake * 95 + (boost ? 32 : 0)
  vehicle.speed += (target - vehicle.speed) * Math.min(1, dt * (input.brake ? 1.7 : boost ? 1.5 : 0.8))
  vehicle.speed = clamp(vehicle.speed, 25, 272)
  vehicle.vx += (input.steering * (12 - vehicle.speed / 100) - vehicle.vx) * Math.min(1, dt * 6)
  vehicle.x = clamp(vehicle.x + vehicle.vx * dt, -6.25, 6.25)
  if (Math.abs(vehicle.x) >= 6.25) vehicle.vx = 0
  vehicle.d += vehicle.speed / 3.6 * dt
  vehicle.nitro = clamp(vehicle.nitro + (boost ? -0.28 : 0.05) * dt, 0, 1)
  vehicle.survival += dt
  vehicle.maxSpeed = Math.max(vehicle.maxSpeed, vehicle.speed)
}

export function trafficDifficulty(seconds, multiplier = 1) {
  const stage = seconds < 60 ? 1 : seconds < 120 ? 2 : seconds < 180 ? 3 : seconds < 300 ? 4 : 5
  const extra = Math.min(0.4, Math.max(0, seconds - 300) / 600)
  return {
    stage,
    spawnInterval: clamp((1.8 - (stage - 1) * 0.27 - extra) / multiplier, 0.48, 2.4),
    maxTraffic: Math.min(24, Math.round((8 + stage * 3 + extra * 6) * multiplier)),
  }
}
