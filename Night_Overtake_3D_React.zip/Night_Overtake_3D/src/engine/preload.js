const IDS = ['m4', 'g63', 'r34', 'po']

export async function preloadModels(onProgress) {
  const sizes = await Promise.all(IDS.map(async (id) => {
    try {
      const response = await fetch(`/models/${id}.json`, { method: 'HEAD' })
      return Number(response.headers.get('content-length')) || 0
    } catch { return 0 }
  }))
  const knownTotal = sizes.every(Boolean) ? sizes.reduce((a, b) => a + b, 0) : 0
  let finishedBytes = 0
  const models = {}
  for (let i = 0; i < IDS.length; i++) {
    const id = IDS[i]
    const response = await fetch(`/models/${id}.json`)
    if (!response.ok) throw new Error(`Модель ${id}: HTTP ${response.status}`)
    let text
    if (response.body && response.body.getReader) {
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let bytes = 0
      text = ''
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        bytes += value.byteLength
        text += decoder.decode(value, { stream: true })
        onProgress({ loaded: i, total: IDS.length, name: id.toUpperCase(), percent: knownTotal ? Math.min(99, Math.round((finishedBytes + bytes) / knownTotal * 100)) : null })
      }
      text += decoder.decode()
      finishedBytes += bytes
    } else {
      text = await response.text()
      finishedBytes += new TextEncoder().encode(text).byteLength
    }
    let data
    try { data = JSON.parse(text) } catch { throw new Error(`Модель ${id} повреждена: JSON`) }
    if (typeof data.b !== 'string' || atob(data.b.slice(0, 32)).slice(0, 4) !== 'glTF') {
      throw new Error(`Модель ${id} повреждена: GLB`)
    }
    models[id === 'po' ? '911' : id] = text
    onProgress({ loaded: i + 1, total: IDS.length, name: id.toUpperCase(), percent: knownTotal ? Math.min(100, Math.round(finishedBytes / knownTotal * 100)) : null })
  }
  return models
}
