import * as Three from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
const THREE = { ...Three, GLTFLoader };
window.THREE = THREE;

(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var game = $('game'), toastEl = $('toast');
  function toast(msg, ms) {
    toastEl.textContent = msg; toastEl.classList.add('show');
    clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.classList.remove('show'); }, ms || 2600);
  }
  if (!window.THREE) { toast('Не удалось загрузить 3D-движок. Проверьте соединение и откройте страницу заново.', 8000); return; }
  var T = THREE;
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function fnum(n) { return String(n).replace('.', ','); }
  function fint(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }
  function cut() { var f = $('fade'); f.classList.remove('go'); void f.offsetWidth; f.classList.add('go'); }

  /* ---------- cars: names and figures from manufacturers / public sources ---------- */
  var CARS = [
    { id: 'm4', brand: 'BMW', name: 'M4 Competition xDrive', gen: 'Купе · G82 · обвес Adro · Stage 4', shape: 'm4', engine: '3,0 л, рядная «шестёрка», две большие турбины (тюнинг), 8-ступенчатый автомат', hp: 1030, nm: 1250, t100: 2.2, vmax: 345, kg: 1800, drive: 'Полный', price: 0, spoiler: 'duck', roof: 'carbon', plate: 'M4 777', blackRims: true, grille: true, model: 'models/m4.json', exh: [[-0.39, 0.21], [-0.27, 0.21], [0.27, 0.21], [0.39, 0.21]], exr: 0.045, snd: { cyl: 6, fr: 230, tau: 0.0032, rasp: 0.8, rough: 0.12, uneven: 0.03, pair: 0, body: 0.5, nfc: 2500, seed: 11, lo: 2200, hi: 7300, vol: 1, turbo: 1, wh: 2600, whv: 0.035, intake: 0.5, pop: 1, bov: 0.8, flutter: 0 } },
    { id: 'g63', brand: 'Mercedes-AMG', name: 'G 63', gen: 'Внедорожник · W463 · 2020 · Stage 4', shape: 'brick', engine: '4,0 л, V8, увеличенные турбины (тюнинг), 9-ступенчатый автомат', hp: 1180, nm: 1500, t100: 2.7, vmax: 295, kg: 2485, drive: 'Полный', price: 1200, spoiler: 'none', roof: 'paint', plate: 'G 585', model: 'models/g63.json', exh: [[-0.64, 0.36], [0.64, 0.36]], exr: 0.06, snd: { cyl: 12, fr: 170, tau: 0.0038, rasp: 0.45, rough: 0.05, uneven: 0, pair: 0, body: 0.95, nfc: 1700, seed: 23, lo: 1800, hi: 6200, vol: 1.15, turbo: 1, wh: 1800, whv: 0.02, intake: 0.4, pop: 1.2, bov: 0.7, flutter: 0 } },
    { id: 'r34', brand: 'Nissan', name: 'Skyline GT-R', gen: 'Купе · R34 · «Двойной форсаж» · Stage 4', shape: 'coupe', engine: '2,6 л, рядная «шестёрка» RB26, две большие турбины (тюнинг), 6-ступенчатая механика', hp: 1010, nm: 1250, t100: 2.1, vmax: 345, kg: 1540, drive: 'Полный', price: 1500, spoiler: 'wing', roof: 'paint', plate: 'R34 GTR', model: 'models/r34.json', fixedPaint: true, exh: [[-0.4, 0.34]], exr: 0.065, snd: { cyl: 6, fr: 280, tau: 0.0028, rasp: 1.0, rough: 0.15, uneven: 0.03, pair: 0, body: 0.45, nfc: 3000, seed: 37, lo: 2600, hi: 8000, vol: 1, turbo: 1, wh: 3400, whv: 0.045, intake: 0.5, pop: 0.95, bov: 1, flutter: 1 } },
    { id: '911', brand: 'Porsche', name: '911 GT3 Touring', gen: 'Купе · 992 · 2022 · Stage 4', shape: 'gt', engine: '4,0 л, оппозитная «шестёрка», две турбины (тюнинг), 6-ступенчатая механика', hp: 1050, nm: 1250, t100: 2.3, vmax: 355, kg: 1418, drive: 'Задний', price: 1900, spoiler: 'duck', roof: 'paint', plate: 'GT3', model: 'models/po.json', exh: [[-0.064, 0.29], [0.06, 0.29]], exr: 0.05, snd: { cyl: 6, fr: 330, tau: 0.0024, rasp: 0.7, rough: 0.08, uneven: 0.02, pair: 0, body: 0.6, nfc: 3600, seed: 51, lo: 3200, hi: 8800, vol: 0.95, turbo: 1, wh: 2900, whv: 0.03, intake: 1.0, pop: 1.0, bov: 0.7, flutter: 0 } }
  ];
  var SHORT = { m4: 'M4', g63: 'G 63', r34: 'GT-R', '911': 'GT3' };
  var PAINT_COLORS = [0x1d4fb8, 0xc4161c, 0xe8ebef, 0x59616d, 0xe0b000, 0x0c0e12, 0x1f7a4d, 0xe0620f, 0x9cbd0a];
  var PAINT_NAMES = ['Синий металлик', 'Красный', 'Белый', 'Графит', 'Жёлтый', 'Чёрный', 'Зелёный', 'Оранжевый', 'Сан-Паулу (лайм)'];
  function carById(id) { for (var i = 0; i < CARS.length; i++) if (CARS[i].id === id) return CARS[i]; return CARS[0]; }
  function perf(c) {
    return {
      top: Math.min(c.vmax, 300),
      accel: clamp(5.2 / (c.t100 + 1.5), 0.6, 1.5),
      agile: clamp(Math.sqrt(1700 / c.kg), 0.82, 1.12) * (c.shape === 'brick' ? 0.94 : 1)
    };
  }

  /* ---------- save ---------- */
  var KEY = 'nochnoj-obgon-3d';
  var save = { version: 3, best: 0, total: 0, ctrl: 'wheel', sound: true, quality: 'auto', owned: ['m4'], sel: 'm4', colors: {}, matte: {}, qv: 2, track: 'night', level: 1, stars: {}, drive: 'sport', lights: {}, neon: {}, rims: {} };
  try {
    var sv = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (sv && typeof sv === 'object') {
      save.best = Number.isFinite(+sv.best) ? clamp(+sv.best, 0, 1e9) : 0;
      save.total = Number.isFinite(+sv.total) ? clamp(+sv.total, 0, 1e9) : 0;
      save.sound = sv.sound !== false;
      if (sv.ctrl === 'wheel' || sv.ctrl === 'arrows' || sv.ctrl === 'tilt') save.ctrl = sv.ctrl;
      if (sv.qv === 2 && ['auto', 'low', 'medium', 'high', 'ultra'].includes(sv.quality)) save.quality = sv.quality;
      if (Array.isArray(sv.owned)) save.owned = Array.from(new Set(sv.owned.filter(function (x) { return typeof x === 'string' && CARS.some(function (c) { return c.id === x; }); })));
      if (save.owned.indexOf('m4') < 0) save.owned.push('m4');
      if (typeof sv.track === 'string') save.track = sv.track;
      if (sv.drive === 'drift') save.drive = 'drift';
      if (+sv.level >= 1) save.level = Math.min(50, sv.level | 0);
      if (sv.stars && typeof sv.stars === 'object') save.stars = sv.stars;
      if (typeof sv.sel === 'string' && save.owned.indexOf(sv.sel) >= 0) save.sel = sv.sel;
      if (sv.colors && typeof sv.colors === 'object') save.colors = sv.colors;
      if (sv.matte && typeof sv.matte === 'object') save.matte = sv.matte;
      if (sv.lights && typeof sv.lights === 'object') save.lights = sv.lights;
      if (sv.neon && typeof sv.neon === 'object') save.neon = sv.neon;
      if (sv.rims && typeof sv.rims === 'object') save.rims = sv.rims;
    }
  } catch (e) {}
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch (e) {} }
  var autoLevel = 'high', fpsCap = 0, lastRender = 0, fpsSamples = 0, fpsElapsed = 0, paused = false, gameType = 'classic', testId = null, driftScore = 0, driftTime = 90, cameraMode = 'chase', steerSensitivity = 1;
  var graphics = { resolution: 1, pixelRatioCap: 2.5, particles: 1, drawDistance: 900, traffic: 1, lighting: true, shadows: 'off', antialias: true };
  try { graphics = Object.assign(graphics, JSON.parse(localStorage.getItem('night-graphics-v3') || '{}')); } catch (e) {}
  graphics.resolution = clamp(+graphics.resolution || 1, 0.65, 1.25);
  graphics.pixelRatioCap = clamp(+graphics.pixelRatioCap || 2.5, 0.75, 3);
  graphics.particles = clamp(+graphics.particles || 1, 0.25, 1);
  graphics.drawDistance = clamp(+graphics.drawDistance || 900, 300, 1500);
  graphics.traffic = clamp(+graphics.traffic || 1, 0.8, 1.8);
  graphics.lighting = graphics.lighting !== false;
  graphics.antialias = graphics.antialias !== false;
  if (!['off', 'low', 'high'].includes(graphics.shadows)) graphics.shadows = 'off';
  try { fpsCap = +localStorage.getItem('night-fps-cap') || 0; steerSensitivity = +localStorage.getItem('night-steer') || 1; } catch (e) {}
  var audioMix = { master: 1, engine: 1, effects: 1, ui: 1, music: 1 };
  try { audioMix = Object.assign(audioMix, JSON.parse(localStorage.getItem('night-audio-v2') || '{}')); } catch (e) {}
  Object.keys(audioMix).forEach(function (key) { audioMix[key] = Number.isFinite(+audioMix[key]) ? clamp(+audioMix[key], 0, 1) : 1; });
  function effectiveQuality() { return save.quality === 'auto' ? autoLevel : save.quality; }
  function owned(id) { return save.owned.indexOf(id) >= 0; }
  function colorOf(id) { var c = save.colors[id]; if (c === undefined) return id === 'm4' ? 8 : id === 'g63' ? 5 : id === '911' ? 1 : 0; return clamp(+c || 0, 0, PAINT_COLORS.length - 1); }

  /* ---------- renderer / scene ---------- */
  var renderer;
  try {
    renderer = new T.WebGLRenderer({ canvas: $('gl'), antialias: graphics.antialias, powerPreference: 'high-performance' });
  } catch (e) { toast('Ваш браузер не поддерживает WebGL, 3D-режим не запустится.', 8000); return; }
  renderer.outputEncoding = T.sRGBEncoding;
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.15;
  var FOGC = 0x060a12;
  var scene = new T.Scene();
  scene.background = new T.Color(FOGC);
  scene.fog = new T.FogExp2(FOGC, 0.0055);
  var camera = new T.PerspectiveCamera(65, 1, 0.1, 1500);
  var baseFov = 65, voKey = '', voOn = false;
  function resize() {
    var w = Math.max(1, game.clientWidth), h = Math.max(1, game.clientHeight);
    var dpr = window.devicePixelRatio || 1, q = effectiveQuality(), pr = q === 'ultra' ? Math.min(2.5, Math.max(dpr, 1.5)) : q === 'high' ? Math.min(dpr, 1.8) : q === 'medium' ? Math.min(dpr, 1.35) : Math.min(dpr, 1);
    pr = Math.min(pr * graphics.resolution, graphics.pixelRatioCap, Math.sqrt(8.3e6 / (w * h)));
    renderer.setPixelRatio(Math.max(0.75, pr));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.far = graphics.drawDistance;
    baseFov = clamp(2 * Math.atan(Math.tan(33 * Math.PI / 180) / camera.aspect) * 180 / Math.PI, 50, 84);
    voKey = '';
  }
  window.addEventListener('resize', resize);
  if (window.ResizeObserver) new ResizeObserver(resize).observe(game);
  resize();

  function canvasTex(w, h, draw, repeat, linear) {
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    var t = new T.CanvasTexture(c);
    if (!linear) t.encoding = T.sRGBEncoding;
    if (repeat) t.wrapS = t.wrapT = T.RepeatWrapping;
    t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    return t;
  }
  function radialTex(inner, outer) {
    return canvasTex(128, 128, function (g, w, h) {
      var gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
      gr.addColorStop(0, inner); gr.addColorStop(1, outer);
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    });
  }

  // reflection environments: night road and studio
  var envRoad, envGarage;
  (function () {
    var pm = new T.PMREMGenerator(renderer);
    function env(draw) {
      var tex = canvasTex(1024, 512, draw);
      tex.mapping = T.EquirectangularReflectionMapping;
      return pm.fromEquirectangular(tex).texture;
    }
    envRoad = env(function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#04070d'); gr.addColorStop(0.42, '#16233a'); gr.addColorStop(0.52, '#b9803f');
      gr.addColorStop(0.58, '#2a2d36'); gr.addColorStop(1, '#06080c');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      g.fillStyle = '#fff1d2';
      for (var i = 0; i < 14; i++) g.fillRect((i / 14) * w + 10, h * 0.2, 70, 10);
      g.fillStyle = '#9ec4ff';
      for (i = 0; i < 6; i++) g.fillRect((i / 6) * w + 60, h * 0.1, 120, 6);
    });
    envGarage = env(function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#0b0f16'); gr.addColorStop(0.5, '#1b222d'); gr.addColorStop(0.55, '#0c1016'); gr.addColorStop(1, '#05070a');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      var boxes = [[40, 20, 330, 150], [420, 10, 340, 120], [800, 30, 200, 160], [180, 200, 220, 46], [600, 205, 260, 40]];
      boxes.forEach(function (b, i) {
        var bg = g.createLinearGradient(b[0], b[1], b[0], b[1] + b[3]);
        bg.addColorStop(0, '#ffffff'); bg.addColorStop(1, i % 2 ? '#cfe0ff' : '#fff0d8');
        g.fillStyle = bg; g.fillRect(b[0], b[1], b[2], b[3]);
      });
      g.fillStyle = '#e8f0ff';
      for (var i = 0; i < 8; i++) g.fillRect(i * 128 + 20, 250, 8, 120);
    });
    pm.dispose();
  })();
  scene.environment = envRoad;

  var hemi = new T.HemisphereLight(0x4a6fa5, 0x0a0d12, 0.55); scene.add(hemi);
  var moon = new T.DirectionalLight(0x8fb2ff, 0.4); moon.position.set(-20, 30, 10); scene.add(moon);
  var world = new T.Group(); scene.add(world);

  /* ---------- world: road, rails, scenery ---------- */
  var LANE_W = 3.6, HALF = 7.2, NL = 4, RLEN = 520;
  function laneX(i) { return -HALF + LANE_W * (i + 0.5); }

  var roadTex = canvasTex(512, 1024, function (g, w, h) {
    g.fillStyle = '#222a35'; g.fillRect(0, 0, w, h);
    var i, x, y;
    for (i = 0; i < 70000; i++) {
      x = Math.random() * w; y = Math.random() * h;
      g.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.08)';
      g.fillRect(x, y, 1.5, 1.5);
    }
    g.fillStyle = 'rgba(0,0,0,0.13)';
    for (i = 0; i < 4; i++) { g.fillRect(i * 128 + 26, 0, 22, h); g.fillRect(i * 128 + 80, 0, 22, h); }
    g.fillStyle = 'rgba(238,243,250,0.88)';
    g.fillRect(w - 17, 0, 9, h);
    g.fillStyle = 'rgba(240,190,45,0.95)'; g.fillRect(2, 0, 7, h); g.fillRect(15, 0, 7, h);
    g.fillStyle = 'rgba(238,243,250,0.88)';
    for (i = 1; i < 4; i++) g.fillRect(i * 128 - 4, 0, 8, 256);
  }, true);
  roadTex.repeat.set(1, RLEN / 12);
  // wet asphalt: puddles and tyre tracks are glossy, dry patches are rough
  var roughTex = canvasTex(512, 1024, function (g, w, h) {
    g.fillStyle = '#d2d2d2'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#9a9a9a';
    var i;
    for (i = 0; i < 4; i++) { g.fillRect(i * 128 + 24, 0, 26, h); g.fillRect(i * 128 + 78, 0, 26, h); }
    for (i = 0; i < 70; i++) {
      var x = Math.random() * w, y = Math.random() * h, r = 14 + Math.random() * 60;
      var rg = g.createRadialGradient(x, y, 0, x, y, r);
      rg.addColorStop(0, 'rgba(24,24,24,0.95)'); rg.addColorStop(0.7, 'rgba(40,40,40,0.5)'); rg.addColorStop(1, 'rgba(40,40,40,0)');
      g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2);
    }
  }, true, true);
  var road = new T.Mesh(new T.PlaneGeometry(HALF * 2, RLEN), new T.MeshStandardMaterial({ map: roadTex, roughnessMap: roughTex, roughness: 1, metalness: 0.15, envMapIntensity: 1.15 }));
  road.rotation.x = -Math.PI / 2; road.position.set(0, 0, -230); road.receiveShadow = true; world.add(road);
  // oncoming carriageway: two lanes to the left, separated by a double yellow line only
  function laneXO(i) { return -HALF - LANE_W * (i + 0.5); }
  var ONC_EDGE = -(HALF + 2 * LANE_W);
  var roadTex2 = canvasTex(256, 1024, function (g, w, h) {
    g.fillStyle = '#222a35'; g.fillRect(0, 0, w, h);
    var i;
    for (i = 0; i < 35000; i++) { g.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.08)'; g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5); }
    g.fillStyle = 'rgba(0,0,0,0.13)';
    for (i = 0; i < 2; i++) { g.fillRect(i * 128 + 26, 0, 22, h); g.fillRect(i * 128 + 80, 0, 22, h); }
    g.fillStyle = 'rgba(238,243,250,0.88)'; g.fillRect(8, 0, 9, h); g.fillRect(124, 0, 8, 256);
  }, true);
  roadTex2.repeat.set(1, RLEN / 12);
  var roughTex2 = roughTex.clone(); roughTex2.needsUpdate = true; roughTex2.repeat.set(0.5, RLEN / 12);
  var road2 = new T.Mesh(new T.PlaneGeometry(LANE_W * 2, RLEN), new T.MeshStandardMaterial({ map: roadTex2, roughnessMap: roughTex2, roughness: 1, metalness: 0.15, envMapIntensity: 1.15 }));
  road2.rotation.x = -Math.PI / 2; road2.position.set(-HALF - LANE_W, 0.001, -230); road2.receiveShadow = true; world.add(road2);

  var shoulderMat = new T.MeshStandardMaterial({ color: 0x12171e, roughness: 1 });
  [-1, 1].forEach(function (s) {
    var m = new T.Mesh(new T.PlaneGeometry(1.4, RLEN), shoulderMat);
    m.rotation.x = -Math.PI / 2; m.position.set(s < 0 ? ONC_EDGE - 0.7 : HALF + 0.7, 0.005, -230); world.add(m);
  });
  var ground = new T.Mesh(new T.PlaneGeometry(900, RLEN + 200), new T.MeshStandardMaterial({ color: 0x07110c, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.position.set(0, -0.03, -230); world.add(ground);

  var railTex = canvasTex(256, 64, function (g, w, h) {
    var gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#59636f'); gr.addColorStop(0.5, '#aab4bf'); gr.addColorStop(1, '#4a535e');
    g.fillStyle = gr; g.fillRect(0, 8, w, 34);
    g.fillStyle = '#30363f'; g.fillRect(0, 0, 14, h);
    g.fillStyle = '#c8452f'; g.fillRect(70, 18, 28, 8);
  }, true);
  railTex.repeat.set(RLEN / 4, 1);
  var railL = new T.Mesh(new T.PlaneGeometry(RLEN, 0.7), new T.MeshStandardMaterial({ map: railTex, metalness: 0.55, roughness: 0.4, side: T.DoubleSide }));
  railL.rotation.y = Math.PI / 2; railL.position.set(ONC_EDGE - 1.4, 0.62, -230); world.add(railL);
  var railTexR = railTex.clone(); railTexR.needsUpdate = true; railTexR.repeat.set(RLEN / 4, 1);
  var railR = new T.Mesh(new T.PlaneGeometry(RLEN, 0.7), new T.MeshStandardMaterial({ map: railTexR, metalness: 0.55, roughness: 0.4, side: T.DoubleSide }));
  railR.rotation.y = -Math.PI / 2; railR.position.set(HALF + 1.4, 0.62, -230); world.add(railR);

  // street lamps with wet-road reflections
  var LAMP_N = 12, LAMP_GAP = 40, lamps = [], streaks = [];
  var poleMat = new T.MeshStandardMaterial({ color: 0x2a313b, metalness: 0.6, roughness: 0.5 });
  var lampHeadMat = new T.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffc878, emissiveIntensity: 2.4 });
  var glowMat = new T.MeshBasicMaterial({ map: radialTex('rgba(255,190,100,0.65)', 'rgba(255,190,100,0)'), transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  var streakTex = canvasTex(32, 256, function (g, w, h) {
    var gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, 'rgba(255,196,120,0.55)'); gr.addColorStop(1, 'rgba(255,196,120,0)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    var hg = g.createLinearGradient(0, 0, w, 0);
    hg.addColorStop(0, 'rgba(0,0,0,1)'); hg.addColorStop(0.5, 'rgba(0,0,0,0)'); hg.addColorStop(1, 'rgba(0,0,0,1)');
    g.globalCompositeOperation = 'destination-out'; g.fillStyle = hg; g.fillRect(0, 0, w, h);
  });
  var streakMat = new T.MeshBasicMaterial({ map: streakTex, transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  var poleGeo = new T.CylinderGeometry(0.1, 0.14, 9, 8), armGeo = new T.BoxGeometry(3.2, 0.12, 0.12), headGeo = new T.BoxGeometry(0.9, 0.14, 0.4), glowGeo = new T.PlaneGeometry(22, 22), streakGeo = new T.PlaneGeometry(1.8, 22);
  for (var li = 0; li < LAMP_N * 2; li++) {
    (function (i) {
      var side = i % 2 === 0 ? -1 : 1, g = new T.Group();
      var pole = new T.Mesh(poleGeo, poleMat); pole.position.y = 4.5; g.add(pole);
      var arm = new T.Mesh(armGeo, poleMat); arm.position.set(-side * 1.5, 9, 0); g.add(arm);
      var head = new T.Mesh(headGeo, lampHeadMat); head.position.set(-side * 2.9, 8.95, 0); g.add(head);
      var glow = new T.Mesh(glowGeo, glowMat); glow.rotation.x = -Math.PI / 2; glow.position.set(-side * 4.4, 0.04, 0); g.add(glow);
      var st = new T.Mesh(streakGeo, streakMat); st.rotation.x = -Math.PI / 2; st.position.set(-side * 3.6, 0.05, 11); g.add(st); streaks.push(st);
      g.position.set(side < 0 ? ONC_EDGE - 2.2 : HALF + 2.2, 0, 30 - Math.floor(i / 2) * LAMP_GAP - (side > 0 ? LAMP_GAP / 2 : 0));
      world.add(g); lamps.push(g);
    })(li);
  }
  var LAMP_SPAN = LAMP_N * LAMP_GAP;

  var skyDome, horizonGlow, skyCache = {};
  // dense pine forest: three instanced cone layers
  var TREE_N = 90, TREE_GAP = 12, TREE_SPAN = TREE_N / 2 * TREE_GAP, treeData = [], treeLayers = [], tmpObj = new T.Object3D();
  (function () {
    var geos = [new T.ConeGeometry(2.5, 5.5, 8), new T.ConeGeometry(1.95, 4.6, 8), new T.ConeGeometry(1.35, 3.6, 8)];
    var ys = [2.9, 5.4, 7.6], cols = [0x0b2216, 0x0f2c1c, 0x143823];
    for (var k = 0; k < 3; k++) {
      geos[k].translate(0, ys[k], 0);
      var im = new T.InstancedMesh(geos[k], new T.MeshStandardMaterial({ color: cols[k], roughness: 1, envMapIntensity: 0.3 }), TREE_N);
      im.frustumCulled = false; world.add(im); treeLayers.push(im);
    }
    for (var i = 0; i < TREE_N; i++) {
      treeData.push({ x: (i % 2 ? rand(11, 40) : -rand(20, 48)), z: 30 - (i >> 1) * TREE_GAP - Math.random() * 6, s: rand(0.8, 1.5), h: rand(0.9, 1.3) });
    }
  })();
  var treeSc = [1, 1];
  function updateTrees(v, dt) {
    var i, k;
    for (i = 0; i < TREE_N; i++) {
      var t = treeData[i];
      t.z += v * dt;
      if (t.z > 40) { t.z -= TREE_SPAN; t.x = (i % 2 ? rand(11, 40) : -rand(20, 48)); }
      tmpObj.position.set(t.x, 0, t.z); tmpObj.scale.set(t.s * treeSc[0], t.s * t.h * treeSc[1], t.s * treeSc[0]); tmpObj.updateMatrix();
      for (k = 0; k < 3; k++) treeLayers[k].setMatrixAt(i, tmpObj.matrix);
    }
    for (k = 0; k < 3; k++) treeLayers[k].instanceMatrix.needsUpdate = true;
  }

  (function () {
    var n = 500, pos = new Float32Array(n * 3);
    for (var i = 0; i < n; i++) {
      var a = Math.random() * Math.PI * 2, e = Math.random() * 1.2 + 0.08, r = 1100;
      pos[i * 3] = Math.cos(a) * Math.cos(e) * r; pos[i * 3 + 1] = Math.sin(e) * r * 0.7 + 20; pos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r;
    }
    var geo = new T.BufferGeometry(); geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    /* stars are painted into the sky dome below */
    var hz = canvasTex(512, 128, function (g, w, h) {
      var gr = g.createLinearGradient(0, h, 0, 0);
      gr.addColorStop(0, 'rgba(255,150,70,0.55)'); gr.addColorStop(0.35, 'rgba(120,80,110,0.25)'); gr.addColorStop(1, 'rgba(6,10,18,0)');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      g.fillStyle = 'rgba(255,220,160,0.9)';
      for (var i = 0; i < 260; i++) g.fillRect(Math.random() * w, h - 6 - Math.random() * 20, 1.6, 1.6);
    });
    var hm = new T.Mesh(new T.PlaneGeometry(1800, 240), new T.MeshBasicMaterial({ map: hz, transparent: true, depthWrite: false, fog: false }));
    hm.position.set(0, 80, -1000); world.add(hm); horizonGlow = hm;
  })();

  // night sky with a Milky Way band
  (function () {
    var tex = canvasTex(2048, 1024, function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#01030a'); gr.addColorStop(0.35, '#050c1c'); gr.addColorStop(0.47, '#101a36');
      gr.addColorStop(0.5, '#3a2c3a'); gr.addColorStop(0.53, '#6a4636'); gr.addColorStop(0.58, '#1a1210'); gr.addColorStop(1, '#0a0808');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      function bandY(x) { return h * 0.3 + Math.sin(x / w * 6.283 + 0.6) * h * 0.1 + (x / w) * h * 0.08; }
      var i, x, y, r, a, rg;
      g.globalCompositeOperation = 'lighter';
      for (i = 0; i < 280; i++) {
        x = Math.random() * w; y = bandY(x) + (Math.random() - 0.5) * h * 0.16;
        r = 40 + Math.random() * 110; a = 0.03 + Math.random() * 0.05;
        rg = g.createRadialGradient(x, y, 0, x, y, r);
        rg.addColorStop(0, 'rgba(150,170,230,' + a + ')'); rg.addColorStop(1, 'rgba(150,170,230,0)');
        g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2);
      }
      g.globalCompositeOperation = 'source-over';
      for (i = 0; i < 40; i++) {
        x = Math.random() * w; y = bandY(x) + (Math.random() - 0.5) * h * 0.1; r = 20 + Math.random() * 50;
        rg = g.createRadialGradient(x, y, 0, x, y, r);
        rg.addColorStop(0, 'rgba(2,4,10,0.28)'); rg.addColorStop(1, 'rgba(2,4,10,0)');
        g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2);
      }
      for (i = 0; i < 9000; i++) {
        x = Math.random() * w;
        y = Math.random() < 0.6 ? bandY(x) + (Math.random() + Math.random() + Math.random() - 1.5) * h * 0.1 : Math.random() * h * 0.46;
        if (y < 0 || y > h * 0.48) continue;
        var b = Math.random(), sz = b > 0.97 ? 2.2 : b > 0.85 ? 1.4 : 0.9;
        g.fillStyle = 'rgba(255,255,255,' + (0.15 + b * b * 0.85).toFixed(2) + ')'; g.fillRect(x, y, sz, sz);
      }
    });
    var dome = new T.Mesh(new T.SphereGeometry(1200, 48, 24), new T.MeshBasicMaterial({ map: tex, side: T.BackSide, fog: false, depthWrite: false }));
    dome.renderOrder = -2; world.add(dome); skyDome = dome; skyCache.night = tex;
  })();


  /* ---------- tracks: scenery themes ---------- */
  function envTex(draw) {
    var pm = new T.PMREMGenerator(renderer), tex = canvasTex(1024, 512, draw);
    tex.mapping = T.EquirectangularReflectionMapping;
    var r = pm.fromEquirectangular(tex).texture; pm.dispose(); return r;
  }
  var envCache = { night: envRoad };
  function envFor(k) {
    if (envCache[k]) return envCache[k];
    var draws = {
      city: function (g, w, h) {
        var gr = g.createLinearGradient(0, 0, 0, h);
        gr.addColorStop(0, '#0a0618'); gr.addColorStop(0.45, '#3a1458'); gr.addColorStop(0.52, '#d0388c'); gr.addColorStop(0.58, '#241238'); gr.addColorStop(1, '#07040e');
        g.fillStyle = gr; g.fillRect(0, 0, w, h);
        var cols = ['#ff3cac', '#38e8ff', '#ffd23c', '#8a5cff'];
        for (var i = 0; i < 26; i++) { g.fillStyle = cols[i % 4]; g.fillRect((i / 26) * w + 6, h * (0.3 + (i % 3) * 0.06), 18 + (i % 4) * 14, 90 + (i % 5) * 20); }
        g.fillStyle = '#fff0ff'; for (i = 0; i < 6; i++) g.fillRect(i * 170 + 30, h * 0.12, 110, 8);
      },
      desert: function (g, w, h) {
        var gr = g.createLinearGradient(0, 0, 0, h);
        gr.addColorStop(0, '#27407a'); gr.addColorStop(0.35, '#8a6aa8'); gr.addColorStop(0.47, '#ff9a5a'); gr.addColorStop(0.53, '#8a4a2a'); gr.addColorStop(1, '#3a2014');
        g.fillStyle = gr; g.fillRect(0, 0, w, h);
        var sg = g.createRadialGradient(w * 0.75, h * 0.47, 0, w * 0.75, h * 0.47, 150);
        sg.addColorStop(0, 'rgba(255,250,220,1)'); sg.addColorStop(0.3, 'rgba(255,200,120,0.8)'); sg.addColorStop(1, 'rgba(255,150,60,0)');
        g.fillStyle = sg; g.fillRect(0, 0, w, h);
      },
      alps: function (g, w, h) {
        var gr = g.createLinearGradient(0, 0, 0, h);
        gr.addColorStop(0, '#3f78c0'); gr.addColorStop(0.4, '#a8cdf0'); gr.addColorStop(0.5, '#f1f6fb'); gr.addColorStop(0.56, '#d9e3ec'); gr.addColorStop(1, '#b9c6d3');
        g.fillStyle = gr; g.fillRect(0, 0, w, h);
        var sg = g.createRadialGradient(w * 0.7, h * 0.22, 0, w * 0.7, h * 0.22, 120);
        sg.addColorStop(0, 'rgba(255,255,240,1)'); sg.addColorStop(1, 'rgba(255,255,240,0)');
        g.fillStyle = sg; g.fillRect(0, 0, w, h);
      }
    };
    return (envCache[k] = envTex(draws[k]));
  }

  function skyFor(k) {
    if (skyCache[k]) return skyCache[k];
    var W = 2048, H = 1024;
    function ridge(g, base, amp, col, seedK, snow) {
      g.fillStyle = col; g.beginPath(); g.moveTo(0, base + 4);
      var pts = [], x;
      for (x = 0; x <= W; x += 16) {
        var yy = base - amp * (0.55 * Math.abs(Math.sin(x * 0.0061 * seedK + seedK)) + 0.3 * Math.abs(Math.sin(x * 0.017 * seedK + 2 * seedK)) + 0.15 * Math.abs(Math.sin(x * 0.043 + seedK)));
        pts.push([x, yy]); g.lineTo(x, yy);
      }
      g.lineTo(W, base + 4); g.closePath(); g.fill();
      if (snow) {
        g.fillStyle = 'rgba(255,255,255,0.92)';
        for (var i = 1; i < pts.length - 1; i++) if (pts[i][1] < base - amp * 0.55 && pts[i][1] <= pts[i - 1][1] && pts[i][1] <= pts[i + 1][1]) {
          g.beginPath(); g.moveTo(pts[i][0], pts[i][1]); g.lineTo(pts[i][0] - 34, pts[i][1] + 38); g.lineTo(pts[i][0] + 34, pts[i][1] + 38); g.closePath(); g.fill();
        }
      }
    }
    var tex;
    if (k === 'city') tex = canvasTex(W, H, function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#04030c'); gr.addColorStop(0.3, '#120a2a'); gr.addColorStop(0.44, '#3c1260'); gr.addColorStop(0.495, '#e0368e'); gr.addColorStop(0.5, '#1a0d2c'); gr.addColorStop(1, '#07040e');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      var i;
      for (i = 0; i < 1400; i++) { g.fillStyle = 'rgba(255,255,255,' + (0.2 + Math.random() * 0.6).toFixed(2) + ')'; g.fillRect(Math.random() * w, Math.random() * h * 0.38, 1.2, 1.2); }
      var hg = g.createRadialGradient(w * 0.75, h * 0.5, 0, w * 0.75, h * 0.5, 420);
      hg.addColorStop(0, 'rgba(255,90,200,0.55)'); hg.addColorStop(1, 'rgba(255,90,200,0)'); g.fillStyle = hg; g.fillRect(0, 0, w, h);
      for (var layer = 0; layer < 2; layer++) {
        var x = 0;
        while (x < w) {
          var bw = 20 + Math.random() * 46, bh = (layer ? 26 : 50) + Math.random() * (layer ? 60 : 110);
          g.fillStyle = layer ? '#0b0616' : '#150b26'; g.fillRect(x, h * 0.5 - bh, bw, bh + 2);
          g.fillStyle = layer ? 'rgba(255,214,120,0.55)' : 'rgba(120,230,255,0.4)';
          for (var wy = h * 0.5 - bh + 6; wy < h * 0.5 - 4; wy += 9) for (var wx = x + 4; wx < x + bw - 4; wx += 8) if (Math.random() < 0.35) g.fillRect(wx, wy, 3, 4);
          x += bw + Math.random() * 6;
        }
      }
    });
    else if (k === 'desert') tex = canvasTex(W, H, function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#1d2f66'); gr.addColorStop(0.2, '#47508f'); gr.addColorStop(0.33, '#9c6a9a'); gr.addColorStop(0.43, '#f0905c'); gr.addColorStop(0.485, '#ffd08a'); gr.addColorStop(0.5, '#c46a3a'); gr.addColorStop(1, '#6a3420');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      var sg = g.createRadialGradient(w * 0.75, h * 0.485, 0, w * 0.75, h * 0.485, 380);
      sg.addColorStop(0, 'rgba(255,252,230,1)'); sg.addColorStop(0.06, 'rgba(255,230,160,0.95)'); sg.addColorStop(0.25, 'rgba(255,170,90,0.45)'); sg.addColorStop(1, 'rgba(255,120,50,0)');
      g.fillStyle = sg; g.fillRect(0, 0, w, h);
      var i;
      for (i = 0; i < 26; i++) {
        var cx = Math.random() * w, cy = h * (0.2 + Math.random() * 0.22), rg = g.createRadialGradient(cx, cy, 0, cx, cy, 160);
        rg.addColorStop(0, 'rgba(255,170,130,0.30)'); rg.addColorStop(1, 'rgba(255,170,130,0)');
        g.save(); g.translate(cx, cy); g.scale(2.6, 0.32); g.translate(-cx, -cy); g.fillStyle = rg; g.fillRect(cx - 160, cy - 160, 320, 320); g.restore();
      }
      ridge(g, h * 0.5, 26, '#7a3a24', 1.7, false);
      var mx = 0;
      while (mx < w) { var mw = 50 + Math.random() * 120, mh = 18 + Math.random() * 46; g.fillStyle = '#5c2c1c'; g.fillRect(mx, h * 0.5 - mh, mw, mh + 2); g.fillRect(mx + 8, h * 0.5 - mh - 7, mw - 16, 8); mx += mw + 90 + Math.random() * 260; }
    });
    else tex = canvasTex(W, H, function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#2f6ab8'); gr.addColorStop(0.28, '#6aa6e2'); gr.addColorStop(0.43, '#bcdaf4'); gr.addColorStop(0.5, '#eef4fa'); gr.addColorStop(0.52, '#dfe8f0'); gr.addColorStop(1, '#c4d0dc');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      var sg = g.createRadialGradient(w * 0.7, h * 0.2, 0, w * 0.7, h * 0.2, 260);
      sg.addColorStop(0, 'rgba(255,255,245,1)'); sg.addColorStop(0.1, 'rgba(255,255,235,0.8)'); sg.addColorStop(1, 'rgba(255,255,235,0)');
      g.fillStyle = sg; g.fillRect(0, 0, w, h);
      for (var i = 0; i < 42; i++) {
        var cx = Math.random() * w, cy = h * (0.08 + Math.random() * 0.32), rr = 60 + Math.random() * 120, rg = g.createRadialGradient(cx, cy, 0, cx, cy, rr);
        rg.addColorStop(0, 'rgba(255,255,255,0.65)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
        g.save(); g.translate(cx, cy); g.scale(2.2, 0.5); g.translate(-cx, -cy); g.fillStyle = rg; g.fillRect(cx - rr, cy - rr, rr * 2, rr * 2); g.restore();
      }
      ridge(g, h * 0.5, 120, '#9fb6cf', 2.3, true);
      ridge(g, h * 0.5, 80, '#7d97b4', 3.1, true);
      ridge(g, h * 0.5, 40, '#587791', 4.3, false);
    });
    return (skyCache[k] = tex);
  }

  // city: instanced high-rises with lit windows
  var BLD_N = 66, BLD_GAP = 14, BLD_SPAN = BLD_N / 2 * BLD_GAP, bldData = [], bldMeshes = [];
  (function () {
    var classes = [{ h: 18, c: 0 }, { h: 34, c: 1 }, { h: 58, c: 2 }];
    classes.forEach(function (cl, ci) {
      var tex = canvasTex(128, 256, function (g, w, h) {
        g.fillStyle = '#05060b'; g.fillRect(0, 0, w, h);
        var neon = ['#ff4fb8', '#46e6ff', '#ffd54a', '#9c6bff'];
        for (var y = 6; y < h - 6; y += 16) for (var x = 6; x < w - 6; x += 16) {
          var r = Math.random();
          g.fillStyle = r < 0.42 ? 'rgba(255,214,140,' + (0.5 + Math.random() * 0.5).toFixed(2) + ')' : r < 0.5 ? neon[(Math.random() * 4) | 0] : '#0a0c14';
          g.fillRect(x, y, 10, 9);
        }
      }, true);
      tex.repeat.set(3, cl.h / 6);
      var geo = new T.BoxGeometry(1, cl.h, 1); geo.translate(0, cl.h / 2, 0);
      var m = new T.MeshStandardMaterial({ color: 0x14131f, roughness: 0.6, metalness: 0.4, emissive: 0xffffff, emissiveMap: tex, emissiveIntensity: 1.1 });
      var im = new T.InstancedMesh(geo, m, BLD_N / 3); im.frustumCulled = false; im.visible = false; world.add(im); bldMeshes.push(im);
    });
    for (var i = 0; i < BLD_N; i++) bldData.push({ x: (i % 2 ? rand(24, 62) : -rand(30, 68)), z: 30 - (i >> 1) * BLD_GAP - Math.random() * 6, w: rand(9, 16), d: rand(9, 16), c: i % 3, neon: i });
  })();
  function updateBuildings(v, dt) {
    var cnt = [0, 0, 0], i;
    for (i = 0; i < BLD_N; i++) {
      var b = bldData[i];
      b.z += v * dt;
      if (b.z > 40) { b.z -= BLD_SPAN; b.x = (i % 2 ? 1 : -1) * rand(24, 62); }
      tmpObj.position.set(b.x, 0, b.z); tmpObj.scale.set(b.w, 1, b.d); tmpObj.updateMatrix();
      bldMeshes[b.c].setMatrixAt(cnt[b.c]++, tmpObj.matrix);
    }
    for (i = 0; i < 3; i++) { bldMeshes[i].count = cnt[i]; bldMeshes[i].instanceMatrix.needsUpdate = true; }
  }

  // falling snow
  var SN_N = 600, snPos = new Float32Array(SN_N * 3), snGeo = new T.BufferGeometry(), snowPts;
  (function () {
    for (var i = 0; i < SN_N; i++) { snPos[i * 3] = rand(-26, 26); snPos[i * 3 + 1] = rand(0, 16); snPos[i * 3 + 2] = rand(-90, 12); }
    snGeo.setAttribute('position', new T.BufferAttribute(snPos, 3));
    snowPts = new T.Points(snGeo, new T.PointsMaterial({ color: 0xffffff, size: 0.16, map: softTexEarly(), transparent: true, opacity: 0.9, depthWrite: false, sizeAttenuation: true, fog: false }));
    snowPts.frustumCulled = false; snowPts.visible = false; scene.add(snowPts);
  })();
  function softTexEarly() {
    var c = document.createElement('canvas'); c.width = c.height = 32;
    var x = c.getContext('2d'), gr = x.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = gr; x.fillRect(0, 0, 32, 32);
    return new T.CanvasTexture(c);
  }
  function updateSnow(v, dt) {
    if (!snowPts.visible) return;
    for (var i = 0; i < SN_N; i++) {
      var k = i * 3;
      snPos[k] += Math.sin(time * 0.7 + i) * 0.25 * dt; snPos[k + 1] -= 2.6 * dt; snPos[k + 2] += v * dt;
      if (snPos[k + 1] < 0 || snPos[k + 2] > 14) { snPos[k] = rand(-26, 26); snPos[k + 1] = rand(8, 16); snPos[k + 2] = rand(-95, -30); }
    }
    snGeo.attributes.position.needsUpdate = true;
  }

  var TRACKS = [
    { id: 'night', name: 'Ночное шоссе', fog: 0x060a12, dens: 0.0055, expo: 1.15, hemi: [0x4a6fa5, 0x0a0d12, 0.55], sun: [0x8fb2ff, 0.4, -20, 30, 10], ground: 0x07110c, shoulder: 0x12171e, wet: true, lamps: true, scenery: 'pine', treeCol: [0x0b2216, 0x0f2c1c, 0x143823], treeSc: [1, 1], env: 'night', sky: 'night', snow: false },
    { id: 'city', name: 'Неон-сити', fog: 0x150a26, dens: 0.0058, expo: 1.2, hemi: [0x7a56c8, 0x120a1c, 0.7], sun: [0xff72d8, 0.5, -20, 30, 10], ground: 0x0a0812, shoulder: 0x16121f, wet: true, lamps: true, scenery: 'city', treeCol: [0x0b2216, 0x0f2c1c, 0x143823], treeSc: [1, 1], env: 'city', sky: 'city', snow: false },
    { id: 'desert', name: 'Закат в пустыне', fog: 0xd98a58, dens: 0.0036, expo: 1.0, hemi: [0xffc58a, 0x7a4524, 0.75], sun: [0xffb070, 1.1, 40, 18, -30], ground: 0xb9784a, shoulder: 0x8a5a3a, wet: false, lamps: false, scenery: 'rock', treeCol: [0x5a3020, 0x6a3a26, 0x7e472c], treeSc: [2.4, 0.5], env: 'desert', sky: 'desert', snow: false },
    { id: 'alps', name: 'Горный перевал', fog: 0xdbe6f0, dens: 0.0046, expo: 1.05, hemi: [0xdbe8ff, 0x8a99aa, 0.8], sun: [0xfff3e0, 1.1, 30, 40, -20], ground: 0xeaf1f8, shoulder: 0xc9d3dd, wet: false, lamps: false, scenery: 'pine', treeCol: [0x2a4a3a, 0xdfe9ef, 0xf3f7fa], treeSc: [1.15, 1.05], env: 'alps', sky: 'alps', snow: true }
  ];
  var trk = TRACKS[0], envRoadCur = envRoad;
  function applyTrack(id) {
    var t = TRACKS.filter(function (q) { return q.id === id; })[0] || TRACKS[0];
    trk = t;
    hemi.color.setHex(t.hemi[0]); hemi.groundColor.setHex(t.hemi[1]); hemi.intensity = t.hemi[2];
    moon.color.setHex(t.sun[0]); moon.intensity = t.sun[1]; moon.position.set(t.sun[2], t.sun[3], t.sun[4]);
    ground.material.color.setHex(t.ground); shoulderMat.color.setHex(t.shoulder);
    var rm = road.material;
    if (t.wet) { rm.roughnessMap = roughTex; rm.roughness = 1; rm.metalness = 0.15; } else { rm.roughnessMap = null; rm.roughness = 0.9; rm.metalness = 0.03; }
    rm.needsUpdate = true;
    var rm2 = road2.material;
    if (t.wet) { rm2.roughnessMap = roughTex2; rm2.roughness = 1; rm2.metalness = 0.15; } else { rm2.roughnessMap = null; rm2.roughness = 0.9; rm2.metalness = 0.03; }
    rm2.needsUpdate = true;
    skyDome.material.map = skyFor(t.sky); skyDome.material.needsUpdate = true;
    horizonGlow.visible = t.id === 'night';
    lamps.forEach(function (l) { l.visible = t.lamps; });
    treeSc = t.treeSc;
    treeLayers.forEach(function (im, k) { im.material.color.setHex(t.treeCol[k]); im.visible = t.scenery !== 'city'; });
    bldMeshes.forEach(function (im) { im.visible = t.scenery === 'city'; });
    snowPts.visible = t.snow;
    envRoadCur = envFor(t.env);
  }

  /* ---------- garage studio ---------- */
  var garageGroup = new T.Group(); garageGroup.visible = false; scene.add(garageGroup);
  var mirrorHolder = new T.Group(); garageGroup.add(mirrorHolder);
  (function () {
    var floor = new T.Mesh(new T.CircleGeometry(34, 64), new T.MeshStandardMaterial({ color: 0x0a0d12, roughness: 0.3, metalness: 0.5, transparent: true, opacity: 0.74, envMapIntensity: 0.7 }));
    floor.rotation.x = -Math.PI / 2; garageGroup.add(floor);
    var wallTex = canvasTex(1024, 256, function (g, w, h) {
      g.fillStyle = '#10151d'; g.fillRect(0, 0, w, h);
      for (var i = 0; i < 32; i++) {
        g.fillStyle = i % 2 ? '#141a23' : '#0d1219'; g.fillRect(i * 32, 0, 30, h);
        g.fillStyle = 'rgba(160,190,255,0.22)'; g.fillRect(i * 32 + 30, 20, 2, h - 40);
      }
    }, true);
    wallTex.repeat.set(3, 1);
    var wall = new T.Mesh(new T.CylinderGeometry(16, 16, 9, 48, 1, true), new T.MeshStandardMaterial({ map: wallTex, roughness: 0.8, metalness: 0.2, side: T.BackSide }));
    wall.position.y = 4.5; garageGroup.add(wall);
    var ring = new T.Mesh(new T.RingGeometry(4.0, 4.14, 80), new T.MeshBasicMaterial({ color: 0x3b86ff, side: T.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.012; garageGroup.add(ring);
    var ring2 = new T.Mesh(new T.RingGeometry(5.2, 5.25, 80), new T.MeshBasicMaterial({ color: 0x3b86ff, transparent: true, opacity: 0.35, side: T.DoubleSide }));
    ring2.rotation.x = -Math.PI / 2; ring2.position.y = 0.012; garageGroup.add(ring2);
    var barMat = new T.MeshBasicMaterial({ color: 0xfff6e6 });
    for (var i = 0; i < 6; i++) {
      var a = i / 6 * Math.PI * 2, bar = new T.Mesh(new T.BoxGeometry(9, 0.12, 0.35), barMat);
      bar.position.set(Math.cos(a) * 8.5, 8.2, Math.sin(a) * 8.5); bar.rotation.y = -a + Math.PI / 2; garageGroup.add(bar);
    }
    var key = new T.DirectionalLight(0xffffff, 0.75); key.position.set(-5, 9, 7); garageGroup.add(key);
    var fill = new T.DirectionalLight(0xbcd2ff, 0.5); fill.position.set(7, 5, 3); garageGroup.add(fill);
    var rim1 = new T.PointLight(0x3b86ff, 1.6, 22, 2); rim1.position.set(-6, 2.2, -6); garageGroup.add(rim1);
    var rim2 = new T.PointLight(0xff8a3a, 0.9, 22, 2); rim2.position.set(6, 2.2, -5); garageGroup.add(rim2);
    garageGroup.add(new T.AmbientLight(0x40506a, 0.3));
  })();

  /* ---------- car construction ---------- */
  var plateCache = {};
  function plateMat(text) {
    if (plateCache[text]) return plateCache[text];
    var tex = canvasTex(256, 64, function (g, w, h) {
      g.fillStyle = '#f1efe4'; g.fillRect(0, 0, w, h);
      g.strokeStyle = '#1b1f26'; g.lineWidth = 4; g.strokeRect(3, 3, w - 6, h - 6);
      g.fillStyle = '#1b3a8a'; g.fillRect(6, 6, 26, h - 12);
      g.fillStyle = '#1b1f26'; g.font = 'bold 36px monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(text, w / 2 + 12, h / 2 + 2);
    });
    return (plateCache[text] = new T.MeshStandardMaterial({ map: tex, roughness: 0.5 }));
  }
  var MAT = {
    glass: new T.MeshPhysicalMaterial({ color: 0x05080d, metalness: 0.9, roughness: 0.06, envMapIntensity: 1.7 }),
    glassT: new T.MeshPhysicalMaterial({ color: 0x0a121c, metalness: 0.25, roughness: 0.04, envMapIntensity: 2.0, transparent: true, opacity: 0.6, depthWrite: false }),
    carbon: new T.MeshStandardMaterial({ color: 0x0b0d11, metalness: 0.4, roughness: 0.35 }),
    carbonL: new T.MeshStandardMaterial({ color: 0x2a2e36, metalness: 0.6, roughness: 0.35 }),
    rimSp: new T.MeshStandardMaterial({ color: 0x1a1d22, metalness: 0.9, roughness: 0.32 }),
    tire: new T.MeshStandardMaterial({ color: 0x0a0a0b, roughness: 0.92, side: T.DoubleSide }),
    rim: new T.MeshStandardMaterial({ color: 0xbcc4ce, metalness: 0.95, roughness: 0.22 }),
    rimDark: new T.MeshStandardMaterial({ color: 0x1b2027, metalness: 0.8, roughness: 0.4 }),
    rimBlk: new T.MeshStandardMaterial({ color: 0x0b0c0f, metalness: 0.9, roughness: 0.34 }),
    disc: new T.MeshStandardMaterial({ color: 0x9aa2ad, metalness: 1, roughness: 0.4 }),
    caliper: new T.MeshStandardMaterial({ color: 0xd8a10a, metalness: 0.35, roughness: 0.4 }),
    chrome: new T.MeshStandardMaterial({ color: 0xe6eaef, metalness: 1, roughness: 0.12 }),
    plastic: new T.MeshStandardMaterial({ color: 0x0e1014, roughness: 0.6, metalness: 0.1 }),
    seat: new T.MeshStandardMaterial({ color: 0x15181d, roughness: 0.8 }),
    head: new T.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff0c8, emissiveIntensity: 1.8 }),
    tail: new T.MeshStandardMaterial({ color: 0x330000, emissive: 0xff0a0a, emissiveIntensity: 1.3 }),
    plate: new T.MeshStandardMaterial({ color: 0xe9e9e4, roughness: 0.5 }),
    shard: new T.MeshStandardMaterial({ color: 0xc8ecff, metalness: 0.6, roughness: 0.05, transparent: true, opacity: 0.55 }),
    flame: new T.MeshBasicMaterial({ color: 0x9fd0ff, transparent: true, opacity: 0.9, blending: T.AdditiveBlending, depthWrite: false })
  };
  function makePaint(color, matte) {
    var m = new T.MeshPhysicalMaterial({ color: color, metalness: 0.22, roughness: 0.38, clearcoat: 1, clearcoatRoughness: 0.03, envMapIntensity: 1.7, vertexColors: true });
    if (matte) { m.clearcoat = 0; m.roughness = 0.58; m.metalness = 0.35; }
    return m;
  }
  function applyFinish(m, matte) {
    if (m.userData && m.userData.model) { m.clearcoat = matte ? 0 : 1; m.roughness = matte ? 0.6 : 0.2; m.metalness = matte ? 0.35 : 0.4; m.needsUpdate = true; return; }
    m.clearcoat = matte ? 0 : 1; m.roughness = matte ? 0.58 : 0.38; m.metalness = matte ? 0.3 : 0.22; m.needsUpdate = true;
  }
  var trafficPaints = {};
  function trafficPaint(c) { return trafficPaints[c] || (trafficPaints[c] = makePaint(c, false)); }

  var boxCache = {};
  function gbox(w, h, d) { var k = w + '|' + h + '|' + d; return boxCache[k] || (boxCache[k] = new T.BoxGeometry(w, h, d)); }
  var boxCacheC = {};
  function whiteBox(w, h, d) {
    var k = w + '|' + h + '|' + d;
    if (!boxCacheC[k]) {
      var g = new T.BoxGeometry(w, h, d), n = g.attributes.position.count, c = new Float32Array(n * 3).fill(1);
      g.setAttribute('color', new T.BufferAttribute(c, 3)); boxCacheC[k] = g;
    }
    return boxCacheC[k];
  }
  function bx(w, h, d, mat, x, y, z, parent) { var m = new T.Mesh(mat.vertexColors ? whiteBox(w, h, d) : gbox(w, h, d), mat); m.position.set(x, y, z); parent.add(m); return m; }
  function rod(p1, p2, thick, mat, x, parent) {
    var du = p2[0] - p1[0], dv = p2[1] - p1[1], len = Math.sqrt(du * du + dv * dv);
    var m = new T.Mesh(gbox(thick, len, thick), mat);
    m.position.set(x, (p1[1] + p2[1]) / 2, -(p1[0] + p2[0]) / 2);
    m.rotation.x = Math.atan2(-du, dv);
    parent.add(m); return m;
  }
  function smoothGeo(geo) {
    geo.computeVertexNormals();
    var pos = geo.attributes.position, nor = geo.attributes.normal, map = {}, i, k;
    for (i = 0; i < pos.count; i++) {
      k = Math.round(pos.getX(i) * 400) + '|' + Math.round(pos.getY(i) * 400) + '|' + Math.round(pos.getZ(i) * 400);
      var a = map[k] || (map[k] = [0, 0, 0]);
      a[0] += nor.getX(i); a[1] += nor.getY(i); a[2] += nor.getZ(i);
    }
    for (i = 0; i < pos.count; i++) {
      k = Math.round(pos.getX(i) * 400) + '|' + Math.round(pos.getY(i) * 400) + '|' + Math.round(pos.getZ(i) * 400);
      var v = map[k], l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) || 1;
      nor.setXYZ(i, v[0] / l, v[1] / l, v[2] / l);
    }
    nor.needsUpdate = true;
    return geo;
  }
  function extrude(shape, width, bevel) {
    var depth = Math.max(0.05, width - 2 * bevel);
    var geo = new T.ExtrudeGeometry(shape, { depth: depth, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 6, curveSegments: 20 });
    geo.translate(0, 0, -depth / 2);
    return smoothGeo(geo);
  }

  var SPEC = {
    coupe: { L: 4.8, W: 1.92, lowT: 0.3, tail: 0.8, deck: 0.98, belt: 0.98, hood: 0.84, wr: 0.35, wf: 1.45, wb: -1.4, track: 0.88, cab: [[-1.62, 1.0], [-0.98, 1.385], [-0.12, 1.39], [0.8, 0.99]], cabW: 1.52 },
    m4: { bp: true, L: 4.794, W: 1.887, lowT: 0.17, tail: 0.93, deck: 1.02, belt: 0.96, hood: 0.95, wr: 0.345, wf: 1.537, wb: -1.32, track: 0.8085, trackR: 0.8025, cab: [[-1.78, 1.1], [-1.0, 1.37], [0.15, 1.38], [0.92, 0.96]], cabW: 1.4 },
    sedan: { L: 4.75, W: 1.88, lowT: 0.34, tail: 0.7, deck: 0.98, belt: 1.0, hood: 0.9, wr: 0.33, wf: 1.45, wb: -1.4, track: 0.84, cab: [[-1.5, 1.0], [-1.05, 1.44], [0.35, 1.45], [1.0, 1.0]], cabW: 1.55 },
    suv: { L: 4.6, W: 1.95, lowT: 0.42, tail: 0.85, deck: 1.15, belt: 1.15, hood: 1.05, wr: 0.38, wf: 1.4, wb: -1.4, track: 0.9, cab: [[-1.9, 1.14], [-1.85, 1.76], [0.5, 1.78], [1.15, 1.14]], cabW: 1.66 },
    hatch: { L: 4.1, W: 1.8, lowT: 0.33, tail: 0.7, deck: 0.98, belt: 0.98, hood: 0.86, wr: 0.31, wf: 1.25, wb: -1.2, track: 0.8, cab: [[-1.35, 0.98], [-1.28, 1.42], [0.3, 1.44], [0.9, 0.98]], cabW: 1.46 },
    brick: { L: 4.85, W: 1.98, lowT: 0.46, tail: 1.0, deck: 1.3, belt: 1.3, hood: 1.28, wr: 0.4, wf: 1.45, wb: -1.4, track: 0.9, cab: [[-2.2, 1.3], [-2.2, 1.95], [0.45, 1.96], [0.62, 1.3]], cabW: 1.72 },
    gt: { L: 4.55, W: 1.98, lowT: 0.3, tail: 0.6, deck: 0.9, belt: 0.9, hood: 0.74, wr: 0.35, wf: 1.3, wb: -1.28, track: 0.88, cab: [[-1.85, 0.92], [-0.95, 1.3], [0.1, 1.31], [0.85, 0.9]], cabW: 1.55 },
    super: { L: 4.7, W: 2.04, lowT: 0.26, tail: 0.6, deck: 0.9, belt: 0.74, hood: 0.66, wr: 0.35, wf: 1.4, wb: -1.3, track: 0.9, cab: [[-0.85, 0.76], [-0.4, 1.1], [0.35, 1.12], [1.05, 0.74]], cabW: 1.56 }
  };
  var TRUCK = { L: 11.6, W: 2.55 };
  var geoCache = {};
  function lerp(a, b, t) { return a + (b - a) * t; }
  function sstep(a, b, x) { var t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
  // closed Catmull-Rom subdivision of a ring of [z,y] points; seg ids carried along
  function ringSmooth(P, sub) {
    var n = P.length, out = [], seg = [], i, k, t;
    for (i = 0; i < n; i++) {
      var p0 = P[(i + n - 1) % n], p1 = P[i], p2 = P[(i + 1) % n], p3 = P[(i + 2) % n];
      for (k = 0; k < sub; k++) {
        t = k / sub; var t2 = t * t, t3 = t2 * t;
        out.push([
          0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
        ]);
        seg.push(i);
      }
    }
    return { pts: out, seg: seg };
  }
  function bodyGeo(kind, hi) {
    var key = kind + (hi ? 'H' : 'L');
    if (geoCache[key]) return geoCache[key];
    var s = SPEC[kind], h = s.L / 2, c = s.cab, W2 = s.W / 2, cw2 = s.cabW / 2;
    var xr0 = c[0][0], xr1 = c[1][0], xf1 = c[2][0], xf0 = c[3][0];
    var roofMax = Math.max(c[1][1], c[2][1]), crown = 0.035;
    var xB = (xr0 + xf0) / 2 - 0.1, xA = xf1 + (xf0 - xf1) * 0.35;
    function deckLine(x) {
      if (x >= xf0) {
        var xh = h - 0.5;
        if (x <= xh) return lerp(s.belt, s.hood, (x - xf0) / (xh - xf0));
        var t2 = (x - xh) / 0.5; return s.hood - 0.12 * t2 * t2 * (0.6 + 0.4 * t2);
      }
      if (x <= xr0) {
        var xd = -h + 0.45;
        if (x >= xd) return lerp(s.deck, s.belt, (x - xd) / (xr0 - xd));
        var t = (x + h) / 0.45; return lerp(s.tail, s.deck, 1 - (1 - t) * (1 - t));
      }
      return s.belt;
    }
    function roofRaw(x) {
      if (x <= xr0 || x >= xf0) return deckLine(x);
      if (x < xr1) return lerp(c[0][1], c[1][1], (x - xr0) / (xr1 - xr0));
      if (x < xf1) return lerp(c[1][1], c[2][1], (x - xr1) / (xf1 - xr1));
      return lerp(c[2][1], c[3][1], (x - xf1) / (xf0 - xf1));
    }
    function roofLine(x) { var a = 0, k; for (k = -3; k <= 3; k++) a += Math.max(roofRaw(x + k * 0.05), deckLine(x)); return a / 7; }
    var N = hi ? 110 : 64, sub = hi ? 8 : 3, rows = [], segs, i, j;
    var rF = 0.27, rR = 0.24;
    for (i = 0; i <= N; i++) {
      var u = i / N, x = -h + s.L * (0.5 - 0.5 * Math.cos(Math.PI * u));
      var deck = deckLine(x), roof = Math.max(deck, roofLine(x));
      var hc = clamp((roof - deck) / (roofMax - s.belt), 0, 1), hcs = sstep(0, 0.22, hc);
      var zg = lerp(W2 * 0.88, cw2 + 0.1, hcs), zr = lerp(W2 * 0.8, cw2 * 0.98, hcs);
      var lip = 0.08 * sstep(h - 0.75, h - 0.1, x), hw = 1 + 0.022 * (Math.exp(-Math.pow((x - s.wb) / 0.55, 2)) + 0.6 * Math.exp(-Math.pow((x - s.wf) / 0.5, 2))) - 0.012 * Math.exp(-Math.pow((x + 0.1) / 0.6, 2));
      W2 = s.W / 2 * hw;
      var R = [
        [0, s.lowT + 0.04 - lip], [W2 * 0.8, s.lowT - lip], [W2 * 0.985, s.lowT + 0.1], [W2 * 0.955, s.lowT + 0.2 * (deck - s.lowT)],
        [W2 * 1.005, deck - 0.2], [W2 * 0.95, deck - 0.02], [zg, deck + 0.01],
        [zr, roof - 0.045 * hcs + 0.007 * (1 - hcs)], [zr * 0.8, roof - 0.012 * hcs + 0.02 * (1 - hcs)], [0, roof + crown * (1 - hcs)]
      ];
      // plan-view taper at the nose and tail
      var wf = 1, t;
      if (x > h - rF) { t = (x - (h - rF)) / rF; wf = Math.pow(Math.max(0, 1 - t * t * t * t), 0.25); }
      else if (x < -h + rR) { t = ((-h + rR) - x) / rR; wf = Math.pow(Math.max(0, 1 - t * t * t * t), 0.25); }
      var ring = [], m;
      for (m = 0; m < 10; m++) ring.push([R[m][0] * wf, R[m][1]]);
      for (m = 8; m >= 1; m--) ring.push([-R[m][0] * wf, R[m][1]]);
      var sm = ringSmooth(ring, sub);
      rows.push({ x: x, pts: sm.pts, seg: sm.seg, deck: deck, roof: roof, hc: hc });
    }
    var per = rows[0].pts.length, pos = new Float32Array((N + 1) * per * 3), col = new Float32Array((N + 1) * per * 3), idx = [[], [], [], []];
    for (i = 0; i <= N; i++) for (j = 0; j < per; j++) {
      var q = rows[i].pts[j], o3 = (i * per + j) * 3, px = rows[i].x, py = q[1];
      pos[o3] = px; pos[o3 + 1] = py; pos[o3 + 2] = q[0];
      var ao = lerp(0.28, 1, sstep(s.lowT - 0.02, s.lowT + 0.36, py)), sf = sstep(0.5, 0.92, Math.abs(q[0]) / W2);
      [s.wf, s.wb].forEach(function (xa) {
        var d = Math.sqrt((px - xa) * (px - xa) + (py - s.wr) * (py - s.wr));
        ao *= lerp(1, lerp(0.18, 1, sstep(s.wr + 0.03, s.wr + 0.38, d)), sf);
      });
      col[o3] = col[o3 + 1] = col[o3 + 2] = ao;
    }
    for (i = 0; i < N; i++) {
      var xm = (rows[i].x + rows[i + 1].x) / 2, hcm = (rows[i].hc + rows[i + 1].hc) / 2, dk = (rows[i].deck + rows[i + 1].deck) / 2, rf = (rows[i].roof + rows[i + 1].roof) / 2;
      for (j = 0; j < per; j++) {
        var sg = rows[i].seg[j], g = 0, j2 = (j + 1) % per;
        if ((sg === 8 || sg === 9) && hcm > 0.1 && ((xm > xf1 + 0.1 && xm < xf0 - 0.1) || (xm > xr0 + 0.1 && xm < xr1 - 0.06))) g = 1;
        else if ((sg === 6 || sg === 11) && hcm > 0.2 && xm > xr0 + 0.2 && xm < xf0 - 0.1 && Math.abs(xm - xB) > 0.045) g = 1;
        else if (sg >= 7 && sg <= 10 && xm > xr1 - 0.06 && xm < xf1 + 0.1) g = 3;
        else if (sg <= 2 || sg >= 15) g = 2;
        var a = i * per + j, b = (i + 1) * per + j, c2 = (i + 1) * per + j2, d = i * per + j2;
        idx[g].push(a, b, d, d, b, c2);
      }
    }
    var geo = new T.BufferGeometry(), all = [], start = 0;
    geo.setAttribute('position', new T.BufferAttribute(pos, 3)); geo.setAttribute('color', new T.BufferAttribute(col, 3));
    for (var g2 = 0; g2 < 4; g2++) { geo.addGroup(start, idx[g2].length, g2); start += idx[g2].length; all = all.concat(idx[g2]); }
    geo.setIndex(all); geo.computeVertexNormals();
    return (geoCache[key] = { body: geo });
  }
  /* ---------- BMW M4 (G82): body lofted from the manufacturer drawing ---------- */
  var BP = {
    T: [0.574, 0.723, 0.885, 1.025, 1.023, 1.019, 1.011, 1.017, 1.023, 1.039, 1.046, 1.054, 1.059, 1.066, 1.076, 1.089, 1.103, 1.117, 1.132, 1.146, 1.159, 1.172, 1.186, 1.2, 1.213, 1.225, 1.236, 1.248, 1.258, 1.268, 1.278, 1.287, 1.306, 1.335, 1.362, 1.376, 1.37, 1.362, 1.354, 1.354, 1.359, 1.35, 1.356, 1.36, 1.378, 1.379, 1.381, 1.383, 1.385, 1.389, 1.391, 1.393, 1.393, 1.393, 1.393, 1.393, 1.393, 1.391, 1.387, 1.383, 1.379, 1.378, 1.372, 1.366, 1.356, 1.348, 1.337, 1.323, 1.306, 1.289, 1.271, 1.252, 1.233, 1.212, 1.192, 1.17, 1.149, 1.126, 1.102, 1.079, 1.056, 1.032, 1.008, 0.973, 0.961, 0.959, 0.953, 0.953, 0.95, 0.948, 0.946, 0.944, 0.962, 0.958, 0.954, 0.95, 0.948, 0.946, 0.944, 0.94, 0.934, 0.931, 0.927, 0.911, 0.887, 0.88, 0.884, 0.894, 0.885, 0.876, 0.862, 0.849, 0.834, 0.82, 0.802, 0.787, 0.77, 0.752, 0.729, 0.694, 0.676],
    B: [0.291, 0.279, 0.274, 0.244, 0.231, 0.22, 0.206, 0.187, 0.177, 0.17, 0.166, 0.164, 0.162, 0.161, 0.165, 0.175, 0.186, 0.197, 0.207, 0.211, 0.208, 0.204, 0.2, 0.197, 0.193, 0.19, 0.186, 0.183, 0.179, 0.175, 0.172, 0.168, 0.165, 0.161, 0.158, 0.154, 0.151, 0.149, 0.148, 0.147, 0.146, 0.146, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.145, 0.144, 0.143, 0.142, 0.141, 0.14, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.139, 0.138, 0.155, 0.153, 0.151, 0.149, 0.149, 0.131, 0.132, 0.133, 0.135, 0.136, 0.137, 0.139, 0.14, 0.142, 0.143, 0.144, 0.146, 0.147, 0.148, 0.15, 0.151, 0.153, 0.154, 0.155, 0.156, 0.156, 0.157, 0.153, 0.147, 0.142, 0.137, 0.133, 0.142, 0.153, 0.16, 0.168],
    W: [0.505, 0.554, 0.65, 0.701, 0.748, 0.784, 0.815, 0.834, 0.85, 0.86, 0.867, 0.873, 0.881, 0.915, 0.915, 0.915, 0.925, 0.934, 0.942, 0.944, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.945, 0.943, 0.942, 0.94, 0.927, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.921, 0.922, 0.923, 0.923, 0.923, 0.924, 0.925, 0.926, 0.926, 0.926, 0.926, 0.926, 0.926, 0.926, 0.926, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.915, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.918, 0.916, 0.915, 0.915, 0.915, 0.915, 0.918, 0.921, 0.924, 0.925, 0.926, 0.926, 0.926, 0.926, 0.927, 0.931, 0.938, 0.944, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.946, 0.945, 0.943, 0.941, 0.93, 0.92, 0.907, 0.897, 0.881, 0.854, 0.811, 0.758, 0.702, 0.641, 0.561, 0.44, 0.374],
    F: [0.914, 0.936, 0.939, 0.939, 0.939, 0.939, 0.939, 0.939, 0.937, 0.936, 0.939, 0.939, 0.939, 0.942, 0.942, 0.942, 0.926, 0.912, 0.879, 0.853, 0.817, 0.78, 0.744, 0.708, 0.683, 0.657, 0.628, 0.595, 0.54]
  };
  
  function smoothArr(a, k) { var o = a.slice(), i, j, t, n; for (i = 0; i < a.length; i++) { t = 0; n = 0; for (j = Math.max(0, i - k); j <= Math.min(a.length - 1, i + k); j++) { t += a[j]; n++; } o[i] = t / n; } return o; }
  BP.W = smoothArr(smoothArr(BP.W, 4), 3); BP.B = smoothArr(BP.B, 2); BP.T = smoothArr(BP.T, 1);
  function bpAt(arr, x) { var n = arr.length - 1, u = clamp((x + 2.397) / 4.794, 0, 1) * n, i = Math.min(n - 1, Math.floor(u)), f = u - i; return arr[i] * (1 - f) + arr[i + 1] * f; }
  function bpF(y) { var n = BP.F.length - 1, u = clamp(y / 0.05, 0, n), i = Math.min(n - 1, Math.floor(u)), f = u - i; return BP.F[i] * (1 - f) + BP.F[i + 1] * f; }
  function bodyGeoBP(s) {
    if (geoCache.m4) return geoCache.m4;
    var h = 2.397, N = 150, sub = 5, rows = [], i, j, k;
    var xf0 = 0.92, xf1 = 0.15, xr1 = -1.0, xr0 = -1.8, xB = -0.53;
    var fl = [0, 0.1, 0.22, 0.38, 0.55, 0.72, 0.88, 1.0], gl = [0.07, 0.3, 0.55, 0.8, 0.93, 1.0], NL = 0;
    for (i = 0; i <= N; i++) {
      var x = -h + 4.794 * (0.5 - 0.5 * Math.cos(Math.PI * i / N));
      var yt = bpAt(BP.T, x), yb = Math.max(0.1, bpAt(BP.B, x)), sc = bpAt(BP.W, x) / 0.9435;
      var belt = 0.955 + 0.045 * sstep(0.7, -1.2, x), beltE = Math.min(belt, yt - 0.03);
      if (beltE < yb + 0.25) beltE = yb + 0.25;
      if (yt < beltE + 0.02) yt = beltE + 0.02;
      var L = [[0, yb]], y, z, zc = 0;
      for (k = 0; k < fl.length; k++) { y = yb + (beltE - yb) * fl[k]; L.push([sc * bpF(y) * lerp(0.84, 1, sstep(yb, yb + 0.32, y)), y]); }
      for (k = 0; k < gl.length; k++) { y = beltE + (yt - beltE) * gl[k]; zc = sc * bpF(y); L.push([zc, y]); }
      var crown = yt - beltE > 0.1 ? 0.012 : 0.026;
      L.push([zc * 0.86, yt + crown * 0.4], [zc * 0.5, yt + crown * 0.85], [0, yt + crown]);
      NL = L.length;
      var ring = L.slice();
      for (k = NL - 2; k >= 1; k--) ring.push([-L[k][0], L[k][1]]);
      var sm = ringSmooth(ring, sub);
      rows.push({ x: x, pts: sm.pts, seg: sm.seg, yt: yt, belt: beltE });
    }
    var per = rows[0].pts.length, np = (N + 1) * per, pos = new Float32Array((np + 2 * (per + 1)) * 3), col = new Float32Array((np + 2 * (per + 1)) * 3), well = new Uint8Array(np), idx = [[], [], [], []];
    var axles = [s.wf, s.wb], Rw = s.wr + 0.045;
    for (i = 0; i <= N; i++) for (j = 0; j < per; j++) {
      var q = rows[i].pts[j], px = rows[i].x, py = q[1], pz = q[0], ao = lerp(0.3, 1, sstep(0.1, 0.42, py)), v = i * per + j, sideF = sstep(0.5, 0.9, Math.abs(pz) / 0.94);
      for (k = 0; k < 2; k++) {
        var dx = px - axles[k], dy = py - s.wr, d = Math.sqrt(dx * dx + dy * dy);
        if (d < Rw && Math.abs(pz) > 0.45) { var dep = 0.24 * sstep(Rw, Rw - 0.05, d); pz -= (pz < 0 ? -1 : 1) * dep; if (dep > 0.02) well[v] = 1; }
        ao *= lerp(1, lerp(0.15, 1, sstep(s.wr + 0.02, s.wr + 0.42, d)), sideF);
      }
      pos[v * 3] = px; pos[v * 3 + 1] = py; pos[v * 3 + 2] = pz; col[v * 3] = col[v * 3 + 1] = col[v * 3 + 2] = ao;
    }
    for (i = 0; i < N; i++) {
      var xm = (rows[i].x + rows[i + 1].x) / 2, hcm = ((rows[i].yt - rows[i].belt) + (rows[i + 1].yt - rows[i + 1].belt)) / 2;
      for (j = 0; j < per; j++) {
        var sg = rows[i].seg[j], a = sg <= NL - 2 ? sg : 2 * NL - 3 - sg, g = 0, j2 = (j + 1) % per;
        var va = i * per + j, vb = (i + 1) * per + j, vc = (i + 1) * per + j2, vd = i * per + j2;
        if (well[va] && well[vb] && well[vc] && well[vd]) g = 2;
        else if (a >= 9 && a <= 12 && hcm > 0.12 && xm > -1.4 && xm < 0.52 && Math.abs(xm - xB) > 0.04) g = 1;
        else if (a >= 15 && hcm > 0.05 && ((xm > xf1 + 0.05 && xm < xf0 - 0.06) || (xm > xr0 && xm < xr1 - 0.05))) g = 1;
        else if (a >= 14 && xm > xr1 - 0.05 && xm < xf1 + 0.07) g = 3;
        else if (a <= 1) g = 2;
        idx[g].push(va, vb, vd, vd, vb, vc);
      }
    }
    // flat end caps (own vertices so the bumper edge stays crisp)
    var base = np, all = [], start = 0, grp = [];
    [0, N].forEach(function (ri) {
      var c0 = base, cy = 0, cz = 0, ex = rows[ri].x;
      for (j = 0; j < per; j++) { var qq = rows[ri].pts[j]; pos[(base + 1 + j) * 3] = ex; pos[(base + 1 + j) * 3 + 1] = qq[1]; pos[(base + 1 + j) * 3 + 2] = qq[0]; cy += qq[1]; cz += qq[0]; col[(base + 1 + j) * 3] = col[(base + 1 + j) * 3 + 1] = col[(base + 1 + j) * 3 + 2] = 0.7; }
      pos[c0 * 3] = ex; pos[c0 * 3 + 1] = cy / per; pos[c0 * 3 + 2] = cz / per; col[c0 * 3] = col[c0 * 3 + 1] = col[c0 * 3 + 2] = 0.7;
      var sgn = ri === 0 ? -1 : 1;
      for (j = 0; j < per; j++) {
        var p1 = rows[ri].pts[j], p2 = rows[ri].pts[(j + 1) % per];
        var ny = (p1[0] - cz / per) * (p2[1] - cy / per) - (p1[1] - cy / per) * (p2[0] - cz / per);   // x-component of cross((p1-c),(p2-c)) with (z,y) order
        var flip = (ny * sgn) > 0;
        idx[0].push(c0, flip ? base + 1 + (j + 1) % per : base + 1 + j, flip ? base + 1 + j : base + 1 + (j + 1) % per);
      }
      base += per + 1;
    });
    var geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(pos, 3)); geo.setAttribute('color', new T.BufferAttribute(col, 3));
    for (var g2 = 0; g2 < 4; g2++) { geo.addGroup(start, idx[g2].length, g2); start += idx[g2].length; all = all.concat(idx[g2]); }
    geo.setIndex(all); geo.computeVertexNormals();
    return (geoCache.m4 = geo);
  }
  var tireCache = {}, rimCache = {};
  function tireGeo(r, w) {
    var k = r + '|' + w;
    if (!tireCache[k]) {
      var hw = w / 2, p = [[0.7, -0.92], [0.86, -1], [0.97, -0.78], [1, -0.45], [1, 0.45], [0.97, 0.78], [0.86, 1], [0.7, 0.92]];
      var geo = new T.LatheGeometry(p.map(function (q) { return new T.Vector2(r * q[0], hw * q[1]); }), 32);
      geo.rotateZ(Math.PI / 2); tireCache[k] = geo;
    }
    return tireCache[k];
  }
  function rimGeo(r, w) {
    var k = r + '|' + w;
    if (!rimCache[k]) { var g = new T.CylinderGeometry(r * 0.72, r * 0.72, w * 0.9, 24); g.rotateZ(Math.PI / 2); rimCache[k] = g; }
    return rimCache[k];
  }
  var discGeo = {};
  function getDisc(r) {
    if (!discGeo[r]) { var g = new T.CylinderGeometry(r * 0.56, r * 0.56, 0.03, 24); g.rotateZ(Math.PI / 2); discGeo[r] = g; }
    return discGeo[r];
  }
  var ringCache = {};
  function lipGeo(r) {
    if (!ringCache[r]) { var g = new T.RingGeometry(r * 0.6, r * 0.73, 40); g.rotateY(Math.PI / 2); ringCache[r] = g; }
    return ringCache[r];
  }
  var backCache = {};
  function backGeo(r) {
    if (!backCache[r]) { var g = new T.CylinderGeometry(r * 0.7, r * 0.7, 0.02, 28); g.rotateZ(Math.PI / 2); backCache[r] = g; }
    return backCache[r];
  }
  function makeWheel(r, w, x, z, side, detail, parent, rec) {
    var pivot = new T.Group(); pivot.position.set(x, r, z);
    var spin = new T.Group(); pivot.add(spin);
    spin.add(new T.Mesh(tireGeo(r, w), MAT.tire));
    var rimM = rec.rimMat || (detail ? MAT.rim : MAT.rimDark);
    if (!detail) spin.add(new T.Mesh(rimGeo(r, w), rimM));
    if (detail) {
      var blk = rimM === MAT.rimBlk, nsp = blk ? 10 : 10;
      var back = new T.Mesh(backGeo(r), MAT.plastic); back.position.x = -side * w * 0.3; spin.add(back);
      var lip = new T.Mesh(lipGeo(r), rimM); lip.position.x = side * w * 0.47; if (side < 0) lip.rotation.y = Math.PI; spin.add(lip);
      var lip2 = new T.Mesh(lipGeo(r), rimM); lip2.scale.set(1, 1, 1); lip2.position.x = side * w * 0.47; lip2.rotation.y = Math.PI * (side < 0 ? 0 : 1); spin.add(lip2);
      for (var i = 0; i < nsp; i++) {
        var sp = new T.Group(); sp.rotation.x = i * Math.PI * 2 / nsp;
        var sm = blk ? MAT.rimSp : MAT.rim;
        bx(0.03, r * 0.62, 0.052, sm, side * w * 0.45, r * 0.33, 0.034, sp).rotation.x = 0.06;
        bx(0.03, r * 0.62, 0.052, sm, side * w * 0.45, r * 0.33, -0.034, sp).rotation.x = -0.06;
        spin.add(sp);
      }
      var hub = new T.Mesh(new T.CylinderGeometry(r * 0.17, r * 0.17, 0.03, 16), MAT.rimSp); hub.rotation.z = Math.PI / 2; hub.position.x = side * w * 0.47; spin.add(hub);
      var hubc = new T.Mesh(new T.CylinderGeometry(r * 0.07, r * 0.07, 0.035, 12), MAT.chrome); hubc.rotation.z = Math.PI / 2; hubc.position.x = side * w * 0.48; spin.add(hubc);
      var d = new T.Mesh(getDisc(r), MAT.disc); d.position.x = -side * w * 0.12; spin.add(d);
      bx(0.07, r * 0.34, r * 0.42, MAT.caliper, -side * w * 0.12 + side * 0.02, r * 0.36, -r * 0.08, pivot);
    }
    parent.add(pivot);
    rec.spins.push({ g: spin, r: r });
    return pivot;
  }
  var glowSpriteMat = new T.SpriteMaterial({ map: radialTex('rgba(255,60,50,1)', 'rgba(255,60,50,0)'), transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  var shadowMat = new T.MeshBasicMaterial({ map: radialTex('rgba(0,0,0,0.7)', 'rgba(0,0,0,0)'), transparent: true, depthWrite: false });
  var redStreakMat = new T.MeshBasicMaterial({ map: streakTex, color: 0xb01408, transparent: true, opacity: 0.5, depthWrite: false, blending: T.AdditiveBlending });
  var redStreakGeo = new T.PlaneGeometry(2.2, 7);
  function addTailReflection(g, L) {
    var m = new T.Mesh(redStreakGeo, redStreakMat);
    m.rotation.x = -Math.PI / 2; m.position.set(0, 0.035, L / 2 + 3.4); g.add(m);
  }
  function addShadow(g, L, W) {
    var m = new T.Mesh(new T.PlaneGeometry(W * 1.5, L * 1.25), shadowMat);
    m.rotation.x = -Math.PI / 2; m.position.y = 0.02; g.add(m);
  }
  var archGeoCache = {}, archMat = new T.MeshBasicMaterial({ color: 0x030405, side: T.DoubleSide });

  // opts: { spoiler, roof, plate } for hero cars
  function makeCar(kind, paint, detail, opts) {
    opts = opts || {};
    var s = SPEC[kind], g = new T.Group(), body = new T.Group(), rec = { group: g, body: body, spins: [], front: [], flames: [], spec: s, paint: paint };
    g.add(body);
    rec.rimMat = detail ? (opts.blackRims ? MAT.rimBlk : MAT.rim) : MAT.rimDark;
    var geo = s.bp ? { body: bodyGeoBP(s) } : bodyGeo(kind, detail || opts.hi), L2 = s.L / 2, c = s.cab;
    var roofMat = (detail && opts.roof === 'carbon') ? MAT.carbon : paint, roofV = Math.max(c[1][1], c[2][1]);
    var bm = new T.Mesh(geo.body, [paint, MAT.glass, MAT.plastic, roofMat]); bm.rotation.y = Math.PI / 2; body.add(bm); rec.bodyMesh = bm;
    rec.cabMesh = new T.Object3D();
    if (s.bp) {
      var hh = L2;
      [-1, 1].forEach(function (sd) {
        // mirrors, door cuts, handle, front-fender gill
        bx(0.13, 0.095, 0.2, paint, sd * 0.985, 1.03, -0.55, body);
        bx(0.09, 0.03, 0.09, MAT.plastic, sd * 0.9, 0.985, -0.56, body);
        bx(0.012, 0.56, 0.012, MAT.plastic, sd * 0.925, 0.6, -0.74, body);
        bx(0.012, 0.56, 0.012, MAT.plastic, sd * 0.925, 0.6, 0.52, body);
        bx(0.016, 0.022, 0.15, MAT.carbonL, sd * 0.925, 0.83, 0.3, body);
        var gill = bx(0.014, 0.17, 0.12, MAT.plastic, sd * 0.93, 0.6, -1.12, body); gill.rotation.x = 0.35;
        // headlights: slim LED units on the front corners
        var hl = bx(0.46, 0.07, 0.06, MAT.carbon, sd * 0.67, 0.7, -(hh - 0.2), body); hl.rotation.y = sd * 0.5; hl.rotation.z = sd * 0.16;
        var drl = bx(0.4, 0.016, 0.02, MAT.head, sd * 0.67, 0.7, -(hh - 0.2) - 0.03, body); drl.rotation.y = sd * 0.5; drl.rotation.z = sd * 0.16;
        // grille, lower intakes, side air curtains
        bx(0.32, 0.45, 0.07, MAT.plastic, sd * 0.2, 0.48, -hh + 0.02, body);
        for (var gi = 0; gi < 7; gi++) bx(0.28, 0.012, 0.02, MAT.carbonL, sd * 0.2, 0.3 + gi * 0.056, -hh - 0.015, body);
        bx(0.36, 0.17, 0.05, MAT.plastic, sd * 0.49, 0.33, -hh + 0.03, body);
        for (var gj = 0; gj < 4; gj++) bx(0.32, 0.01, 0.02, MAT.carbonL, sd * 0.49, 0.27 + gj * 0.04, -hh - 0.0, body);
        bx(0.03, 0.16, 0.05, MAT.plastic, sd * 0.84, 0.4, -hh + 0.1, body);
        // tail lamps
        if (!rec.tailMat) rec.tailMat = MAT.tail.clone();
        var tl = bx(0.56, 0.045, 0.05, rec.tailMat, sd * 0.57, 0.89, hh - 0.1, body); tl.rotation.x = -0.34;
        var tl2 = bx(0.05, 0.14, 0.05, rec.tailMat, sd * 0.82, 0.84, hh - 0.1, body); tl2.rotation.x = -0.34;
        var sp = new T.Sprite(glowSpriteMat); sp.scale.set(0.8, 0.4, 1); sp.position.set(sd * 0.6, 0.88, hh + 0.14); body.add(sp);
      });
      bx(0.06, 0.45, 0.07, MAT.plastic, 0, 0.48, -hh + 0.02, body);
      bx(0.05, 0.05, 0.02, MAT.chrome, 0, 0.71, -hh + 0.06, body);
      bx(1.5, 0.025, 0.16, MAT.carbon, 0, 0.17, -hh + 0.0, body);
      bx(0.4, 0.1, 0.012, detail ? plateMat(opts.plate || 'M4 777') : MAT.plate, 0, 0.4, hh + 0.012, body);
      bx(1.0, 0.1, 0.22, MAT.carbon, 0, 0.23, hh - 0.1, body);
      var exg2 = new T.CylinderGeometry(0.048, 0.048, 0.16, 14); exg2.rotateX(Math.PI / 2);
      [-0.39, -0.27, 0.27, 0.39].forEach(function (ex) {
        var m = new T.Mesh(exg2, MAT.chrome); m.position.set(ex, 0.31, hh + 0.0); body.add(m);
        var fl = new T.Mesh(new T.ConeGeometry(0.07, 1, 10), MAT.flame); fl.rotation.x = -Math.PI / 2;
        fl.position.set(ex, 0.31, hh + 0.5); fl.visible = false; body.add(fl); rec.flames.push(fl);
      });
    } else {
    [-1, 1].forEach(function (sd) {
      bx(0.13, 0.085, 0.2, paint, sd * (s.W / 2 + 0.02), s.belt + 0.08, -(c[3][0] - 0.38), body);
      bx(0.1, 0.03, 0.1, MAT.plastic, sd * (s.W / 2 - 0.07), s.belt + 0.03, -(c[3][0] - 0.38), body);
      bx(0.012, s.belt - s.lowT - 0.1, 0.012, MAT.plastic, sd * (s.W / 2 + 0.01), (s.belt + s.lowT) / 2, -0.55, body);
      bx(0.012, s.belt - s.lowT - 0.1, 0.012, MAT.plastic, sd * (s.W / 2 + 0.01), (s.belt + s.lowT) / 2, 0.7, body);
      bx(0.07, 0.08, s.L * 0.42, MAT.plastic, sd * (s.W / 2 - 0.03), s.lowT + 0.05, 0, body);
      bx(0.05, 0.02, 0.14, MAT.chrome, sd * (s.W / 2 + 0.01), s.belt - 0.08, 0.35, body);
      var hl = bx(0.5, 0.075, 0.06, MAT.head, sd * (s.W / 2 - 0.3), s.hood - 0.1, -L2 + 0.13, body); hl.rotation.x = 0.5; hl.rotation.y = sd * 0.12;
      if (detail) { var hl2 = bx(0.5, 0.03, 0.05, MAT.plastic, sd * (s.W / 2 - 0.3), s.hood - 0.04, -L2 + 0.15, body); hl2.rotation.x = 0.5; hl2.rotation.y = sd * 0.12; }
      if (detail) {
        bx(0.07, 0.17, 0.05, MAT.tail, sd * (s.W / 2 - 0.13), s.tail - 0.1, L2 - 0.02, body);
        bx(0.46, 0.07, 0.05, MAT.tail, sd * (s.W / 2 - 0.33), s.tail - 0.04, L2 - 0.02, body);
      } else {
        bx(0.5, 0.1, 0.05, MAT.tail, sd * (s.W / 2 - 0.35), s.tail - 0.06, L2 - 0.02, body);
      }
      var sp = new T.Sprite(glowSpriteMat); sp.scale.set(0.85, 0.5, 1);
      sp.position.set(sd * (s.W / 2 - 0.33), s.tail - 0.04, L2 + 0.12); body.add(sp);
    });
    bx(1.0, 0.17, 0.05, MAT.plastic, 0, s.lowT + 0.22, -L2 + 0.02, body);
    if (detail && opts.grille) {
      var gy = s.hood - 0.3;
      [-1, 1].forEach(function (sd) {
        bx(0.4, 0.3, 0.06, MAT.plastic, sd * 0.235, gy, -L2 + 0.0, body);
        for (var gi = 0; gi < 6; gi++) bx(0.36, 0.01, 0.03, MAT.carbonL, sd * 0.235, gy - 0.12 + gi * 0.048, -L2 - 0.03, body);
        bx(0.012, 0.3, 0.03, MAT.carbonL, sd * 0.235, gy, -L2 - 0.03, body);
      });
      bx(0.05, 0.31, 0.07, MAT.plastic, 0, gy, -L2 + 0.0, body);
      bx(0.06, 0.06, 0.03, MAT.chrome, 0, s.hood - 0.04, -L2 + 0.11, body);
    }
    bx(s.W - 0.5, 0.03, 0.2, MAT.carbon, 0, s.lowT + 0.0, -L2 + 0.02, body);
    bx(0.52, 0.12, 0.02, detail ? plateMat(opts.plate || 'NIGHT 01') : MAT.plate, 0, s.lowT + 0.35, L2 + 0.03, body);
    bx(1.1, 0.08, 0.3, MAT.carbon, 0, s.lowT + 0.04, L2 - 0.12, body);
    var exg = new T.CylinderGeometry(0.045, 0.045, 0.16, 12); exg.rotateX(Math.PI / 2);
    (detail ? [-0.6, -0.42, 0.42, 0.6] : [-0.5, 0.5]).forEach(function (ex) {
      var m = new T.Mesh(exg, MAT.chrome); m.position.set(ex, s.lowT + 0.07, L2 + 0.04); body.add(m);
      if (detail) {
        var fl = new T.Mesh(new T.ConeGeometry(0.07, 1, 10), MAT.flame); fl.rotation.x = -Math.PI / 2;
        fl.position.set(ex, s.lowT + 0.07, L2 + 0.5); fl.visible = false; body.add(fl); rec.flames.push(fl);
      }
    });
    if (detail) {
      var sp2 = opts.spoiler;
      if (sp2 === 'duck') bx(s.W - 0.4, 0.045, 0.22, paint, 0, s.deck + 0.02, L2 - 0.4, body);
      if (sp2 === 'roof') bx(s.cabW - 0.2, 0.05, 0.22, paint, 0, roofV + 0.05, -c[1][0] + 0.12, body);
      if (sp2 === 'wing') {
        bx(s.W - 0.2, 0.04, 0.42, MAT.carbon, 0, s.deck + 0.34, L2 - 0.32, body);
        [-1, 1].forEach(function (sd) { bx(0.04, 0.34, 0.2, MAT.carbon, sd * 0.72, s.deck + 0.17, L2 - 0.32, body); });
      }
      if (kind !== 'brick') {
        bx(0.05, 0.012, 1.0, MAT.plastic, -0.28, s.hood + 0.02, -L2 + 1.3, body);
        bx(0.05, 0.012, 1.0, MAT.plastic, 0.28, s.hood + 0.02, -L2 + 1.3, body);
      }
    }
    }
    // wheels and arches
    var w = detail ? 0.27 : 0.23;
    [-1, 1].forEach(function (sd) {
      rec.front.push(makeWheel(s.wr, s.bp ? 0.275 : w, sd * s.track, -s.wf, sd, detail, g, rec));
      makeWheel(s.wr, s.bp ? 0.29 : w, sd * (s.trackR || s.track), -s.wb, sd, detail, g, rec);
      if (detail && !s.bp) {
        var ak = String(s.wr);
        var ag = archGeoCache[ak] || (archGeoCache[ak] = new T.CircleGeometry(s.wr + 0.075, 28));
        [s.wf, s.wb].forEach(function (u) {
          var a = new T.Mesh(ag, archMat); a.rotation.y = sd * Math.PI / 2;
          a.position.set(sd * (s.W / 2 + 0.014), s.wr, -u); g.add(a);
        });
      }
    });
    addShadow(g, s.L, s.W);
    addTailReflection(g, s.L);
    return rec;
  }

  var truckTrailer = [0xdfe3e8, 0xc8d0d8, 0xb9c2cc, 0xe8e2d4];
  function makeTruck(cabColor) {
    var g = new T.Group(), body = new T.Group(), rec = { group: g, body: body, spins: [], front: [], flames: [], spec: TRUCK };
    g.add(body);
    var cab = trafficPaint(cabColor), tmat = new T.MeshStandardMaterial({ color: truckTrailer[(Math.random() * 4) | 0], roughness: 0.55, metalness: 0.2 });
    bx(2.5, 2.7, 2.6, cab, 0, 1.95, -4.5, body);
    bx(2.2, 1.0, 0.05, MAT.glass, 0, 2.75, -5.82, body);
    bx(2.55, 3.2, 8.8, tmat, 0, 2.5, 1.4, body);
    for (var i = 0; i < 5; i++) bx(2.57, 3.0, 0.05, MAT.plastic, 0, 2.5, -2.6 + i * 1.9, body);
    bx(2.3, 0.35, 11.0, MAT.plastic, 0, 0.7, 0.1, body);
    bx(0.55, 0.12, 0.06, MAT.head, -0.8, 1.2, -5.82, body); bx(0.55, 0.12, 0.06, MAT.head, 0.8, 1.2, -5.82, body);
    [-1, 1].forEach(function (sd) {
      bx(0.5, 0.2, 0.06, MAT.tail, sd * 0.95, 1.0, 5.82, body);
      var sp = new T.Sprite(glowSpriteMat); sp.scale.set(1.8, 1.4, 1); sp.position.set(sd * 0.95, 1.0, 6.0); body.add(sp);
      [-0.6, 0, 0.6].forEach(function (o) { bx(0.2, 0.18, 0.04, (o === 0 ? MAT.plate : MAT.tail), sd * 0.3 + o * 0.3, 0.5, 5.83, body); });
      [-4.6, 2.4, 3.8, 5.2].forEach(function (z) { makeWheel(0.52, 0.32, sd * 1.12, z, sd, false, g, rec); });
    });
    bx(2.0, 0.12, 0.05, MAT.chrome, 0, 0.5, 5.84, body);
    addShadow(g, 11.6, 2.55);
    addTailReflection(g, 11.6);
    return rec;
  }


  /* ---------- real 3D models (GLB) ---------- */
  var modelCache = {}, modelBusy = {}, glbLoader = T.GLTFLoader ? new T.GLTFLoader() : null;
  var glassModelMat = new T.MeshPhysicalMaterial({ color: 0x06090d, metalness: 0.6, roughness: 0.05, transparent: true, opacity: 0.9, envMapIntensity: 1.6 });
  var glowWhiteMat = new T.SpriteMaterial({ map: radialTex('rgba(235,242,255,1)', 'rgba(200,220,255,0)'), transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  function makeModelPaint(color, matte) {
    var m = new T.MeshPhysicalMaterial({ color: color, metalness: 0.4, roughness: 0.2, clearcoat: 1, clearcoatRoughness: 0.03, envMapIntensity: 1.25 });
    m.userData.model = true; applyFinish(m, matte); return m;
  }
  function lampSpots(root, L) {
    var acc = {};
    root.traverse(function (m) {
      if (!m.isMesh || !m.material) return; var nm = m.material.name;
      if (nm !== 'LIGHT' && nm !== 'TAIL' && nm !== 'AMBER') return;
      var pa = m.geometry.attributes.position;
      for (var i = 0; i < pa.count; i++) {
        var x = pa.getX(i), y = pa.getY(i), z = pa.getZ(i);
        if (Math.abs(z) < L * 0.3 || y < 0.35 || Math.abs(x) < 0.2) continue;
        var k = (z > 0 ? 'r' : 'f') + (x > 0 ? '1' : '0'), a = acc[k] || (acc[k] = { x: 0, y: 0, z: 0, n: 0, zm: z });
        a.x += x; a.y += y; a.z += z; a.n++; a.zm = z > 0 ? Math.max(a.zm, z) : Math.min(a.zm, z);
      }
    });
    return acc;
  }
  var MODEL_MAT = { CARBON: MAT.carbon, plastic: MAT.plastic, grille: MAT.plastic, textured: MAT.plastic, badge: MAT.chrome, tire: MAT.tire, disc: MAT.disc, caliper: MAT.caliper };
  var ambMat = new T.MeshStandardMaterial({ color: 0x331a00, emissive: 0xff8a00, emissiveIntensity: 0.8, roughness: 0.3 });
  function liveryMat(o) {
    var m = new T.MeshPhysicalMaterial({ color: o.color, map: o.map, metalness: 0.45, roughness: 0.28, clearcoat: 1, clearcoatRoughness: 0.05, envMapIntensity: 1.5 });
    m.userData.model = false; return m;
  }
  var glowFireMat = new T.SpriteMaterial({ map: radialTex('rgba(255,170,70,1)', 'rgba(255,90,10,0)'), transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  var flameTex = (function () {
    var w = 64, h = 128, c = document.createElement('canvas'); c.width = w; c.height = h; var x = c.getContext('2d'), i, j;
    for (j = 0; j < h; j++) {
      var t = j / (h - 1);            // 0 = apex (tip) .. 1 = base (pipe)
      var r, g2, b2, a;
      if (t > 0.85) { r = 255; g2 = 250; b2 = 235; a = 1; }
      else if (t > 0.6) { var u = (t - 0.6) / 0.25; r = 255; g2 = 190 + 60 * u; b2 = 90 + 140 * u; a = 0.95; }
      else if (t > 0.3) { var u2 = (t - 0.3) / 0.3; r = 255; g2 = 110 + 80 * u2; b2 = 30 + 60 * u2; a = 0.55 + 0.4 * u2; }
      else { var u3 = t / 0.3; r = 255 * (0.5 + 0.5 * u3); g2 = 60 + 50 * u3; b2 = 20; a = 0.55 * u3; }
      for (i = 0; i < w; i++) {
        var ph = i / w * Math.PI * 2, nz = 0.62 + 0.2 * Math.sin(ph * 3 + t * 9) + 0.12 * Math.sin(ph * 7 - t * 15) + 0.06 * Math.sin(ph * 13 + t * 4);
        var aa = Math.max(0, Math.min(1, a * nz * (0.85 + 0.3 * Math.random())));
        x.fillStyle = 'rgba(' + (r | 0) + ',' + (g2 | 0) + ',' + (b2 | 0) + ',' + aa.toFixed(3) + ')'; x.fillRect(i, j, 1, 1);
      }
    }
    var tx = new T.CanvasTexture(c); tx.wrapS = T.RepeatWrapping; return tx;
  })();
  var flOuter = new T.MeshBasicMaterial({ map: flameTex, color: 0xffa060, transparent: true, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide });
  var flInner = new T.MeshBasicMaterial({ map: flameTex, color: 0xdde8ff, transparent: true, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide });
  var diaMat = new T.SpriteMaterial({ map: radialTex('rgba(235,245,255,1)', 'rgba(120,170,255,0)'), transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  var flGeo = new T.ConeGeometry(1, 1, 14, 1, true); flGeo.translate(0, 0.5, 0); flGeo.rotateX(Math.PI / 2);
  function makeTip(parent, x, y, z, r) {
    var fg = new T.Group(); fg.position.set(x, y, z); fg.visible = false;
    var o = new T.Mesh(flGeo, flOuter), i = new T.Mesh(flGeo, flInner), gl = new T.Sprite(glowFireMat), dm = [], k;
    o.renderOrder = 5; i.renderOrder = 6; gl.renderOrder = 7;
    fg.add(o); fg.add(i); fg.add(gl);
    for (k = 0; k < 3; k++) { var d = new T.Sprite(diaMat); d.renderOrder = 8; d.visible = false; fg.add(d); dm.push(d); }
    parent.add(fg);
    return { fg: fg, o: o, i: i, gl: gl, dm: dm, r: r, p: 0, ph: Math.random() * 6 };
  }
  function makeModelRec(c, src) {
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var paint = makeModelPaint(PAINT_COLORS[colorOf(c.id)], !!save.matte[c.id]);
    var rec = { group: g, body: body, spins: [], front: [], flames: [], paint: paint, model: true, isHero: true, defMeshes: [], glassMeshes: [], cabMesh: new T.Object3D() };
    var root = src.clone(true);
    var bb = new T.Box3().setFromObject(root), sz = bb.getSize(new T.Vector3());
    rec.spec = Object.assign({}, SPEC.coupe, { L: sz.z, W: sz.x, H: sz.y });
    var tailM = null;
    root.traverse(function (m) {
      if (!m.isMesh) return;
      var nm = m.material.name;
      if (nm === 'PAINT') m.material = paint;
      else if (nm === 'GLASS') { m.material = glassModelMat; rec.glassMeshes.push(m); }
      else if (nm === 'TAIL') { tailM = tailM || MAT.tail.clone(); m.material = tailM; }
      else if (nm === 'AMBER') { m.material = ambMat; }
      else if (nm === 'LIVERY') { var lm = m.material; m.material = liveryMat(lm); }
      else if (nm === 'LIGHT') { var lq = m.material = m.material.clone(); lq.emissiveIntensity = 0.5; lq.metalness = 0.2; lq.roughness = 0.25; lq.envMapIntensity = 1.4; lq.userData.lamp = true; rec.lampMats = (rec.lampMats || []).concat(lq); }
      else if (nm === 'rim') m.material = rec.rimPaint || (rec.rimPaint = MAT.rim.clone());
      else if (MODEL_MAT[nm]) m.material = MODEL_MAT[nm];
      m.castShadow = false; rec.defMeshes.push(m);
    });
    if (tailM) rec.tailMat = tailM;
    root.updateMatrixWorld(true);
    var wheelNodes = [], wheelMeshes = [];
    root.traverse(function (n) { if (/^wheel_/.test(n.name)) wheelNodes.push(n); });
    wheelNodes.forEach(function (wg) {
      var wpos = new T.Vector3().setFromMatrixPosition(wg.matrixWorld);
      var spin = null, stat = null;
      wg.children.forEach(function (ch) { if (/^spin/.test(ch.name)) spin = ch; else if (/^static/.test(ch.name)) stat = ch; });
      if (wg.parent) wg.parent.remove(wg);
      var pivot = new T.Group(); pivot.position.copy(wpos);
      if (!spin) spin = new T.Group();
      var rr = wg.userData && wg.userData.r;
      if (!rr) { var wb = new T.Box3().setFromObject(spin); rr = isFinite(wb.max.y - wb.min.y) && wb.max.y > wb.min.y ? (wb.max.y - wb.min.y) / 2 : 0.35; }
      spin.position.set(0, 0, 0); pivot.add(spin); if (stat) { stat.position.set(0, 0, 0); pivot.add(stat); }
      rec.spins.push({ g: spin, r: rr });
      if (pivot.position.z < 0) rec.front.push(pivot);
      body.add(pivot); pivot.traverse(function (m) { if (m.isMesh) wheelMeshes.push(m); });
    });
    rec.defMeshes = rec.defMeshes.filter(function (m) { return wheelMeshes.indexOf(m) < 0; });
    body.add(root);
    if (c.exh) rec.exh = c.exh.map(function (e) { return makeTip(body, e[0], e[1], bb.max.z - 0.05, c.exr || 0.05); });
    // glow sprites on the lamps
    var sp = lampSpots(root, sz.z);
    Object.keys(sp).forEach(function (k) {
      var a = sp[k]; if (a.n < 20) return;
      var rear = k[0] === 'r', s2 = new T.Sprite(rear ? glowSpriteMat : glowWhiteMat);
      s2.scale.set(rear ? 0.75 : 0.55, rear ? 0.38 : 0.34, 1);
      s2.position.set(a.x / a.n, a.y / a.n, a.zm + (rear ? 0.12 : -0.12)); body.add(s2);
    });
    addShadow(g, sz.z, sz.x); addTailReflection(g, sz.z);
    return rec;
  }
  function loadModel(id) {
    var c = carById(id);
    if (!c.model || modelCache[id] || modelBusy[id] || !glbLoader) return;
    modelBusy[id] = true;
    if (mode === 'garage' || mode === 'menu') toast('Загружаю модель: ' + c.brand + ' ' + c.name + '…');
    function parseModel(txt) {
      try {
        var bin = atob(JSON.parse(txt).b), u = new Uint8Array(bin.length), k;
        for (k = 0; k < bin.length; k++) u[k] = bin.charCodeAt(k);
        glbLoader.parse(u.buffer, '', function (gl) { modelCache[id] = gl.scene; modelBusy[id] = false; if (window.__preloadedModels) delete window.__preloadedModels[id]; onModelReady(id); }, function () { modelBusy[id] = false; toast('Не удалось разобрать модель ' + id, 6000); });
      } catch (e) { modelBusy[id] = false; }
    }
    if (window.__preloadedModels && window.__preloadedModels[id]) parseModel(window.__preloadedModels[id]);
    else new T.FileLoader().load(c.model, parseModel, undefined, function () { modelBusy[id] = false; });
  }
  function onModelReady(id) {
    if (mode === 'play' || mode === 'crash') return;       // swapped on the next start
    if (curCar && curCar.id === id && mode !== 'garage') setPlayerCar(id);
    if (mode === 'garage' && CARS[gIndex].id === id) showGarageCar(gIndex);
  }

  /* ---------- hero cars ---------- */
  var recs = {};
  function getRec(id) {
    var c0 = carById(id);
    if (recs[id] && !(recs[id].proc && modelCache[id])) { if (c0.model && !modelCache[id]) loadModel(id); return recs[id]; }
    if (modelCache[id]) { var mr = makeModelRec(c0, modelCache[id]); return (recs[id] = mr); }
    if (c0.model) loadModel(id);
    var c = carById(id), paint = makePaint(PAINT_COLORS[colorOf(id)], !!save.matte[id]);
    var rec = makeCar(c.shape, paint, true, { spoiler: c.spoiler, roof: c.roof, plate: c.plate, blackRims: c.blackRims, grille: c.grille });
    rec.isHero = true; rec.proc = !!c.model;
    return (recs[id] = rec);
  }

  /* ---------- state ---------- */
  var mode = 'menu';              // menu | garage | play | crash
  var player = { x: laneX(1), vx: 0, yaw: 0, roll: 0, pitch: 0, spin: 0, om: 0, hop: 0, hopV: 0, yawV: 0 };
  var pGroup = new T.Group(); scene.add(pGroup);
  var pCar = null, PL = SPEC.coupe, curCar = CARS[0], P = perf(CARS[0]);
  // two real headlight beams (one per lamp) + light pools on the asphalt
  var headSpots = [-1, 1].map(function (sd) {
    var sl = new T.SpotLight(0xfff4dc, 1.7, 100, 0.36, 0.75, 1);
    sl.position.set(sd * 0.67, 0.7, -2); sl.target.position.set(sd * 1.6, 0, -48);
    pGroup.add(sl); pGroup.add(sl.target); return sl;
  });
  var headSpot = { set visible(v) { headSpots.forEach(function (l) { l.visible = v; }); }, position: { set: function () {} } };
  var tailLight = new T.PointLight(0xff2020, 0.8, 8, 2); tailLight.position.set(0, 0.8, 3.6); pGroup.add(tailLight);
  var neonLight = new T.PointLight(0x2d8cff, 0, 7, 2); neonLight.position.set(0, 0.25, 0); pGroup.add(neonLight);
  var neonGlow = new T.Mesh(new T.PlaneGeometry(3.5, 6.3), new T.MeshBasicMaterial({ color: 0x2d8cff, transparent: true, opacity: 0, depthWrite: false, blending: T.AdditiveBlending }));
  neonGlow.rotation.x = -Math.PI / 2; neonGlow.position.y = 0.035; pGroup.add(neonGlow);
  function applyLighting(id) {
    var light = save.lights[id] || { color: '#fff4dc', intensity: 1.7 }, neon = save.neon[id] || '#000000';
    headSpots.forEach(function (l) { l.color.set(light.color || '#fff4dc'); l.intensity = clamp(+light.intensity || 1.7, 0.2, 4); });
    if (pCar && pCar.lampMats) pCar.lampMats.forEach(function (m) { m.emissive.set(light.color || '#fff4dc'); m.emissiveIntensity = clamp((+light.intensity || 1.7) * 0.45, 0.1, 2); });
    neonGlow.material.color.set(neon); neonLight.color.set(neon);
    neonGlow.material.opacity = !graphics.lighting || neon === '#000000' ? 0 : 0.42;
    neonLight.intensity = !graphics.lighting || neon === '#000000' ? 0 : 0.65;
  }
  function applyShadows() {
    var enabled = graphics.shadows !== 'off';
    renderer.shadowMap.enabled = enabled;
    renderer.shadowMap.type = T.PCFSoftShadowMap;
    headSpots.forEach(function (light, i) {
      light.castShadow = enabled && i === 0;
      light.shadow.mapSize.set(graphics.shadows === 'high' ? 512 : 256, graphics.shadows === 'high' ? 512 : 256);
      light.shadow.bias = -0.001;
      if (light.shadow.map) { light.shadow.map.dispose(); light.shadow.map = null; }
    });
    if (pCar) pCar.group.traverse(function (object) { if (object.isMesh) object.castShadow = enabled; });
  }
  var poolTex = canvasTex(64, 256, function (g, w, h) {
    var gr = g.createLinearGradient(0, h, 0, 0);
    gr.addColorStop(0, 'rgba(255,244,220,0.85)'); gr.addColorStop(0.35, 'rgba(255,240,210,0.38)'); gr.addColorStop(1, 'rgba(255,240,210,0)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    var hg = g.createLinearGradient(0, 0, w, 0);
    hg.addColorStop(0, 'rgba(0,0,0,1)'); hg.addColorStop(0.5, 'rgba(0,0,0,0)'); hg.addColorStop(1, 'rgba(0,0,0,1)');
    g.globalCompositeOperation = 'destination-out'; g.fillStyle = hg; g.fillRect(0, 0, w, h);
  });
  var cone = new T.Group();
  [-1, 1].forEach(function (sd) {
    var pool = new T.Mesh(new T.PlaneGeometry(4.2, 30), new T.MeshBasicMaterial({ map: poolTex, transparent: true, opacity: 0.32, depthWrite: false, blending: T.AdditiveBlending }));
    pool.rotation.x = -Math.PI / 2; pool.position.set(sd * 1.1, 0.035, -16); cone.add(pool);
  });
  pGroup.add(cone);

  function setPlayerCar(id) {
    curCar = carById(id); P = perf(curCar);
    if (pCar) pGroup.remove(pCar.group);
    pCar = getRec(id); PL = pCar.spec;
    restoreCar(pCar);
    $('carBadge').textContent = SHORT[id] || '';
    pGroup.add(pCar.group);
    pCar.body.rotation.set(0, 0, 0); pCar.body.position.set(0, 0, 0);
    headSpots.forEach(function (l, i) { var sd = i ? 1 : -1; l.position.set(sd * (PL.W * 0.35), 0.7, -PL.L / 2 + 0.3); l.target.position.set(sd * 1.6, 0, -48); });
    tailLight.position.set(0, 0.8, PL.L / 2 + 0.8);
    cone.position.z = -PL.L / 2;
    applyLighting(id);
    if (pCar.rimPaint) pCar.rimPaint.color.set(save.rims[id] || '#aeb8c8');
    applyShadows();
  }
  setPlayerCar(save.sel);

  var cars = [], time = 0, runT = 0, speed = 0, roadOff = 0;
  var coins = 0, overtakes = 0, nearMisses = 0, distanceMeters = 0, combo = 0, comboT = 0, nitro = 1, nitroOn = false, maxSpeed = 0;
  var smokeT = 0, slowT = 0;
  var oncT = 2, onT = 0, spawnT = 0, crashT = 0, shake = 0, overShown = false, camX = player.x, menuBlend = 1, steerVis = 0, bobT = 0;
  var COMBO_WINDOW = 2.5;
  var rpm = 2800, gearN = 1, throttle = 0.1;
  var gAng = 0.7, gH = 1.7, gZoom = 1, gVel = 0, gDrag = null, gLast = 0, gIndex = 0;
  window.__cam = function (an, hh) { gAng = an; gH = hh; gVel = 0; gLast = time; };

  /* ---------- scene switching ---------- */
  function enterMode(m) {
    mode = m;
    var g = m === 'garage', hi = effectiveQuality() !== 'low';
    world.visible = !g; garageGroup.visible = g;
    hemi.visible = !g; moon.visible = !g; headSpot.visible = true; tailLight.visible = !g;
    cone.visible = !g && hi && graphics.lighting;
    streaks.forEach(function (s) { s.visible = hi && graphics.lighting && trk.wet && trk.lamps; });
    mirrorHolder.visible = hi;
    redStreakMat.opacity = g ? 0 : 0.5; glowSpriteMat.opacity = g ? 0.3 : 1; glowWhiteMat.opacity = g ? 0.12 : (trk.lamps ? 0.9 : 0.35);
    scene.environment = g ? envGarage : envRoadCur;
    scene.fog.density = g ? 0.0016 : trk.dens;
    scene.fog.color.setHex(g ? 0x07090d : trk.fog); scene.background.setHex(g ? 0x07090d : trk.fog);
    renderer.toneMappingExposure = g ? 1.15 : trk.expo;
    $('menu').hidden = m !== 'menu'; $('garage').hidden = !g;
    $('dof').hidden = !(m === 'play' && hi);
    if (m === 'menu' || g) $('ui').hidden = true;
    voKey = '';
  }

  /* ---------- controls ---------- */
  var keys = {}, btnDir = 0, nitroHold = false, kb = 0;
  var wAng = 0, wDrag = null, tiltSteer = 0, tiltBase = null, tiltSeen = false, tiltOn = false;
  function setKey(e, v) {
    var k = e.key, used = true;
    if (k === 'ArrowLeft' || k === 'a' || k === 'A') keys.l = v;
    else if (k === 'ArrowRight' || k === 'd' || k === 'D') keys.r = v;
    else if (k === 'ArrowUp' || k === 'w' || k === 'W') keys.a = v;
    else if (k === 'Shift') keys.t = v;
    else if (k === 'ArrowDown' || k === 's' || k === 'S' || k === ' ') keys.b = v;
    else used = false;
    if (used) e.preventDefault();
  }
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && mode === 'play') { setPaused(!paused); return; }
    if (paused) return;
    if (mode === 'garage') {
      if (e.key === 'ArrowLeft') { garageStep(-1); e.preventDefault(); }
      if (e.key === 'ArrowRight') { garageStep(1); e.preventDefault(); }
      if (e.key === 'Escape') leaveGarage();
      return;
    }
    if (e.key === 'Enter' && (mode === 'menu' || !$('over').hidden) && !(e.target && e.target.tagName === 'BUTTON')) { startGame(); return; }
    setKey(e, true);
  });
  window.addEventListener('keyup', function (e) { setKey(e, false); });
  window.addEventListener('blur', function () { keys = {}; btnDir = 0; nitroHold = false; wDrag = null; if (mode === 'play') setPaused(true); });
  document.addEventListener('visibilitychange', function () { if (document.hidden && mode === 'play') setPaused(true); });

  var wheelEl = $('wheel'), wheelSvg = $('wheelSvg');
  wheelEl.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    var r = wheelEl.getBoundingClientRect();
    wDrag = { id: e.pointerId, a: Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)) };
    try { wheelEl.setPointerCapture(e.pointerId); } catch (err) {}
  });
  wheelEl.addEventListener('pointermove', function (e) {
    if (!wDrag || e.pointerId !== wDrag.id) return;
    var r = wheelEl.getBoundingClientRect();
    var a = Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2));
    var d = (a - wDrag.a) * 180 / Math.PI;
    while (d > 180) d -= 360;
    while (d < -180) d += 360;
    wAng = clamp(wAng + d, -135, 135); wDrag.a = a;
  });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (n) { wheelEl.addEventListener(n, function () { wDrag = null; }); });
  function holdBtn(el, dir) {
    el.addEventListener('pointerdown', function (e) { e.preventDefault(); btnDir = dir; el.classList.add('on'); try { el.setPointerCapture(e.pointerId); } catch (err) {} });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (n) {
      el.addEventListener(n, function () { if (btnDir === dir) btnDir = 0; el.classList.remove('on'); });
    });
  }
  holdBtn($('btnL'), -1); holdBtn($('btnR'), 1);
  var turboEl = $('turbo'), brakeEl = $('brake');
  brakeEl.addEventListener('pointerdown', function (e) { e.preventDefault(); keys.b = true; brakeEl.classList.add('on'); try { brakeEl.setPointerCapture(e.pointerId); } catch (err) {} });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (n) { brakeEl.addEventListener(n, function () { keys.b = false; brakeEl.classList.remove('on'); }); });
  turboEl.addEventListener('pointerdown', function (e) { e.preventDefault(); nitroHold = true; try { turboEl.setPointerCapture(e.pointerId); } catch (err) {} });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (n) { turboEl.addEventListener(n, function () { nitroHold = false; }); });

  // garage: drag to orbit
  var glEl = $('gl');
  glEl.addEventListener('pointerdown', function (e) {
    if (mode !== 'garage') return;
    gDrag = { id: e.pointerId, x: e.clientX, y: e.clientY }; gVel = 0;
    try { glEl.setPointerCapture(e.pointerId); } catch (err) {}
  });
  glEl.addEventListener('pointermove', function (e) {
    if (!gDrag || e.pointerId !== gDrag.id) return;
    var dx = e.clientX - gDrag.x, dy = e.clientY - gDrag.y;
    gDrag.x = e.clientX; gDrag.y = e.clientY;
    gAng -= dx * 0.009; gVel = -dx * 0.54; gH = clamp(gH + dy * 0.012, 0.5, 3.6); gLast = time;
  });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (n) { glEl.addEventListener(n, function () { gDrag = null; gLast = time; }); });

  function onOrient(e) {
    var ang = (screen.orientation && typeof screen.orientation.angle === 'number') ? screen.orientation.angle : (typeof window.orientation === 'number' ? window.orientation : 0);
    var v = ang === 90 ? -e.beta : ang === 270 || ang === -90 ? e.beta : e.gamma;
    if (typeof v !== 'number' || isNaN(v)) return;
    tiltSeen = true;
    if (tiltBase === null) tiltBase = v;
    var d = v - tiltBase;
    if (Math.abs(d) < 2) d = 0;
    tiltSteer = clamp(d / 24, -1, 1);
  }
  function enableTilt() {
    if (tiltOn) { tiltBase = null; return; }
    function attach() {
      tiltOn = true; tiltBase = null; tiltSeen = false;
      window.addEventListener('deviceorientation', onOrient);
      setTimeout(function () {
        if (!tiltSeen && save.ctrl === 'tilt') { toast('Датчик наклона недоступен в этом окне. Включён руль.', 4000); setCtrl('wheel'); }
      }, 1600);
    }
    try {
      if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
        DeviceOrientationEvent.requestPermission().then(function (r) {
          if (r === 'granted') attach(); else { toast('Доступ к датчику не выдан. Включён руль.', 4000); setCtrl('wheel'); }
        }).catch(function () { setCtrl('wheel'); });
      } else attach();
    } catch (e) { setCtrl('wheel'); }
  }
  function steerValue(dt) {
    var tgt = clamp((keys.r ? 1 : 0) - (keys.l ? 1 : 0) + btnDir, -1, 1);
    var rate = (tgt !== 0 ? 3.4 : 5.5) * dt;
    kb += clamp(tgt - kb, -rate, rate);
    if (!wDrag) wAng *= Math.max(0, 1 - dt * 7);
    var s = kb;
    if (save.ctrl === 'wheel') s += wAng / 110;
    if (save.ctrl === 'tilt') s += tiltSteer;
    return clamp(s * steerSensitivity, -1, 1);
  }

  /* ---------- menu + garage UI ---------- */
  function setCtrl(c) {
    save.ctrl = c; persist();
    Array.prototype.forEach.call(document.querySelectorAll('#ctrlSeg button'), function (b) { b.setAttribute('aria-checked', b.dataset.c === c ? 'true' : 'false'); });
    $('wheel').hidden = c !== 'wheel'; $('arrows').hidden = c !== 'arrows'; $('tiltBox').hidden = c !== 'tilt';
  }
  Array.prototype.forEach.call(document.querySelectorAll('#ctrlSeg button'), function (b) { b.addEventListener('click', function () { setCtrl(b.dataset.c); }); });
  function setQuality(q) {
    save.quality = q; persist();
    Array.prototype.forEach.call(document.querySelectorAll('#qSeg button'), function (b) { b.setAttribute('aria-checked', b.dataset.q === q ? 'true' : 'false'); });
    resize(); enterMode(mode);
  }
  Array.prototype.forEach.call(document.querySelectorAll('#qSeg button'), function (b) { b.addEventListener('click', function () { setQuality(b.dataset.q); }); });
  function soundLabel() { $('soundBtn').textContent = save.sound ? 'Звук: вкл' : 'Звук: выкл'; }
  $('soundBtn').addEventListener('click', function () { save.sound = !save.sound; persist(); soundLabel(); if (save.sound) initAudio(); });
  soundLabel();

  function refreshMenu() {
    $('mBest').textContent = save.best; $('mTotal').textContent = save.total; $('gCoins').textContent = save.total;
    $('mCarName').textContent = curCar.brand + ' ' + curCar.name;
    $('mCarSub').textContent = curCar.hp + ' л.с. · 0–100 за ' + fnum(curCar.t100) + ' с · до ' + curCar.vmax + ' км/ч';
  }

  var gSw = $('gSw'), gDots = $('gDots');
  PAINT_COLORS.forEach(function (c, i) {
    var b = document.createElement('button');
    b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-label', PAINT_NAMES[i]); b.title = PAINT_NAMES[i];
    b.style.background = '#' + ('000000' + c.toString(16)).slice(-6);
    b.addEventListener('click', function () {
      var id = CARS[gIndex].id; save.colors[id] = i; persist();
      getRec(id).paint.color.setHex(c); refreshGarage();
    });
    gSw.appendChild(b);
  });
  CARS.forEach(function () { gDots.appendChild(document.createElement('i')); });
  Array.prototype.forEach.call(document.querySelectorAll('#gFinish button'), function (b) {
    b.addEventListener('click', function () {
      var id = CARS[gIndex].id, m = b.dataset.m === '1';
      save.matte[id] = m; persist(); applyFinish(getRec(id).paint, m); refreshGarage();
    });
  });

  function refreshGarage() {
    var c = CARS[gIndex], p = perf(c);
    $('gBrand').textContent = c.brand; $('gName').textContent = c.name; $('gGen').textContent = c.gen;
    $('gEngine').textContent = c.engine;
    var items = [
      ['Мощность', c.hp + ' л.с.', c.hp / 1250],
      ['Крутящий момент', c.nm + ' Н·м', c.nm / 1600],
      ['0–100 км/ч', fnum(c.t100) + ' с', (4.2 - c.t100) / 2.2],
      ['Макс. скорость', c.vmax + ' км/ч', c.vmax / 360],
      ['Масса', fint(c.kg) + ' кг', c.kg / 2600],
      ['Привод', c.drive, null]
    ];
    var html = '';
    items.forEach(function (it) {
      html += '<div class="spec"><div class="k">' + it[0] + '</div><div class="v">' + it[1] + '</div>' +
        (it[2] === null ? '' : '<div class="b"><i style="width:' + Math.round(clamp(it[2], 0.04, 1) * 100) + '%"></i></div>') + '</div>';
    });
    $('gSpecs').innerHTML = html;
    $('gSw').parentNode.hidden = !!c.fixedPaint;
    Array.prototype.forEach.call(gDots.children, function (d, i) { d.className = i === gIndex ? 'on' : ''; });
    Array.prototype.forEach.call(gSw.children, function (b, i) { b.setAttribute('aria-checked', i === colorOf(c.id) ? 'true' : 'false'); });
    Array.prototype.forEach.call(document.querySelectorAll('#gFinish button'), function (b) { b.setAttribute('aria-checked', (b.dataset.m === '1') === !!save.matte[c.id] ? 'true' : 'false'); });
    var act = $('gAction'), own = $('gOwn');
    if (owned(c.id)) {
      var sel = save.sel === c.id;
      act.textContent = sel ? 'Выбрана' : 'Выбрать'; act.disabled = sel; own.textContent = sel ? '' : 'В гараже';
    } else {
      var lack = c.price - save.total;
      act.textContent = 'Купить за ' + fint(c.price); act.disabled = lack > 0;
      own.textContent = lack > 0 ? 'Не хватает ' + fint(lack) : '';
    }
    $('gCoins').textContent = save.total;
  }
  function showGarageCar(i) {
    gIndex = (i + CARS.length) % CARS.length;
    var id = CARS[gIndex].id, rec = getRec(id);
    setPlayerCar(id);
    mirrorHolder.children.slice().forEach(function (ch) { mirrorHolder.remove(ch); });
    var mr = rec.group.clone(true); mr.scale.set(1, -1, 1); var spr = []; mr.traverse(function (o) { if (o.isSprite) spr.push(o); }); spr.forEach(function (o) { o.parent.remove(o); }); mirrorHolder.add(mr);
    refreshGarage();
  }
  function garageStep(d) { cut(); showGarageCar(gIndex + d); }
  $('gPrev').addEventListener('click', function () { garageStep(-1); });
  $('gNext').addEventListener('click', function () { garageStep(1); });
  $('gAction').addEventListener('click', function () {
    var c = CARS[gIndex];
    if (!owned(c.id)) {
      if (save.total < c.price) return;
      save.total -= c.price; save.owned.push(c.id); toast(c.brand + ' ' + c.name + ' теперь в вашем гараже');
    }
    save.sel = c.id; persist(); refreshGarage(); refreshMenu();
  });
  function openGarage() {
    cut(); clearCars(); gIndex = Math.max(0, CARS.indexOf(carById(save.sel)));
    enterMode('garage'); gLast = time; gAng = 0.7; gH = 1.7;
    showGarageCar(gIndex);
  }
  function leaveGarage() {
    cut(); setPlayerCar(save.sel); enterMode('menu'); refreshMenu();
  }
  $('garageBtn').addEventListener('click', openGarage);
  $('overGarage').addEventListener('click', function () { $('over').hidden = true; openGarage(); });
  $('gBack').addEventListener('click', leaveGarage);
  setCtrl(save.ctrl); Array.prototype.forEach.call(document.querySelectorAll('#qSeg button'), function (b) { b.setAttribute('aria-checked', b.dataset.q === save.quality ? 'true' : 'false'); });
  var trSeg = $('trSeg');
  TRACKS.forEach(function (t) {
    var b = document.createElement('button'); b.type = 'button'; b.setAttribute('role', 'radio'); b.dataset.t = t.id; b.textContent = t.name;
    b.addEventListener('click', function () { save.track = t.id; persist(); applyTrack(t.id); enterMode('menu'); syncTr(); });
    trSeg.appendChild(b);
  });
  function syncTr() { Array.prototype.forEach.call(trSeg.children, function (b) { b.setAttribute('aria-checked', b.dataset.t === trk.id ? 'true' : 'false'); }); }
  function syncDrive() {
    var d = save.drive === 'drift';
    $('modeBtn').textContent = d ? 'Дрифт' : 'Спорт'; $('modeBtn').classList.toggle('drift', d);
    Array.prototype.forEach.call($('driveSeg').children, function (b) { b.setAttribute('aria-checked', b.dataset.d === save.drive ? 'true' : 'false'); });
  }
  function setDrive(d) { save.drive = d; persist(); syncDrive(); }
  Array.prototype.forEach.call($('driveSeg').children, function (b) { b.addEventListener('click', function () { setDrive(b.dataset.d); }); });
  $('modeBtn').addEventListener('click', function () { setDrive(save.drive === 'drift' ? 'sport' : 'drift'); toast(save.drive === 'drift' ? 'Дрифт: машину заносит, очки за скольжение' : 'Спорт: точное управление'); });
  syncDrive();
  applyTrack(save.track); syncTr();
  enterMode('menu'); refreshMenu();

  /* ---------- HUD helpers ---------- */
  var ledsEl = $('leds'), LEDS = 16;
  for (var ld = 0; ld < LEDS; ld++) ledsEl.appendChild(document.createElement('i'));

  /* ---------- audio ---------- */
  var AC = null, eng = null;
/*SYNTH_BEGIN*/
  function mkRnd(seed) { var s = seed >>> 0; return function () { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
  function synthEngine(sr, p, R) {
    var rnd = mkRnd(p.seed * 7919 + Math.round(R)), TP = Math.PI * 2;
    var cycT = 120 / R, k = Math.max(1, Math.round(1.5 / cycT)), N = Math.round(k * cycT * sr);
    var d = new Float32Array(N), nf = k * p.cyl, per = N / nf, i, j, m, h;
    var L = Math.min(N, Math.round(sr * p.tau * 6)), tab = new Float32Array(L);
    for (m = 0; m < L; m++) {
      var t = m / sr, env = (1 - Math.exp(-t / 0.00025)) * Math.exp(-t / p.tau);
      tab[m] = env * (Math.sin(TP * p.fr * t) + p.rasp * 0.6 * Math.sin(TP * p.fr * 2.37 * t + 1.3) + 0.5 * Math.sin(TP * p.fr * 0.5 * t + 0.4));
    }
    for (j = 0; j < nf; j++) {
      var amp = 1 + (rnd() - 0.5) * p.rough * 2, off = (rnd() - 0.5) * p.uneven * per + (j % 2 ? 1 : -1) * p.pair * per * 0.25;
      var i0 = Math.round(j * per + off);
      for (m = 0; m < L; m++) { var ix = (i0 + m) % N; if (ix < 0) ix += N; d[ix] += tab[m] * amp; }
    }
    var f0 = R / 120;
    for (h = 1; h <= 44; h++) {
      var fh = h * f0; if (fh > 7000) break;
      var a = p.body * Math.pow(h, -0.7) * (h % p.cyl === 0 ? 3 : (h % (p.cyl / 2) === 0 ? 1.6 : 1)), ph = rnd() * TP, w = TP * h * k / N;
      var c2 = 2 * Math.cos(w), s1 = Math.sin(ph - w), s2 = Math.sin(ph - 2 * w);
      for (i = 0; i < N; i++) { var s0 = c2 * s1 - s2; s2 = s1; s1 = s0; d[i] += a * s0; }
    }
    var nz = new Float32Array(N), a1 = 1 - Math.exp(-TP * p.nfc / sr), y = 0, pass;
    for (i = 0; i < N; i++) nz[i] = rnd() * 2 - 1;
    for (pass = 0; pass < 2; pass++) for (i = 0; i < N; i++) { y += a1 * (nz[i] - y); nz[i] = y; }
    var ns = 1 / Math.sqrt(a1 / (2 - a1));
    for (i = 0; i < N; i++) { var e = 0.5 + 0.5 * Math.cos(TP * i / per); d[i] += nz[i] * ns * p.rasp * 0.35 * e * e; }
    var mean = 0, pk = 1e-6;
    for (i = 0; i < N; i++) mean += d[i]; mean /= N;
    for (i = 0; i < N; i++) { d[i] -= mean; if (Math.abs(d[i]) > pk) pk = Math.abs(d[i]); }
    for (i = 0; i < N; i++) d[i] = Math.tanh(1.5 * d[i] / pk) * 0.85;
    return d;
  }
  function synthPop(sr, kind) {
    // dry, broadband exhaust crackle: sharp noise crack + short cavity thump + diffuse tail (no tonal ringing)
    var rnd = mkRnd(4242 + kind * 77), TP = Math.PI * 2, big = kind >= 4, n = Math.round((big ? 0.9 : 0.5) * sr), d = new Float32Array(n), i, pk = 1e-6;
    var fc = [3300, 2500, 2900, 1900, 1500, 1200][kind], tauC = [0.006, 0.009, 0.0075, 0.016, 0.024, 0.032][kind];
    var bf = [220, 175, 195, 145, 105, 80][kind], bt = [0.022, 0.035, 0.03, 0.065, 0.11, 0.17][kind], ba = [0.1, 0.17, 0.14, 0.38, 0.8, 1.2][kind];
    var r = 0.84, c1 = 2 * r * Math.cos(TP * fc / sr), c2 = r * r;
    function addHit(t0, amp) {
      var s0 = Math.round(t0 * sr), j, y1 = 0, y2 = 0, prev = 0, lp = 0, lt = 0;
      for (j = 0; s0 + j < n && j < 0.6 * sr; j++) {
        var t = j / sr, wn = rnd() * 2 - 1;
        var att = 1 - Math.exp(-t / 0.0003);
        var y = wn * att * Math.exp(-t / tauC) + c1 * y1 - c2 * y2; y2 = y1; y1 = y;
        var hp = (wn - prev) * 0.5; prev = wn;
        lp += 0.07 * (wn - lp);
        lt += 0.22 * (wn - lt);
        var crack = y * 0.9 + hp * att * Math.exp(-t / (tauC * 0.6)) * 1.5;
        var body = Math.sin(TP * bf * (1 + 0.3 * Math.exp(-t / 0.02)) * t) * Math.exp(-t / bt) * ba + lp * Math.exp(-t / (bt * 0.9)) * ba * 2.2;
        var tail = lt * (t > 0.008 ? Math.exp(-(t - 0.008) / (big ? 0.2 : 0.08)) : t / 0.008) * 0.14;
        d[s0 + j] += (crack + body + tail) * amp;
      }
    }
    addHit(0, 1);
    if (kind === 2) addHit(0.032, 0.5);
    if (kind === 5) { addHit(0.055, 0.38); addHit(0.12, 0.22); }
    var fade = big ? 0.8 : 0.42;
    for (i = 0; i < n; i++) { var tt = i / sr; if (tt > fade) d[i] *= Math.max(0, 1 - (tt - fade) / 0.08); if (Math.abs(d[i]) > pk) pk = Math.abs(d[i]); }
    for (i = 0; i < n; i++) d[i] = Math.tanh(1.25 * d[i] / pk) * 0.95;
    return d;
  }
  function synthBov(sr, flutter) {
    var rnd = mkRnd(991), n = Math.round(0.75 * sr), d = new Float32Array(n), i, lp = 0, lp2 = 0, prev = 0, pk = 1e-6;
    for (i = 0; i < n; i++) {
      var t = i / sr, wn = rnd() * 2 - 1;
      var hp = wn - prev; prev = wn; lp += 0.5 * (hp - lp); lp2 += 0.35 * (lp - lp2);
      var env = Math.min(1, t / 0.012) * Math.exp(-t / (flutter ? 0.2 : 0.14));
      if (flutter) env *= (Math.sin(t * 2 * Math.PI * 13) > -0.15 ? 1 : 0.12);
      d[i] = lp2 * env;
      if (Math.abs(d[i]) > pk) pk = Math.abs(d[i]);
    }
    for (i = 0; i < n; i++) d[i] = d[i] / pk * 0.9;
    return d;
  }
  function synthWhoosh(sr) {
    var rnd = mkRnd(31337), n = Math.round(1.3 * sr), d = new Float32Array(n), i, y = 0, pk = 1e-6;
    for (i = 0; i < n; i++) {
      var t = i / sr, a = 0.02 + 0.5 * Math.min(1, t / 0.5), wn = rnd() * 2 - 1;
      y += a * (wn - y);
      var env = Math.min(1, t / 0.06) * Math.exp(-Math.max(0, t - 0.15) / 0.5);
      d[i] = y * env; if (Math.abs(d[i]) > pk) pk = Math.abs(d[i]);
    }
    for (i = 0; i < n; i++) d[i] = d[i] / pk * 0.9;
    return d;
  }

  function synthCrash(sr) {
    var rnd = mkRnd(5150), TP = Math.PI * 2, n = Math.round(2.6 * sr), d = new Float32Array(n), i, b, k, pk = 1e-6;
    var nb = Math.round(1.0 * sr);
    for (i = 0; i < nb; i++) { var t = i / sr; d[i] += Math.sin(TP * (36 + 80 * Math.exp(-t / 0.05)) * t) * Math.exp(-t / 0.24) * 1.1; }
    for (b = 0; b < 8; b++) {
      var t0 = b === 0 ? 0 : 0.03 + rnd() * 0.5, dur = 0.05 + rnd() * 0.11, f = 450 + rnd() * 2400, r = 0.955 + rnd() * 0.035, c1 = 2 * r * Math.cos(TP * f / sr), c2 = r * r, y1 = 0, y2 = 0;
      var s0 = Math.round(t0 * sr), len = Math.round(dur * 6 * sr), amp = (b === 0 ? 1 : 0.6) * (0.6 + rnd() * 0.5);
      for (k = 0; k < len && s0 + k < n; k++) {
        var tt = k / sr, x = (rnd() * 2 - 1) * Math.exp(-tt / dur) * 0.12 * amp, y = x + c1 * y1 - c2 * y2; y2 = y1; y1 = y; d[s0 + k] += y;
      }
    }
    for (k = 0; k < 34; k++) {
      var tg = Math.pow(rnd(), 1.7) * 1.5 + 0.02, fg = 2800 + rnd() * 5200, dg = 0.02 + rnd() * 0.07, ag = (0.08 + rnd() * 0.2) * (1 - tg / 2.2), sg = Math.round(tg * sr), lg = Math.round(dg * 5 * sr);
      for (i = 0; i < lg && sg + i < n; i++) { var u = i / sr; d[sg + i] += (Math.sin(TP * fg * u) * 0.8 + (rnd() * 2 - 1) * 0.25) * Math.exp(-u / dg) * ag; }
    }
    var lp1 = 0, lp2 = 0, lfo = 0, lfoT = 0;
    for (i = Math.round(0.08 * sr); i < Math.round(1.9 * sr); i++) {
      var ts = i / sr; if (i % 900 === 0) lfoT = rnd();
      lfo += (lfoT - lfo) * 0.002;
      var wn = rnd() * 2 - 1; lp1 += 0.28 * (wn - lp1); lp2 += 0.04 * (wn - lp2);
      d[i] += (lp1 - lp2) * 1.6 * lfo * Math.exp(-(ts - 0.08) / 0.75) * (ts < 0.1 ? (ts - 0.08) / 0.02 : 1);
    }
    for (i = Math.round(0.06 * sr); i < Math.round(0.95 * sr); i++) {
      var tq = i / sr, fq = 1150 - 380 * tq + 40 * Math.sin(TP * 7 * tq);
      var ph = TP * fq * tq, w = Math.sin(ph) + 0.5 * Math.sin(2 * ph) + 0.3 * Math.sin(3 * ph);
      d[i] += w * 0.09 * Math.exp(-(tq - 0.06) / 0.45) * Math.min(1, (tq - 0.06) / 0.03);
    }
    var hp = 0, prev = 0;
    for (i = Math.round(0.3 * sr); i < n; i++) {
      var th = i / sr, w2 = rnd() * 2 - 1; hp = w2 - prev; prev = w2;
      d[i] += hp * 0.07 * Math.exp(-(th - 0.3) / 0.9) * Math.min(1, (th - 0.3) / 0.15);
    }
    for (i = 0; i < n; i++) if (Math.abs(d[i]) > pk) pk = Math.abs(d[i]);
    for (i = 0; i < n; i++) d[i] = Math.tanh(1.6 * d[i] / pk) * 0.95 * (i > n - 2000 ? (n - i) / 2000 : 1);
    return d;
  }
/*SYNTH_END*/

  function layerRpms(sp) {
    var a = sp.lo * 0.88, b = sp.hi * 1.03, n = 6, out = [], i;
    for (i = 0; i < n; i++) out.push(a * Math.pow(b / a, i / (n - 1)));
    return out;
  }
  function mkBuf(d) { var b = AC.createBuffer(1, d.length, AC.sampleRate); b.getChannelData(0).set(d); return b; }
  function initAudio() {
    if (!save.sound) return;
    try {
      if (!AC) {
        AC = new (window.AudioContext || window.webkitAudioContext)();
        var master = AC.createGain(); master.gain.value = 1.25 * audioMix.master;
        var comp = AC.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 14; comp.ratio.value = 5; comp.attack.value = 0.004; comp.release.value = 0.22;
        master.connect(comp); comp.connect(AC.destination);
        var sr = AC.sampleRate, i;
        eng = { master: master, layers: null, car: null, cache: {}, building: false, boost: 0, sp: null, pops: [], bov: mkBuf(synthBov(sr, false)), flut: mkBuf(synthBov(sr, true)), whoosh: mkBuf(synthWhoosh(sr)) };
        eng.bangs = [];
        for (i = 0; i < 4; i++) eng.pops.push(mkBuf(synthPop(sr, i)));
        for (i = 4; i < 6; i++) eng.bangs.push(mkBuf(synthPop(sr, i)));
        eng.crash = mkBuf(synthCrash(sr));
        // engine bus: layers -> tone -> duck -> master
        eng.bus = AC.createGain(); eng.bus.gain.value = 0;
        eng.tone = AC.createBiquadFilter(); eng.tone.type = 'lowpass'; eng.tone.frequency.value = 3000; eng.tone.Q.value = 0.6;
        eng.duck = AC.createGain(); eng.duck.gain.value = 1;
        eng.bus.connect(eng.tone); eng.tone.connect(eng.duck); eng.duck.connect(master);
        // shared noise loop for wind / intake
        var nn = sr * 2, nb = AC.createBuffer(1, nn, sr), nd = nb.getChannelData(0), rr = mkRnd(77);
        for (i = 0; i < nn; i++) nd[i] = rr() * 2 - 1;
        eng.wind = AC.createBufferSource(); eng.wind.buffer = nb; eng.wind.loop = true;
        eng.windF = AC.createBiquadFilter(); eng.windF.type = 'bandpass'; eng.windF.Q.value = 0.5; eng.windF.frequency.value = 600;
        eng.windG = AC.createGain(); eng.windG.gain.value = 0;
        eng.wind.connect(eng.windF); eng.windF.connect(eng.windG); eng.windG.connect(master); eng.wind.start();
        eng.intake = AC.createBufferSource(); eng.intake.buffer = nb; eng.intake.loop = true; eng.intake.loopStart = 0.37;
        eng.intF = AC.createBiquadFilter(); eng.intF.type = 'bandpass'; eng.intF.Q.value = 1.3; eng.intF.frequency.value = 900;
        eng.intG = AC.createGain(); eng.intG.gain.value = 0;
        eng.intake.connect(eng.intF); eng.intF.connect(eng.intG); eng.intG.connect(eng.bus); eng.intake.start();
        // tyre squeal
        eng.sq = AC.createBufferSource(); eng.sq.buffer = nb; eng.sq.loop = true; eng.sq.loopStart = 0.81;
        eng.sqF = AC.createBiquadFilter(); eng.sqF.type = 'bandpass'; eng.sqF.Q.value = 7; eng.sqF.frequency.value = 1700;
        eng.sqG = AC.createGain(); eng.sqG.gain.value = 0;
        eng.sq.connect(eng.sqF); eng.sqF.connect(eng.sqG); eng.sqG.connect(master); eng.sq.start();
        // turbo whistle
        eng.wh1 = AC.createOscillator(); eng.wh1.type = 'sine'; eng.wh2 = AC.createOscillator(); eng.wh2.type = 'triangle';
        eng.whG = AC.createGain(); eng.whG.gain.value = 0; var wg2 = AC.createGain(); wg2.gain.value = 0.35;
        eng.wh1.connect(eng.whG); eng.wh2.connect(wg2); wg2.connect(eng.whG); eng.whG.connect(master);
        eng.wh1.start(); eng.wh2.start();
      }
      if (AC.state === 'suspended') AC.resume();
      engBuild(curCar.id);
    } catch (e) { AC = null; eng = null; }
  }
  function engBuild(id) {
    if (!AC || !eng || eng.car === id || eng.building) return;
    var sp = carById(id).snd; if (!sp) return;
    if (eng.cache[id]) { engUse(id, eng.cache[id]); return; }
    eng.building = true;
    var rs = layerRpms(sp), bufs = [], i = 0, sr = AC.sampleRate;
    (function next() {
      try {
        if (!AC) return;
        if (i >= rs.length) { eng.cache[id] = bufs; eng.building = false; engUse(id, bufs); if (eng.car !== curCar.id) engBuild(curCar.id); return; }
        bufs.push(mkBuf(synthEngine(sr, sp, rs[i]))); i++; setTimeout(next, 16);
      } catch (e) { eng.building = false; }
    })();
  }
  function engUse(id, bufs) {
    if (eng.layers) eng.layers.forEach(function (l) { try { l.src.stop(); l.src.disconnect(); l.g.disconnect(); } catch (e) {} });
    var sp = carById(id).snd, rs = layerRpms(sp);
    eng.layers = bufs.map(function (b, i) {
      var s = AC.createBufferSource(); s.buffer = b; s.loop = true;
      var g = AC.createGain(); g.gain.value = 0; s.connect(g); g.connect(eng.bus); s.start(0, Math.random() * 0.5);
      return { src: s, g: g, R: rs[i] };
    });
    eng.car = id; eng.sp = sp;
    eng.wh1.frequency.value = sp.wh; eng.wh2.frequency.value = sp.wh * 1.5;
  }
  function audioUpdate() {
    if (!AC || !eng || !eng.layers) return;
    var t = AC.currentTime, sp = eng.sp, on = save.sound && (mode === 'play' || mode === 'crash') ? 1 : 0;
    var alive = mode === 'play' ? 1 : (mode === 'crash' ? Math.max(0, 1 - crashT * 1.1) : 0);
    var fr = clamp((rpm - 2800) / 4700, 0, 1), Re = sp.lo + (sp.hi - sp.lo) * fr, load = clamp(throttle, 0, 1);
    var ls = eng.layers, n = ls.length, i0 = 0, i;
    while (i0 < n - 2 && Re > ls[i0 + 1].R) i0++;
    var w = clamp(Math.log(Re / ls[i0].R) / Math.log(ls[i0 + 1].R / ls[i0].R), 0, 1);
    for (i = 0; i < n; i++) {
      var gg = i === i0 ? Math.cos(w * Math.PI / 2) : (i === i0 + 1 ? Math.sin(w * Math.PI / 2) : 0);
      ls[i].g.gain.setTargetAtTime(gg, t, 0.03);
      if (gg > 0.001) ls[i].src.playbackRate.setTargetAtTime(clamp(Re / ls[i].R, 0.5, 2), t, 0.03);
    }
    eng.bus.gain.setTargetAtTime(on * alive * sp.vol * 1.45 * audioMix.engine * (0.3 + 0.5 * load + 0.2 * fr), t, 0.06);
    eng.tone.frequency.setTargetAtTime(1300 + load * 4800 + fr * 2600 + (nitroOn ? 1500 : 0), t, 0.08);
    var tb = sp.turbo ? clamp((load - 0.3) / 0.7, 0, 1) * clamp(fr * 1.5, 0, 1) : 0;
    eng.boost += (tb - eng.boost) * 0.07;
    eng.wh1.frequency.setTargetAtTime(sp.wh * (0.45 + 0.95 * eng.boost), t, 0.1);
    eng.wh2.frequency.setTargetAtTime(sp.wh * 1.5 * (0.45 + 0.95 * eng.boost), t, 0.1);
    eng.whG.gain.setTargetAtTime(on * alive * eng.boost * sp.whv, t, 0.1);
    eng.windG.gain.setTargetAtTime(on * alive * Math.pow(clamp(speed / 300, 0, 1), 1.6) * 0.22, t, 0.15);
    eng.windF.frequency.setTargetAtTime(350 + speed * 4.5, t, 0.2);
    var slipA = mode === 'play' && DRF.on ? clamp((Math.abs(player.yaw) - 0.15) / 0.4, 0, 1) : (mode === 'crash' && speed > 25 ? 0.5 : 0);
    eng.sqG.gain.setTargetAtTime(on * slipA * clamp(speed / 90, 0, 1) * 1.1, t, 0.06);
    eng.sqF.frequency.setTargetAtTime(1500 + slipA * 900 + speed * 2 + (Math.sin(time * 9) * 80), t, 0.05);
    eng.intF.frequency.setTargetAtTime(500 + Re * 0.35, t, 0.1);
    eng.intG.gain.setTargetAtTime(on * alive * sp.intake * (0.05 + load * 0.5) * (0.4 + fr), t, 0.1);
  }
  function sndPlay(buf, vol, rate) {
    var s = AC.createBufferSource(), g = AC.createGain();
    s.buffer = buf; s.playbackRate.value = rate; g.gain.value = vol * audioMix.effects; s.connect(g); g.connect(eng.master); s.start();
  }
  function sndPop(str, att) {
    if (!AC || !eng || !eng.sp || !save.sound) return;
    att = att === undefined ? 1 : att; if (att < 0.03) return;
    try {
      var big = str > 0.72, arr = big ? eng.bangs : eng.pops;
      sndPlay(arr[(Math.random() * arr.length) | 0], clamp(0.4 + 0.9 * str, 0, 1.5) * eng.sp.pop * (big ? 1.5 : 1.7) * att, (big ? 0.96 : 0.94) + Math.random() * 0.12);
    } catch (e) {}
  }
  function sndBov() {
    if (!AC || !eng || !eng.sp || !save.sound || !eng.sp.turbo || eng.boost < 0.25) return;
    try { sndPlay(eng.sp.flutter ? eng.flut : eng.bov, 0.8 * eng.sp.bov, 0.95 + Math.random() * 0.1); } catch (e) {}
  }
  function sndHit(att) {
    if (!AC || !eng || !eng.crash || !save.sound || att < 0.03) return;
    try { sndPlay(eng.crash, 0.45 * att, 1.25 + Math.random() * 0.2); } catch (e) {}
  }
  function sndWhoosh() {
    if (!AC || !eng || !save.sound) return;
    try { sndPlay(eng.whoosh, 0.8, 1); } catch (e) {}
  }
  function sndCut() {
    if (!AC || !eng || !save.sound) return;
    try { var t = AC.currentTime; eng.duck.gain.cancelScheduledValues(t); eng.duck.gain.setValueAtTime(0.45, t); eng.duck.gain.linearRampToValueAtTime(1, t + 0.05); } catch (e) {}
  }
  function sndShift() {
    if (!AC || !eng || !save.sound) return;
    try { var t = AC.currentTime; eng.duck.gain.cancelScheduledValues(t); eng.duck.gain.setValueAtTime(0.18, t); eng.duck.gain.linearRampToValueAtTime(1, t + 0.16); } catch (e) {}
  }
  function crashSound(sev) {
    if (!AC || !save.sound) return;
    sev = sev || 1;
    try {
      if (eng && eng.crash) {
        sndPlay(eng.crash, clamp(0.6 + 0.6 * sev, 0.7, 1.4), 0.96 + Math.random() * 0.08);
        sndPlay(eng.crash, 0.35 * sev, 0.62);
        return;
      }
      var n = AC.sampleRate * 0.6, buf = AC.createBuffer(1, n, AC.sampleRate), d = buf.getChannelData(0);
      for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.2);
      var s = AC.createBufferSource(); s.buffer = buf;
      var g = AC.createGain(); g.gain.value = 0.5;
      var f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1400;
      s.connect(f); f.connect(g); g.connect(AC.destination); s.start();
    } catch (e) {}
  }
  function coinSound(big) {
    if (!AC || !save.sound) return;
    try {
      var o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime;
      o.type = 'triangle'; o.frequency.setValueAtTime(big ? 988 : 784, t); o.frequency.setValueAtTime(big ? 1319 : 1175, t + 0.07);
      g.gain.setValueAtTime(Math.max(0.001, 0.07 * audioMix.effects * audioMix.master), t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
      o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + 0.26);
    } catch (e) {}
  }

  /* ---------- traffic ---------- */
  var trafficPools = {};
  function compactTraffic() {
    return effectiveQuality() === 'low' || effectiveQuality() === 'medium' ||
      (navigator.maxTouchPoints > 0 && Math.min(window.innerWidth, window.innerHeight) < 650);
  }
  function trafficLimit() { return gameType === 'extreme' ? (compactTraffic() ? 9 : 12) : (compactTraffic() ? 5 : 6); }
  function takeTraffic(kind, color) {
    var pool = trafficPools[kind] || (trafficPools[kind] = []);
    var rec = pool.pop();
    if (!rec) rec = kind === 'truck' ? makeTruck(color) : makeCar(kind, trafficPaint(color), false);
    rec.group.rotation.set(0, 0, 0);
    rec.body.rotation.set(0, 0, 0);
    return rec;
  }
  function releaseTraffic(c) {
    scene.remove(c.rec.group);
    if (!c.hit) {
      var pool = trafficPools[c.kind] || (trafficPools[c.kind] = []);
      if (pool.length < 8) pool.push(c.rec);
    }
  }
  function spawnOncoming() {
    var extreme = gameType === 'extreme', oncomingCount = 0;
    for (var j = 0; j < cars.length; j++) if (cars[j].onc && cars[j].z < 45) oncomingCount++;
    if (oncomingCount >= (extreme ? (compactTraffic() ? 5 : 8) : 6)) return false;
    var truck = Math.random() < (extreme ? 0.18 : 0.14), kind = truck ? 'truck' : ['sedan', 'suv', 'hatch', 'coupe'][(Math.random() * 4) | 0];
    var spec = truck ? TRUCK : SPEC[kind], l0 = Math.random() < 0.5 ? 0 : 1, tries, z = -380 - Math.random() * 60;
    for (tries = 0; tries < 2; tries++) {
      var l = (l0 + tries) % 2, ok = true, i;
      for (i = 0; i < cars.length; i++) if (cars[i].onc && cars[i].lane === 4 + l && Math.abs(cars[i].z - z) < (extreme ? 55 : 70)) { ok = false; break; }
      if (!ok) continue;
      var rec = takeTraffic(kind, truck ? TRUCK_COLORS[(Math.random() * TRUCK_COLORS.length) | 0] : COLORS[(Math.random() * COLORS.length) | 0]);
      var v = truck ? rand(extreme ? 80 : 65, extreme ? 105 : 85) : rand(extreme ? 100 : 80, extreme ? 155 : 125);
      rec.group.position.set(laneXO(l), 0, z); rec.group.rotation.y = Math.PI; scene.add(rec.group);
      cars.push({ lane: 4 + l, x: laneXO(l), z: z, spd: -v, len: spec.L, w: spec.W * 0.92, kind: kind, rec: rec, passed: false, minGap: 99, overlap: false, onc: true });
      return true;
    }
    return false;
  }
  var COLORS = [0xc9d1db, 0xe9ebef, 0x8793a5, 0xb83c3c, 0xd99b2b, 0x3f8f6d, 0x6a5ad6, 0x232a34, 0xd8d2c4];
  var TRUCK_COLORS = [0xb8452f, 0x3b6ea5, 0xd0a526, 0x5d6b7c];
  function clearCars() { cars.forEach(releaseTraffic); cars = []; }
  function spawnCar(z) {
    var n = 0, i, c, extreme = gameType === 'extreme';
    for (i = 0; i < cars.length; i++) { c = cars[i]; if (!c.onc && c.z < -30 && c.z > -300) n++; }
    if (n >= trafficLimit()) return false;
    var truck = Math.random() < (extreme ? 0.17 : 0.12) + Math.min(0.12, runT / 500);
    var kind = truck ? 'truck' : ['sedan', 'suv', 'hatch', 'coupe'][(Math.random() * 4) | 0];
    var spec = truck ? TRUCK : SPEC[kind];
    var order = [0, 1, 2, 3].sort(function () { return Math.random() - 0.5; });
    for (var oi = 0; oi < order.length; oi++) {
      var lane = order[oi], lo = truck ? (extreme ? 55 : 50) : (extreme ? 55 : 60), hi = truck ? (extreme ? 90 : 72) : (extreme ? 115 : 102), ok = true;
      for (i = 0; i < cars.length; i++) {
        c = cars[i]; if (c.lane !== lane) continue;
        if (Math.abs(c.z - z) < (c.len + spec.L) / 2 + (extreme ? 31 : 38)) { ok = false; break; }
        if (c.z < z) hi = Math.min(hi, c.spd); else lo = Math.max(lo, c.spd);
      }
      if (!ok || lo > hi) continue;
      var rec = takeTraffic(kind, truck ? TRUCK_COLORS[(Math.random() * TRUCK_COLORS.length) | 0] : COLORS[(Math.random() * COLORS.length) | 0]);
      rec.group.position.set(laneX(lane), 0, z);
      scene.add(rec.group);
      cars.push({ lane: lane, x: laneX(lane), z: z, spd: lo + Math.random() * (hi - lo), len: spec.L, w: spec.W * 0.92, kind: kind, rec: rec, passed: false, minGap: 99, overlap: false, shiftT: extreme && !truck ? rand(0.5, 1.7) : 999 });
      return true;
    }
    return false;
  }
  function tryTrafficShift(c) {
    if (c.kind === 'truck' || c.onc || c.hit || c.shiftTo !== undefined || c.z > -110 || c.z < -230) return;
    var choices = Math.random() < 0.5 ? [-1, 1] : [1, -1];
    for (var k = 0; k < choices.length; k++) {
      var target = c.lane + choices[k];
      if (target < 0 || target >= NL) continue;
      var targetX = laneX(target), free = true;
      for (var j = 0; j < cars.length; j++) {
        var other = cars[j];
        if (other === c || other.onc) continue;
        if (Math.abs(other.z - c.z) < 55 && (other.lane === target || Math.abs(other.x - targetX) < LANE_W * 0.8)) { free = false; break; }
      }
      if (!free) continue;
      c.lane = target; c.shiftTo = targetX;
      return;
    }
  }


  /* ---------- chase mode: two bots, 10 km, 50 levels ---------- */
  var CH = { on: false, lvl: 1, info: null, dist: 0, time: 0, bots: [], done: false, doneAt: 0, fin: false, finT: 0, win: false, stars: 0, catches: 0, busy: false };
  var CH_LEN = 3000, CH_MAX = 50, LV_TRACKS = ['night', 'desert', 'city', 'alps'];
  var BOT_DEF = [{ name: 'Оранж', color: 0xe0620f, ph: 0 }, { name: 'Синий', color: 0x1d4fb8, ph: 2.1 }];
  function levelInfo(n) {
    return { n: n, track: LV_TRACKS[Math.floor((n - 1) / 3) % 4], bot: P.top * (0.62 + 0.0076 * (n - 1)), need: n <= 15 ? 1 : 2, dens: 1 - 0.38 * (n - 1) / 49, reward: 40 + n * 3 };
  }
  function hex6(c) { return '#' + ('000000' + c.toString(16)).slice(-6); }
  function botOthers() { return CARS.filter(function (c) { return c.id !== curCar.id; }); }
  function whenModels(ids, cb, maxMs) {
    var t0 = Date.now();
    ids.forEach(function (id) { if (!modelCache[id]) loadModel(id); });
    (function poll() {
      var ok = ids.every(function (id) { return modelCache[id]; });
      if (ok || Date.now() - t0 > maxMs) cb(); else setTimeout(poll, 150);
    })();
  }
  function makeBotRec(id, color) {
    var c = carById(id), rec;
    if (modelCache[id]) {
      rec = makeModelRec(c, modelCache[id]);
      if (!c.fixedPaint) rec.paint.color.setHex(color);
    } else {
      rec = makeCar(c.shape, makePaint(color, false), true, { spoiler: c.spoiler, roof: c.roof, plate: 'BOT', blackRims: c.blackRims, grille: c.grille });
    }
    return rec;
  }
  function laneFree(l, z, ahead, behind, self) {
    var x = laneX(l), i, c;
    for (i = 0; i < cars.length; i++) { c = cars[i]; if (Math.abs(c.x - x) < 2.5 && c.z < z + behind && c.z > z - ahead) return false; }
    for (i = 0; i < CH.bots.length; i++) { c = CH.bots[i]; if (c !== self && Math.abs(c.x - x) < 2.5 && c.z < z + behind && c.z > z - ahead) return false; }
    return true;
  }
  function clearBots() {
    CH.bots.forEach(function (b) { b.sk.prev = [null, null, null, null]; scene.remove(b.rec.group); if (b.tag && b.tag.parentNode) b.tag.parentNode.removeChild(b.tag); });
    CH.bots = [];
  }
  function spawnBots() {
    clearBots();
    var oth = botOthers();
    [0, 1].forEach(function (i) {
      var id = oth[(CH.lvl + i) % oth.length].id, def = BOT_DEF[i], rec = makeBotRec(id, def.color), lane = i ? 2 : 1, z = -(100 + i * 90), tries = 0;
      while (!laneFree(lane, z, 40, 40) && tries++ < 6) lane = (lane + 1) % 4;
      var b = { i: i, id: id, name: def.name, color: def.color, rec: rec, x: laneX(lane), tx: laneX(lane), vx: 0, z: z, spd: CH.info.bot, ph: def.ph, meter: 0, got: 0, imm: 0, boost: 0, lc: 0, len: rec.spec.L, w: rec.spec.W * 0.92, tag: null, yaw: 0, yawV: 0, pit: 0, pitV: 0, rol: 0, rolV: 0, pvx: 0, pspd: CH.info.bot, gear: 0, cr: 0, crT: 0, crTot: 1, bump: 0, burst: 0, sk: { prev: [null, null, null, null] } };
      rec.group.position.set(b.x, 0, b.z); scene.add(rec.group);
      var tg = document.createElement('div'); tg.className = 'btag'; tg.style.setProperty('--c', hex6(def.color)); $('popLayer').appendChild(tg); b.tag = tg;
      CH.bots.push(b);
    });
  }
  function catchBot(b) {
    b.got++; CH.catches++; b.meter = 0; b.imm = 5; b.boost = 7; b.burst = 1; botPop(b, 1, true); b.cr = 4; b.crTot = 4;
    var r = CH.info.reward; coins += r;
    popAt(b.x, 2.4, b.z, 'Поймал! +' + r); coinSound(true); shake = Math.max(shake, 0.2);
    if (!CH.done && CH.bots.every(function (q) { return q.got >= CH.info.need; })) {
      CH.done = true; CH.doneAt = CH.dist;
      popAt(player.x, 4.2, -8, 'Все пойманы!', 'sub');
      if (!CH.fin) finishChase();
    }
  }
  function botPop(b, s, all) {
    var att = Math.pow(clamp(1 - Math.abs(b.z) / 280, 0, 1), 1.4) * (b.z > 25 ? 0 : 1);
    recPop(b.rec, s, all); sndPop(s, att * 0.8);
  }
  function botCrackle(b, n) { if (n > b.cr) { b.cr = n; b.crTot = n; } }
  function botGear(spd) { var g = 1; while (g < 7 && spd >= GEARS[g]) g++; return g; }
  function updateBots(dt) {
    var t = CH.time;
    CH.bots.forEach(function (b) {
      var base = CH.info.bot * (1 + 0.045 * Math.sin(t * 0.37 + b.ph));
      if (b.boost > 0) { b.boost -= dt; base *= 1.12; }
      if (b.z < -330) base *= 0.9; else if (b.z > 30) base *= 1.12;
      var blk = null, bd = 1e9, i, c;
      for (i = 0; i < cars.length; i++) {
        c = cars[i];
        if (Math.abs(c.x - b.x) < 2.4 && c.z < b.z && b.z - c.z < 60 && c.spd < base && b.z - c.z < bd) { bd = b.z - c.z; blk = c; }
      }
      var threat = b.z > -30 && b.z < 6 && Math.abs(b.x - player.x) < 2.3;
      b.lc -= dt;
      if ((blk || threat) && b.lc <= 0) {
        var best = -1, bs = 1e9, l;
        for (l = 0; l < 4; l++) {
          var lx = laneX(l);
          if (Math.abs(lx - b.x) < 1 || !laneFree(l, b.z, 75, 24, b)) continue;
          var sc = Math.abs(lx - b.x) - (threat ? Math.abs(lx - player.x) * 0.5 : 0) + Math.random() * 0.6;
          if (sc < bs) { bs = sc; best = l; }
        }
        if (best >= 0) { b.tx = laneX(best); b.lc = 1.3; }
      }
      var spdT = base;
      if (blk && bd < 30 && Math.abs(b.tx - b.x) < 1.6) spdT = Math.min(base, blk.spd + 2);
      b.spd += (spdT - b.spd) * Math.min(1, dt * 1.2);
      var want = clamp((b.tx - b.x) * 2.4, -7, 7);
      b.vx += (want - b.vx) * Math.min(1, dt * 5); b.x += b.vx * dt;
      b.z += (speed - b.spd) / 3.6 * dt;
      var g = b.rec.group; g.position.set(b.x, 0, b.z);
      var dtc = Math.max(dt, 0.001), ay = (b.vx - b.pvx) / dtc, ax = (b.spd - b.pspd) / 3.6 / dtc; b.pvx = b.vx; b.pspd = b.spd;
      // suspension: pitch (squat/dive) and roll from real accelerations, as damped springs
      var pT = clamp(ax * 0.004, -0.05, 0.05), rT = clamp(ay * 0.0018, -0.07, 0.07);
      b.pitV += ((pT - b.pit) * 60 - b.pitV * 6.5) * dt; b.pit += b.pitV * dt;
      b.rolV += ((rT - b.rol) * 55 - b.rolV * 6) * dt; b.rol += b.rolV * dt;
      b.rec.body.rotation.x = b.pit; b.rec.body.rotation.z = b.rol;
      b.rec.body.position.y = Math.sin(CH.time * 9 + b.ph) * 0.003 * Math.min(1, b.spd / 100);
      // yaw follows the path with a little lag/overshoot (sliding a touch on hard lane changes)
      var yT = -Math.atan2(b.vx, Math.max(10, b.spd / 3.6)) * (1.5 + clamp((Math.abs(b.vx) - 5) / 6, 0, 1) * 0.9);
      b.yawV += ((yT - b.yaw) * 42 - b.yawV * 7) * dt; b.yaw += b.yawV * dt;
      g.rotation.y = b.yaw;
      var bs2 = b.spd / 3.6 * dt, k;
      for (k = 0; k < b.rec.spins.length; k++) { var spp = b.rec.spins[k].g.parent; b.rec.spins[k].g.rotation.x -= bs2 / b.rec.spins[k].r * (spp && spp.position.z > 0 && b.boost > 0 ? 1.5 : 1); }
      var bsteer = clamp((yT - b.yaw) * 1.2 - b.vx * 0.03, -0.5, 0.5);
      b.rec.front.forEach(function (f) { f.rotation.y += (bsteer - f.rotation.y) * Math.min(1, dt * 12); });
      // tyre marks on hard lane changes / braking
      var bkF = 0, bkR = 0;
      if (b.spd > 100 && Math.abs(b.vx) > 6) { bkF = clamp((Math.abs(b.vx) - 6) / 4, 0.1, 0.5); bkR = bkF * 0.8; }
      else if (ax < -6 && b.spd > 90) { bkF = 0.2; bkR = 0.35; }
      b.sk.z0 = b.z; skidEmit(b.sk, wheelPos(b.rec), b.x, b.yaw, bkF, bkR, speed / 3.6, dt);
      // exhaust: pops on lift-off / braking, bang on every upshift, flame while boosted
      var gg = botGear(b.spd);
      if (b.gear && gg !== b.gear && b.spd > 60) {
        if (gg > b.gear) { botPop(b, 0.85, true); botCrackle(b, 1 + ((Math.random() * 2) | 0)); } else { botPop(b, 0.4, false); botCrackle(b, 2); }
      }
      b.gear = gg;
      if (ax < -5 && b.spd > 110 && b.cr <= 0 && Math.random() < dt * 4) botCrackle(b, 3 + ((Math.random() * 3) | 0));
      if (b.cr > 0) { b.crT -= dt; if (b.crT <= 0) { botPop(b, 0.2 + 0.5 * Math.pow(b.cr / Math.max(1, b.crTot), 0.6) * (0.6 + 0.4 * Math.random()), false); b.cr--; b.crT = Math.random() < 0.3 ? 0.025 : 0.05 + 0.11 * Math.random(); } }
      b.burst = Math.max(0, b.burst - dt * 2.2);
      tipsAnim(b.rec, dt, b.boost > 0 ? 0.7 : 0, b.burst, b.z < 30 && b.z > -300, ax > 0.5 ? 0.6 : 0.2);
      // contact with traffic: bump, spin, sparks
      b.bump -= dt;
      if (b.bump <= 0) for (var ci = 0; ci < cars.length; ci++) {
        var tc = cars[ci], ox = (b.w + tc.w) / 2 - Math.abs(b.x - tc.x), oz = (b.len + tc.len) / 2 - Math.abs(b.z - tc.z);
        if (ox > 0 && oz > 0) {
          var dirB = b.x >= tc.x ? 1 : -1;
          b.bump = 1.2; b.vx += dirB * 5; b.tx = clamp(b.x + dirB * 1.8, laneX(0), laneX(3)); b.spd = Math.max(35, Math.min(b.spd, tc.spd) - 12); b.yawV += -dirB * 2.4; b.lc = 0.8;
          tc.hit = true; tc.vx = -dirB * 3; tc.yawv = -dirB * 0.9; tc.spd = Math.max(20, tc.spd - 8);
          var q, bz = b.z, bx = b.x - dirB * b.w / 2;
          for (q = 0; q < 22; q++) emitSpark(bx + rand(-0.3, 0.3), rand(0.2, 0.7), bz + rand(-1.2, 1.2), -dirB * rand(-1, 6), rand(0.5, 4), rand(-6, 4), rand(0.4, 1));
          emitDebris(MAT.plastic, bx, 0.5, bz, rand(0.06, 0.2), 0.05, rand(0.1, 0.3), -dirB * rand(0, 4), rand(1, 4), rand(-5, 0));
          emitSmoke(bx, 0.5, bz, rand(1, 1.6), rand(1, 1.6), false, true);
          sndHit(clamp(1 - Math.abs(b.z) / 220, 0, 1));
          break;
        }
      }
      if (b.imm > 0) b.imm -= dt;
      if (mode === 'play' && !CH.fin && b.imm <= 0) {
        var dxp = Math.abs(b.x - player.x), near = b.z > -13 && b.z < 3.5 && dxp < 2.6;
        var touch = Math.abs(b.z) < (b.len + PL.L) / 2 - 0.2 && dxp < (b.w + PL.W * 0.92) / 2;
        if (near) b.meter += dt / 1.3; else b.meter = Math.max(0, b.meter - dt / 2.2);
        if (touch) b.meter = 1;
        if (b.meter >= 1) catchBot(b);
      }
    });
  }
  function finishChase() {
    CH.fin = true; CH.finT = 0; nitroOn = false; nitroHold = false;
    CH.win = CH.bots.every(function (q) { return q.got >= CH.info.need; });
    var n = CH.info.need, st = 0;
    if (CH.win) { st = 1; if (CH.time <= 135) st = 2; if (CH.time <= 90) st = 3; }
    CH.stars = st;
    var bonus = CH.win ? CH.info.reward * 3 + st * 50 : 0; coins += bonus;
    if (CH.win) {
      if ((save.stars[CH.lvl] || 0) < st) save.stars[CH.lvl] = st;
      if (CH.lvl >= save.level && CH.lvl < CH_MAX) save.level = CH.lvl + 1;
    }
    var wasBest = coins > save.best; save.total += coins; if (wasBest) save.best = coins; persist();
    $('rNew').hidden = !(wasBest && coins > 0);
    popAt(player.x, 3.6, -8, CH.win ? 'Финиш!' : 'Финиш... не догнали');
  }
  function chaseHud() {
    var km = Math.min(CH_LEN, CH.dist) / 1000;
    setText($('chKm'), 'chkm', fnum(km.toFixed(1)) + ' / 3 км');
    $('chBar').style.width = (km * 100 / 3).toFixed(1) + '%';
    CH.bots.forEach(function (b, i) {
      var g = b.z < 0 ? Math.round(-b.z) + ' м' : (b.z < 4 ? 'рядом' : '−' + Math.round(b.z) + ' м');
      setText($('btG' + i), 'btg' + i, g);
      $('btM' + i).style.width = Math.round(clamp(b.meter, 0, 1) * 100) + '%';
      setText($('btN' + i), 'btn' + i, b.got + '/' + CH.info.need);
      $('bt' + i).classList.toggle('hot', b.meter > 0.05);
      if (b.tag) {
        vp.set(b.x, 2.1, b.z).project(camera);
        var vis = vp.z < 1 && b.z > -240 && b.z < 14;
        b.tag.style.display = vis ? '' : 'none';
        if (vis) {
          b.tag.style.left = clamp((vp.x * 0.5 + 0.5) * game.clientWidth, 30, game.clientWidth - 30) + 'px';
          b.tag.style.top = clamp((-vp.y * 0.5 + 0.5) * game.clientHeight, 70, game.clientHeight - 70) + 'px';
          setText(b.tag, 'tag' + i, b.name + ' · ' + g);
        }
      }
    });
  }
  function buildChaseHud() {
    var h = '<div class="km"><span>Ур. <b>' + CH.lvl + '</b></span><b id="chKm">0,0 / 3 км</b></div><div class="kbar"><i id="chBar"></i></div>';
    CH.bots.forEach(function (b, i) {
      h += '<div class="bt" id="bt' + i + '" style="--c:' + hex6(b.color) + '"><b>' + b.name + ' · ' + (SHORT[b.id] || '') + ' <span id="btN' + i + '"></span></b><span class="g" id="btG' + i + '">—</span><div class="cm"><i id="btM' + i + '"></i></div></div>';
    });
    $('chase').innerHTML = h; $('chase').hidden = false;
    for (var k in last) if (/^(chkm|btg|btn|tag)/.test(k)) delete last[k];
  }
  function renderLevels() {
    var g = $('lvGrid'); g.innerHTML = '';
    for (var n = 1; n <= CH_MAX; n++) {
      var b = document.createElement('button'), st = save.stars[n] || 0, locked = n > save.level;
      b.type = 'button'; b.disabled = locked || CH.busy; if (n === save.level) b.className = 'cur';
      b.innerHTML = n + '<small>' + (locked ? '—' : '★★★'.slice(0, st) + '···'.slice(0, 3 - st)) + '</small>';
      b.setAttribute('aria-label', 'Уровень ' + n + (locked ? ', закрыт' : ''));
      (function (nn) { b.addEventListener('click', function () { startChase(nn); }); })(n);
      g.appendChild(b);
    }
    $('lvInfo').textContent = 'Открыто уровней: ' + save.level + ' из ' + CH_MAX + '. Трасса меняется каждые 3 уровня. Соперники — ваши остальные машины.';
  }
  function openLevels() { renderLevels(); $('menu').hidden = true; $('over').hidden = true; $('levels').hidden = false; }
  function startChase(n) {
    if (CH.busy) return;
    CH.busy = true; renderLevels();
    $('lvInfo').textContent = 'Загружаю соперников…';
    var ids = botOthers().map(function (c) { return c.id; });
    whenModels(ids, function () {
      CH.busy = false;
      CH.lvl = n; CH.info = levelInfo(n);
      $('levels').hidden = true;
      startGame({ chase: true });
    }, 9000);
  }
  $('chaseBtn').addEventListener('click', openLevels);
  $('lvBack').addEventListener('click', function () { $('levels').hidden = true; $('menu').hidden = false; });
  $('overLevels').addEventListener('click', function () { $('over').hidden = true; clearBots(); CH.on = false; $('chase').hidden = true; $('ui').hidden = true; enterMode('menu'); openLevels(); });
  $('nextBtn').addEventListener('click', function () { startChase(Math.min(CH_MAX, CH.lvl + 1)); });

  /* ---------- game flow ---------- */
  function startGame(opts) {
    var chase = !!(opts && opts.chase === true);
    gameType = chase ? 'chase' : opts && opts.testId ? 'test' : opts && opts.drift ? 'drift' : opts && opts.extreme ? 'extreme' : 'classic';
    testId = gameType === 'test' ? opts.testId : null;
    paused = false; driftScore = 0; driftTime = 90;
    if (gameType === 'drift') setDrive('drift'); else setDrive('sport');
    initAudio();
    if (save.ctrl === 'tilt') enableTilt();
    clearCars(); clearBots();
    CH.on = chase; CH.dist = 0; CH.time = 0; CH.done = false; CH.doneAt = 0; CH.fin = false; CH.finT = 0; CH.win = false; CH.stars = 0; CH.catches = 0;
    setPlayerCar(testId || save.sel);
    if (chase) CH.info = levelInfo(CH.lvl);
    applyTrack(chase ? CH.info.track : save.track);
    enterMode('play');
    player.x = laneX(1); player.vx = 0; player.yaw = 0; player.roll = 0; player.pitch = 0; player.spin = 0;
    speed = 130; runT = 0; spawnT = gameType === 'extreme' ? 0.45 : 1.0; crashT = 0; shake = 0; overShown = false;
    coins = 0; overtakes = 0; nearMisses = 0; distanceMeters = 0; combo = 0; comboT = 0; nitro = 1; nitroOn = false; maxSpeed = 130;
    kb = 0; wAng = 0; tiltBase = null;
    var initialCars = gameType === 'extreme' ? (compactTraffic() ? 7 : 9) : 5;
    for (var i = 0; i < 30 && cars.length < initialCars; i++) spawnCar(-60 - Math.random() * 135);
    $('over').hidden = true; $('ui').hidden = false;
    pGroup.rotation.set(0, 0, 0);
    DRF.on = false; DRF.pts = 0; player.yawV = 0; onT = 0; oncT = gameType === 'extreme' ? 0.8 : 2;
    resetFx(); slowT = 0; smokeT = 0; player.rollT = 0; impact.on = false;
    if (chase) { spawnBots(); buildChaseHud(); } else $('chase').hidden = true;
  }
  $('startBtn').addEventListener('click', function () { startGame(); });
  $('againBtn').addEventListener('click', function () { if (CH.on) startChase(CH.lvl); else startGame(); });

  /* ---------- crash FX: damage, debris, sparks, smoke, skids ---------- */
  var softTex = (function () {
    var c = document.createElement('canvas'); c.width = c.height = 64;
    var x = c.getContext('2d'), gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.4, 'rgba(255,255,255,0.5)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = gr; x.fillRect(0, 0, 64, 64);
    return new T.CanvasTexture(c);
  })();
  var SP_N = 420, spPos = new Float32Array(SP_N * 3), spCol = new Float32Array(SP_N * 3), spVel = new Float32Array(SP_N * 3), spLife = new Float32Array(SP_N), spMax = new Float32Array(SP_N), spI = 0;
  for (var q = 0; q < SP_N; q++) spPos[q * 3 + 1] = -100;
  var spGeo = new T.BufferGeometry();
  spGeo.setAttribute('position', new T.BufferAttribute(spPos, 3));
  spGeo.setAttribute('color', new T.BufferAttribute(spCol, 3));
  var spPts = new T.Points(spGeo, new T.PointsMaterial({ size: 0.22, map: softTex, vertexColors: true, transparent: true, blending: T.AdditiveBlending, depthWrite: false, sizeAttenuation: true }));
  spPts.frustumCulled = false; scene.add(spPts);
  function emitSpark(x, y, z, vx, vy, vz, life) {
    if (Math.random() > graphics.particles) return;
    var i = spI = (spI + 1) % SP_N, k = i * 3;
    spPos[k] = x; spPos[k + 1] = y; spPos[k + 2] = z; spVel[k] = vx; spVel[k + 1] = vy; spVel[k + 2] = vz;
    spLife[i] = spMax[i] = life;
  }
  var SM_N = 72, smoke = [], smI = 0;
  for (var q2 = 0; q2 < SM_N; q2++) {
    var sm = new T.Sprite(new T.SpriteMaterial({ map: softTex, color: 0x6a6e76, transparent: true, opacity: 0, depthWrite: false }));
    sm.visible = false; scene.add(sm); smoke.push({ s: sm, life: 0, max: 1, vx: 0, vy: 0, vz: 0, size: 1 });
  }
  var darkSmoke = 0.3;
  function emitSmoke(x, y, z, size, life, fire, light) {
    if (Math.random() > graphics.particles) return;
    var o = smoke[smI = (smI + 1) % SM_N], m = o.s.material;
    o.s.position.set(x, y, z); o.life = o.max = life; o.size = size; o.fire = !!fire;
    o.vx = rand(-0.6, 0.6); o.vy = rand(0.8, 1.8); o.vz = rand(-1, 0.5);
    var bl = fire ? T.AdditiveBlending : T.NormalBlending;
    if (m.blending !== bl) { m.blending = bl; m.needsUpdate = true; }
    m.color.setHex(fire ? (Math.random() < 0.5 ? 0xff7a1a : 0xffb347) : (light ? 0xc4c8cf : Math.random() < darkSmoke ? 0x1c1d20 : 0x6a6e76)); o.s.visible = true;
  }
  var DB_N = 60, debris = [], dbGeo = whiteBox(1, 1, 1);
  for (var q3 = 0; q3 < DB_N; q3++) {
    var dm = new T.Mesh(dbGeo, MAT.plastic); dm.visible = false; scene.add(dm);
    debris.push({ m: dm, vx: 0, vy: 0, vz: 0, wx: 0, wy: 0, wz: 0, on: false, gr: false, t: 0 });
  }
  var dbI = 0;
  function emitDebris(mat, x, y, z, sx, sy, sz, vx, vy, vz) {
    if (Math.random() > graphics.particles) return;
    var o = debris[dbI = (dbI + 1) % DB_N];
    o.m.material = mat; o.m.scale.set(sx, sy, sz); o.m.position.set(x, y, z);
    o.m.rotation.set(rand(0, 6), rand(0, 6), rand(0, 6));
    o.vx = vx; o.vy = vy; o.vz = vz; o.wx = rand(-9, 9); o.wy = rand(-9, 9); o.wz = rand(-9, 9);
    o.on = true; o.gr = false; o.t = 0; o.m.visible = true;
  }
  // tyre marks: soft-edged rubber strips laid along the real path of each wheel
  var SK_N = 420, skTex = (function () {
    var c = document.createElement('canvas'); c.width = 32; c.height = 64; var x = c.getContext('2d'), i, j;
    for (j = 0; j < 64; j++) for (i = 0; i < 32; i++) {
      var u = (i + 0.5) / 32 * 2 - 1, edge = Math.max(0, 1 - Math.pow(Math.abs(u), 2.6)), tread = (i % 6 < 2 ? 0.78 : 1) * (0.7 + 0.3 * Math.random()), dust = Math.random() < 0.06 ? 0.35 : 1;
      x.fillStyle = 'rgba(255,255,255,' + (edge * tread * dust).toFixed(3) + ')'; x.fillRect(i, j, 1, 1);
    }
    var t = new T.CanvasTexture(c); t.minFilter = T.LinearFilter; return t;
  })();
  var skMesh = new T.InstancedMesh(new T.PlaneGeometry(1, 1), new T.MeshBasicMaterial({ map: skTex, color: 0xffffff, transparent: true, opacity: 0.85, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }), SK_N);
  skMesh.frustumCulled = false; skMesh.renderOrder = 1; skMesh.count = 0; scene.add(skMesh);
  skMesh.setColorAt(0, new T.Color(0)); skMesh.instanceColor.needsUpdate = true;
  var skSeg = [], skI = 0, skN = 0, skObj = new T.Object3D(), skCol = new T.Color(), skPrev = [null, null, null, null];
  for (var q4 = 0; q4 < SK_N; q4++) skSeg.push({ x: 0, z: 0, len: 0, ang: 0, k: 0, on: false });
  var skPlayer = { prev: [null, null, null, null] };
  function skidEmit(src, wp, px, yaw, kF, kR, v, dt) {
    var cy = Math.cos(yaw), sy = Math.sin(yaw), w, seg;
    for (w = 0; w < wp.length && w < 4; w++) {
      var pr = src.prev[w], kw = wp[w].z < 0 ? kF : kR;
      if (pr) pr.z += v * dt;
      if (kw > 0.05) {
        var wx = px + wp[w].x * cy + wp[w].z * sy, wz = (src.z0 || 0) - wp[w].x * sy + wp[w].z * cy;
        if (!pr) { src.prev[w] = { x: wx, z: wz }; continue; }
        var ddx = wx - pr.x, ddz = wz - pr.z, d = Math.sqrt(ddx * ddx + ddz * ddz);
        if (d >= 0.7 && d < 6) {
          seg = skSeg[skI]; skI = (skI + 1) % SK_N; skN = Math.min(SK_N, skN + 1);
          seg.x = (wx + pr.x) / 2; seg.z = (wz + pr.z) / 2; seg.len = d * 1.12 + 0.05; seg.ang = Math.atan2(-ddx, -ddz); seg.k = kw; seg.on = true;
          pr.x = wx; pr.z = wz;
        } else if (d >= 6) { src.prev[w] = { x: wx, z: wz }; }
      } else src.prev[w] = null;
    }
  }
  function wheelPos(rec) {
    if (rec.wpos) return rec.wpos;
    var wp = rec.wpos = [], hx = rec.spec.W * 0.4, hz = rec.spec.L * 0.3;
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (q) { wp.push({ x: q[0] * hx, z: q[1] * hz }); });
    var pv = rec.spins.map(function (sp) { return sp.g.parent; }).filter(function (q) { return q && q.position; });
    if (pv.length === 4) { wp.length = 0; pv.forEach(function (q) { wp.push({ x: q.position.x, z: q.position.z }); }); }
    return wp;
  }
  function skidRender(dt, v) {
    var i, seg, n = 0;
    for (i = 0; i < SK_N; i++) {
      seg = skSeg[i]; if (!seg.on) continue;
      seg.z += v * dt;
      if (seg.z > 45) { seg.on = false; continue; }
      skObj.position.set(seg.x, 0.012, seg.z); skObj.rotation.set(-Math.PI / 2, 0, seg.ang); skObj.scale.set(0.24, seg.len, 1); skObj.updateMatrix();
      skMesh.setMatrixAt(n, skObj.matrix);
      var tone = 0.02 + (1 - seg.k) * 0.1; skCol.setRGB(tone, tone, tone * 1.1); skMesh.setColorAt(n, skCol);
      n++;
    }
    skMesh.count = n; skMesh.instanceMatrix.needsUpdate = true; if (skMesh.instanceColor) skMesh.instanceColor.needsUpdate = true;
  }
  function skidStep(dt, v) {
    var inPlay = mode === 'play', cr = mode === 'crash', onGround = !(cr && player.flipOn && crashT < player.flipDur);
    var yawA = Math.abs(player.yaw), kF = 0, kR = 0;
    if (inPlay && speed > 55 && save.drive === 'drift' && yawA > 0.2) { var dk = clamp((yawA - 0.15) / 0.35, 0.3, 1); kF = dk * 0.16; kR = dk; }
    else if (inPlay && keys.b && speed > 110) { kF = 0.22; kR = 0.38; }
    else if (inPlay && speed > 110 && Math.abs(player.vx) > 9.5) { var lk = clamp((Math.abs(player.vx) - 9.5) / 4, 0.1, 0.5); kF = lk; kR = lk * 0.8; }
    else if (cr && onGround && speed > 6) { kF = kR = clamp(speed / 40, 0.3, 1); }
    skidEmit(skPlayer, wheelPos(pCar), player.x, player.yaw, kF, kR, v, dt);
    skidRender(dt, v);
  }
  function resetFx() {
    var i;
    for (i = 0; i < SP_N; i++) { spLife[i] = 0; spPos[i * 3 + 1] = -100; }
    spGeo.attributes.position.needsUpdate = true;
    for (i = 0; i < SM_N; i++) { smoke[i].life = 0; smoke[i].s.visible = false; }
    for (i = 0; i < DB_N; i++) { debris[i].on = false; debris[i].m.visible = false; }
    for (i = 0; i < SK_N; i++) skSeg[i].on = false; skMesh.count = 0; skPlayer.prev = [null, null, null, null]; CH.bots.forEach(function (b) { b.sk = { prev: [null, null, null, null] }; });
    player.hop = 0; player.hopV = 0; player.flipOn = false; if (pCar) pCar.body.position.set(0, 0, 0); crashLight.intensity = 0; darkSmoke = 0.3; ambMat.emissiveIntensity = 0.8;
    for (i = 0; i < BM_N; i++) { booms[i].life = 0; booms[i].s.visible = false; }
  }
  var BM_N = 8, booms = [], bmI = 0, crashLight = new T.PointLight(0xff8a3a, 0, 14, 2);
  scene.add(crashLight);
  for (var q5 = 0; q5 < BM_N; q5++) {
    var bs = new T.Sprite(new T.SpriteMaterial({ map: radialTex('rgba(255,210,120,1)', 'rgba(255,80,10,0)'), transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: 0 }));
    bs.visible = false; scene.add(bs); booms.push({ s: bs, life: 0, max: 0.5, size: 3 });
  }
  function emitBoom(x, y, z, size, life, noLight) {
    var o = booms[bmI = (bmI + 1) % BM_N]; o.s.position.set(x, y, z); o.life = o.max = life; o.size = size; o.s.visible = true;
    if (noLight) return;
    crashLight.position.set(x, y + 0.4, z - 0.5); crashLight.intensity = 14;
  }
  var flyW = [], tmpV = new T.Vector3();
  function detachWheel(rec, ix, iz, dir, sev) {
    var best = null, bd = 1e9, bs = null;
    rec.spins.forEach(function (sp) {
      var pv = sp.g.parent; if (!pv || pv.parent !== rec.body) return;
      var d = Math.hypot(pv.position.x - ix, pv.position.z - iz); if (d < bd) { bd = d; best = pv; bs = sp; }
    });
    if (!best || bd > 2.2) return;
    rec.lost = rec.lost || [];
    rec.lost.push({ pv: best, pos: best.position.clone(), rot: best.rotation.clone() });
    scene.attach(best);
    flyW.push({ pv: best, r: bs.r, vx: -dir * rand(2.5, 6.5), vy: rand(3.5, 6.5) * sev, vz: rand(-9, -2), w: rand(10, 20) * (Math.random() < 0.5 ? -1 : 1), gr: false, t: 0 });
  }
  function fxUpdate(dt, v) {
    var i, k, o;
    for (i = 0; i < BM_N; i++) {
      o = booms[i]; if (o.life <= 0) continue;
      o.life -= dt; if (o.life <= 0) { o.s.visible = false; continue; }
      var ba = 1 - o.life / o.max, bz = o.size * (0.35 + ba * 1.4);
      o.s.scale.set(bz, bz * 0.8, 1); o.s.material.opacity = (1 - ba) * (1 - ba); o.s.position.z += v * dt * 0.5;
    }
    crashLight.intensity = Math.max(0, crashLight.intensity - dt * 30);
    for (i = flyW.length - 1; i >= 0; i--) {
      o = flyW[i]; o.t += dt; var pv = o.pv;
      if (!o.gr) {
        o.vy -= 9.8 * dt; pv.position.x += o.vx * dt; pv.position.y += o.vy * dt;
        o.vz += (v - o.vz) * Math.min(1, dt * 0.25);
        if (pv.position.y < o.r) {
          pv.position.y = o.r;
          if (Math.abs(o.vy) < 1.5) { o.gr = true; o.vy = 0; } else { o.vy *= -0.38; o.vx *= 0.7; o.w *= 0.8; emitSpark(pv.position.x, 0.05, pv.position.z, rand(-2, 2), rand(0.5, 2), rand(-3, 3), 0.5); }
        }
      } else { o.vx *= Math.max(0, 1 - dt * 1.6); pv.position.x += o.vx * dt; o.vz += (v - o.vz) * Math.min(1, dt * 1.4); o.w *= Math.max(0, 1 - dt * 0.5); }
      pv.position.z += o.vz * dt; pv.rotation.x += o.w * dt;
      if (pv.position.z > 60 || o.t > 14) { pv.visible = false; flyW.splice(i, 1); }
    }
    for (i = 0; i < SP_N; i++) {
      k = i * 3;
      if (spLife[i] > 0) {
        spLife[i] -= dt;
        spVel[k + 1] -= 9.8 * dt;
        spPos[k] += spVel[k] * dt; spPos[k + 1] += spVel[k + 1] * dt; spPos[k + 2] += spVel[k + 2] * dt;
        spVel[k + 2] += (v - spVel[k + 2]) * Math.min(1, dt * 0.8);
        if (spPos[k + 1] < 0.02) { spPos[k + 1] = 0.02; spVel[k + 1] *= -0.35; }
        var f = Math.max(0, spLife[i] / spMax[i]);
        spCol[k] = 1.0 * f; spCol[k + 1] = 0.55 * f * f; spCol[k + 2] = 0.12 * f * f * f;
        if (spLife[i] <= 0) spPos[k + 1] = -100;
      }
    }
    spGeo.attributes.position.needsUpdate = true; spGeo.attributes.color.needsUpdate = true;
    for (i = 0; i < SM_N; i++) {
      o = smoke[i]; if (o.life <= 0) continue;
      o.life -= dt;
      if (o.life <= 0) { o.s.visible = false; continue; }
      var a = 1 - o.life / o.max;
      o.s.position.x += o.vx * dt; o.s.position.y += o.vy * dt * (1 - a * 0.6);
      o.s.position.z += (o.vz + (v - o.vz) * Math.min(1, a * 1.2)) * dt;
      var sz = o.fire ? o.size * (1 - a * 0.7) : o.size * (0.6 + a * 2.6);
      o.s.scale.set(sz, sz, 1);
      o.s.material.opacity = o.fire ? (1 - a) * 0.85 : Math.min(1, a * 8) * (1 - a) * 0.5;
    }
    for (i = 0; i < DB_N; i++) {
      o = debris[i]; if (!o.on) continue;
      o.t += dt;
      var m = o.m;
      if (!o.gr) {
        o.vy -= 9.8 * dt;
        m.position.x += o.vx * dt; m.position.y += o.vy * dt;
        m.rotation.x += o.wx * dt; m.rotation.y += o.wy * dt; m.rotation.z += o.wz * dt;
        o.vz += (v - o.vz) * Math.min(1, dt * 0.25);
        var hh = Math.min(m.scale.x, m.scale.y, m.scale.z) * 0.5;
        if (m.position.y < hh) {
          m.position.y = hh;
          if (Math.abs(o.vy) < 1.2) { o.gr = true; o.vy = 0; } else { o.vy *= -0.32; o.vx *= 0.6; o.wx *= 0.5; o.wy *= 0.5; o.wz *= 0.5; }
        }
      } else {
        o.vx *= Math.max(0, 1 - dt * 3);
        m.position.x += o.vx * dt;
        o.vz += (v - o.vz) * Math.min(1, dt * 2.5);
      }
      m.position.z += o.vz * dt;
      if (m.position.z > 60 || o.t > 12) { o.on = false; m.visible = false; }
    }
  }
  // damage state of the hero car body
  var impact = { x: 0, z: -2, on: false };
  function restoreCar(rec) {
    if (!rec) return;
    if (rec.model) {
      if (rec.ownGeo) rec.defMeshes.forEach(function (m, i) {
        var o = rec.origList[i], g = m.geometry; if (!o || !o.moved) return;
        g.attributes.position.array.set(o.pos); g.attributes.position.needsUpdate = true;
        g.attributes.normal.array.set(o.nor); g.attributes.normal.needsUpdate = true; g.computeBoundingSphere(); o.moved = false;
      });
      (rec.glassMeshes || []).forEach(function (m) { m.visible = true; });
      if (rec.lost) { rec.lost.forEach(function (l) { l.pv.visible = true; rec.body.add(l.pv); l.pv.position.copy(l.pos); l.pv.rotation.copy(l.rot); }); rec.lost = []; flyW.length = 0; }
      return;
    }
    if (rec.ownGeo) {
      var g = rec.bodyMesh.geometry;
      g.attributes.position.array.set(rec.origPos); g.attributes.position.needsUpdate = true;
      if (rec.origNor && g.attributes.normal) { g.attributes.normal.array.set(rec.origNor); g.attributes.normal.needsUpdate = true; }
      g.computeBoundingSphere();
    }
    if (rec.partOrig) rec.partOrig.forEach(function (p) { p.o.position.copy(p.p); p.o.rotation.copy(p.r); });
    if (rec.cabMesh) rec.cabMesh.visible = true;
  }
  var dsp = [0, 0, 0];
  function deformModel(rec, ix, iz, dx, sev) {
    var s = rec.spec, disp = dispFor(s, ix, iz, dx, sev), i;
    if (!rec.ownGeo) {
      rec.origList = rec.defMeshes.map(function (m) {
        m.geometry = m.geometry.clone();
        return { pos: m.geometry.attributes.position.array.slice(0), nor: m.geometry.attributes.normal.array.slice(0), moved: false };
      });
      rec.ownGeo = true;
    }
    rec.defMeshes.forEach(function (m, k) {
      var geo = m.geometry, arr = geo.attributes.position.array, hit = false;
      for (i = 0; i < arr.length; i += 3) {
        if (disp(arr[i], arr[i + 1], arr[i + 2]) > 0) { arr[i] += dsp[0]; arr[i + 1] += dsp[1]; arr[i + 2] += dsp[2]; hit = true; }
      }
      if (!hit) return;
      rec.origList[k].moved = true;
      geo.attributes.position.needsUpdate = true; geo.computeVertexNormals(); geo.attributes.normal.needsUpdate = true; geo.computeBoundingSphere();
    });
  }
  function dispFor(s, ix, iz, dx, sev) {
    var R = 1.7 + sev * 0.7, fz = clamp((Math.abs(iz) - s.L * 0.3) / (s.L * 0.2), 0, 1);
    var dirz = iz < 0 ? 1 : -1, dirx = dx > 0 ? -1 : 1;
    return function (px, py, pz) {
      var ex = px - ix, ey = (py - 0.55) * 0.9, ez = pz - iz, d = Math.sqrt(ex * ex + ey * ey + ez * ez);
      if (d >= R) { dsp[0] = dsp[1] = dsp[2] = 0; return 0; }
      var w = 1 - d / R; w *= w;
      var n1 = Math.sin(px * 37.1 + py * 91.7 + pz * 53.3), n2 = Math.sin(px * 71.3 - py * 43.9 + pz * 29.7);
      dsp[0] = dirx * 0.34 * sev * w * (0.35 + 0.65 * (1 - fz)) + n1 * 0.05 * w * sev;
      dsp[1] = -0.07 * sev * w * (0.5 + n2 * 0.5) + ((fz > 0.3 && py > 0.7) ? 0.2 * sev * w * fz : 0);
      dsp[2] = dirz * 0.85 * sev * w * fz * (1 + 0.3 * n1) + n2 * 0.06 * w * sev;
      return w;
    };
  }
  function deformBody(rec, ix, iz, dx, sev) {
    if (rec.model) return deformModel(rec, ix, iz, dx, sev);
    var s = rec.spec, geo, arr, i, bx, by, bz;
    if (!rec.ownGeo) {
      geo = rec.bodyMesh.geometry.clone(); rec.bodyMesh.geometry = geo; rec.ownGeo = true;
      rec.origPos = geo.attributes.position.array.slice(0);
      rec.origNor = geo.attributes.normal ? geo.attributes.normal.array.slice(0) : null;
      rec.partOrig = [];
      rec.body.children.forEach(function (o) {
        if ((o.isMesh || o.isSprite) && o !== rec.bodyMesh && o !== rec.cabMesh) rec.partOrig.push({ o: o, p: o.position.clone(), r: o.rotation.clone() });
      });
    }
    geo = rec.bodyMesh.geometry; arr = geo.attributes.position.array;
    var R = 1.7 + sev * 0.7, fz = clamp((Math.abs(iz) - s.L * 0.3) / (s.L * 0.2), 0, 1);
    var dirz = iz < 0 ? 1 : -1, dirx = dx > 0 ? -1 : 1;
    function disp(px, py, pz) {
      var ex = px - ix, ey = (py - 0.55) * 0.9, ez = pz - iz, d = Math.sqrt(ex * ex + ey * ey + ez * ez);
      if (d >= R) { dsp[0] = dsp[1] = dsp[2] = 0; return 0; }
      var w = 1 - d / R; w *= w;
      var n1 = Math.sin(px * 37.1 + py * 91.7 + pz * 53.3), n2 = Math.sin(px * 71.3 - py * 43.9 + pz * 29.7);
      dsp[0] = dirx * 0.34 * sev * w * (0.35 + 0.65 * (1 - fz)) + n1 * 0.05 * w * sev;
      dsp[1] = -0.07 * sev * w * (0.5 + n2 * 0.5) + ((fz > 0.3 && py > 0.7) ? 0.2 * sev * w * fz : 0);
      dsp[2] = dirz * 0.85 * sev * w * fz * (1 + 0.3 * n1) + n2 * 0.06 * w * sev;
      return w;
    }
    for (i = 0; i < arr.length; i += 3) {
      bx = arr[i + 2]; by = arr[i + 1]; bz = -arr[i];
      if (disp(bx, by, bz) > 0) { arr[i + 2] = bx + dsp[0]; arr[i + 1] = by + dsp[1]; arr[i] = -(bz + dsp[2]); }
    }
    rec.partOrig.forEach(function (p) {
      var o = p.o, w = disp(o.position.x, o.position.y, o.position.z);
      if (w > 0) { o.position.x += dsp[0]; o.position.y += dsp[1]; o.position.z += dsp[2]; o.rotation.x += n3(o) * w * sev; o.rotation.z += n3(o) * 0.7 * w * sev; }
    });
    function n3() { return rand(-1, 1) * 0.8; }
    geo.attributes.position.needsUpdate = true;
    geo.computeVertexNormals(); if (geo.attributes.normal) geo.attributes.normal.needsUpdate = true;
    geo.computeBoundingSphere();
  }

  function doCrash(hit) {
    endDrift(false);
    mode = 'crash'; crashT = 0; shake = 1.3; nitroOn = false; nitroHold = false;
    var dx = hit ? hit.x - player.x : 0; if (Math.abs(dx) < 0.05) dx = Math.random() < 0.5 ? -1 : 1;
    var rel = hit ? Math.max(0, speed - hit.spd) : 80;
    var sev = clamp(0.45 + rel / 110, 0.5, 1.25);
    var hz = hit ? clamp(hit.z, -PL.L / 2, PL.L / 2) : -PL.L / 2;
    var hx = clamp(dx, -PL.W / 2, PL.W / 2);
    if (Math.abs(hz) < PL.L * 0.32) hx = (dx > 0 ? 1 : -1) * PL.W / 2;
    var sideHit = Math.abs(hz) < PL.L * 0.32;
    impact.x = hx; impact.z = hz; impact.on = true;
    var dir = dx > 0 ? 1 : -1;
    player.spin = dir * (sideHit ? rand(0.8, 1.6) : rand(1.5, 3.4)) * sev * (hz < 0 ? 1 : -1);
    player.vx = -dir * (3 + 5 * sev);
    player.hopV = 1.8 + 2.2 * sev; player.hop = 0.01;
    player.flipA = 0; player.flipOn = false;
    if (sev >= 0.6 || sideHit) {
      var kk = Math.random(), tgt = kk < 0.35 ? 2 : (kk < 0.75 ? 1 : 0.5);
      if (sev > 1.05) tgt += 2;
      player.flipOn = true; player.flipT = tgt * Math.PI * (dx > 0 ? 1 : -1);
      player.flipDur = 1.15 + 0.28 * tgt; player.hopV = 4.5 + 3 * sev; player.flipSp = 0;
    }
    player.rollT = -dir * (0.12 + 0.3 * sev);
    deformBody(pCar, hx, hz, dx, sev);
    if (sev > 0.85 && pCar.cabMesh) pCar.cabMesh.visible = false;
    if (sev > 0.85 && pCar.glassMeshes) pCar.glassMeshes.forEach(function (m) { m.visible = false; });
    if (hit) {
      var mR = hit.rec.spec === TRUCK ? 3.5 : 1, vA = (speed + mR * hit.spd) / (1 + mR);
      speed = Math.max(vA, hit.spd * 0.9) + 4; hit.vA = speed - 4;
      try { if (hit.rec.bodyMesh) { var hix = clamp(player.x - hit.x, -hit.w / 2, hit.w / 2), hiz = clamp(-hit.z, -hit.len / 2, hit.len / 2); if (hit.onc) deformBody(hit.rec, -hix, -hiz, dx, sev * 0.9); else deformBody(hit.rec, hix, hiz, -dx, sev * 0.9); } } catch (e) {}
      hit.hit = true; hit.vx = dir * (2 + 5 * sev); hit.yawv = dir * rand(0.6, 1.8) * sev;
      hit.spd = Math.max(20, hit.vA);
    }
    // debris, glass, sparks, smoke
    var wx = player.x + hx, wy = 0.6, wz = hz, i;
    for (i = 0; i < 9; i++) emitDebris(pCar.paint, wx + rand(-0.3, 0.3), wy + rand(0, 0.3), wz + rand(-0.3, 0.3), rand(0.1, 0.4), rand(0.02, 0.05), rand(0.1, 0.4), -dir * rand(0, 5) + rand(-2, 2), rand(2, 6), rand(-9, -1) * (sideHit ? 0.3 : 1));
    for (i = 0; i < 5; i++) emitDebris(MAT.plastic, wx + rand(-0.3, 0.3), wy, wz + rand(-0.3, 0.3), rand(0.05, 0.2), rand(0.04, 0.1), rand(0.1, 0.5), -dir * rand(0, 6), rand(1, 5), rand(-8, 0));
    for (i = 0; i < 14; i++) emitDebris(MAT.shard, wx + rand(-0.4, 0.4), wy + rand(0.3, 0.8), wz + rand(-0.4, 0.4), rand(0.04, 0.16), 0.012, rand(0.04, 0.16), -dir * rand(-1, 5), rand(2, 7), rand(-7, 0));
    for (i = 0; i < 110; i++) emitSpark(wx + rand(-0.3, 0.3), rand(0.1, 0.6), wz + rand(-0.3, 0.3), -dir * rand(-2, 8), rand(0.5, 6), rand(-10, 4), rand(0.5, 1.4));
    for (i = 0; i < 6; i++) emitSmoke(wx + rand(-0.3, 0.3), 0.7, wz + rand(-0.3, 0.3), rand(1.2, 2.2), rand(2, 3.4));
    crashSound(sev);
    emitBoom(wx, 0.7, wz, 2.2 + 2.2 * sev, 0.55);
    if (pCar.model && sev > 0.75) detachWheel(pCar, hx, hz, dir, sev);
    if (sev > 0.8) darkSmoke = 0.7;
    for (i = 0; i < 26; i++) emitSpark(wx + rand(-0.4, 0.4), rand(0.1, 0.5), wz + rand(-0.4, 0.4), -dir * rand(-3, 10), rand(1, 7), rand(-12, 3), rand(0.6, 1.5));
    for (i = 0; i < 12; i++) emitSmoke(wx + rand(-0.5, 0.5), rand(0.1, 0.5), wz + rand(-0.5, 0.5), rand(1.6, 2.6), rand(1.2, 2), true);
    for (i = 0; i < 14; i++) emitDebris(MAT.shard, wx + rand(-0.5, 0.5), wy + rand(0.2, 0.9), wz + rand(-0.5, 0.5), rand(0.03, 0.12), 0.01, rand(0.03, 0.12), -dir * rand(-2, 6), rand(2, 8), rand(-8, 0));
    var f = $('flash'); f.classList.remove('go'); void f.offsetWidth; f.classList.add('go');
    var wasBest = coins > save.best;
    if (gameType !== 'test') { save.total += coins; if (wasBest) save.best = coins; persist(); }
    $('rNew').hidden = !(wasBest && coins > 0);
    pCar.flames.forEach(function (f2) { f2.visible = false; });
  }
  function showOver() {
    if (gameType === 'test') { $('over').hidden = true; openGarage(); return; }
    overShown = true;
    $('rCoins').textContent = coins; $('rOvt').textContent = overtakes; $('rSpd').textContent = Math.round(maxSpeed);
    $('rBest').textContent = save.best; $('rTotal').textContent = save.total;
    var ch = CH.on, t = $('overTitle');
    $('rChase').hidden = !ch; $('overLevels').hidden = !ch; $('nextBtn').hidden = !(ch && CH.fin && CH.win && CH.lvl < CH_MAX);
    if (ch) {
      $('rCatch').textContent = CH.catches; $('rTime').textContent = Math.floor(CH.time / 60) + ':' + ('0' + Math.floor(CH.time % 60)).slice(-2);
      $('rStars').textContent = CH.fin && CH.win ? '★★★'.slice(0, CH.stars) + '···'.slice(0, 3 - CH.stars) : '—';
    }
    t.textContent = ch ? (CH.fin ? (CH.win ? 'Уровень ' + CH.lvl + ' пройден' : 'Не догнали') : 'Авария · уровень ' + CH.lvl) : gameType === 'drift' ? 'Дрифт завершён' : 'Авария';
    t.style.color = ch && CH.fin && CH.win ? '#6ee79a' : '';
    $('ui').hidden = true; $('over').hidden = false;
    refreshMenu();
  }

  window.__spawn = function (z) { return spawnCar(z); }; window.__botPop = function (i, v) { botPop(CH.bots[i], v, true); }; window.__traf = function (i) { var b = CH.bots[i]; spawnCar(b.z - 5); var c = cars[cars.length - 1]; if (c) { c.lane = 1; c.x = b.x + 0.4; c.z = b.z; c.spd = Math.max(40, b.spd - 40); c.rec.group.position.x = c.x; } return !!c; }; window.__dbg2 = function () { var o = []; (function w(n, d) { if (d > 4) return; o.push('  '.repeat(d) + (n.name || '-') + ' [' + n.type + '] ' + n.children.length + ' ' + n.position.x.toFixed(2) + ',' + n.position.y.toFixed(2) + ',' + n.position.z.toFixed(2)); n.children.slice(0, 12).forEach(function (c) { w(c, d + 1); }); })(pCar.body.children[0], 0); return o.join('\n'); }; window.__dbg = function () { var o = []; pCar.body.children.forEach(function (c) { o.push(c.name + ':' + c.type + ':' + c.children.length + ':' + c.children.slice(0, 8).map(function (q) { return q.name; }).join('|')); }); return JSON.stringify({ model: !!pCar.model, sp: pCar.spins.length, kids: o, grp: pCar.group.children.length }); }; window.__wp = function () { return pCar.spins.map(function (q) { var p = q.g.parent; return [p.position.x, p.position.y, p.position.z, q.r].map(function (n) { return +n.toFixed(2); }); }); }; window.__front = function () { return pCar.front.map(function (f) { return +f.rotation.y.toFixed(2); }); };
  window.__onc = function (z, l) { spawnOncoming(); var c = cars[cars.length - 1]; if (c) { c.z = z; c.lane = 4 + l; c.x = laneXO(l); c.rec.group.position.x = c.x; } return cars.filter(function (q) { return q.onc; }).length; };
  window.__ex = { pop: exPop, crackle: exCrackle, EX: EX }; window.__nitro = function (v) { nitroHold = v; }; window.__ch = CH; window.__pl = player; window.__skip = function (m) { CH.dist += m; }; window.__sp = function (v) { speed = v; };
  window.__forceHit = function () { spawnCar(-14); var c = cars[cars.length - 1]; if (c) { c.x = player.x + 0.5; c.z = -9; c.spd = 90; c.rec.group.position.x = c.x; } };
  var vp = new T.Vector3();
  function popAt(wx, wy, wz, text, cls) {
    vp.set(wx, wy, wz).project(camera);
    var x = (vp.x * 0.5 + 0.5) * game.clientWidth, y = (-vp.y * 0.5 + 0.5) * game.clientHeight;
    if (vp.z > 1 || !isFinite(x) || !isFinite(y)) { x = game.clientWidth / 2; y = game.clientHeight * 0.55; }
    var d = document.createElement('div'); d.className = 'pop' + (cls ? ' ' + cls : ''); d.textContent = text;
    d.style.left = clamp(x, 40, game.clientWidth - 40) + 'px'; d.style.top = clamp(y, 60, game.clientHeight - 60) + 'px';
    $('popLayer').appendChild(d);
    setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 1100);
  }
  function award(c) {
    if (c.onc && !(player.x < -HALF + 0.5)) return;
    combo = comboT > 0 ? Math.min(5, combo + 1) : 1;
    comboT = COMBO_WINDOW;
    var close = c.overlap && c.minGap < 0.6;
    if (close) nearMisses++;
    var gain = (5 + (close ? 5 : 0)) * combo * (c.onc ? 3 : 1) * (gameType === 'extreme' ? 2 : 1);
    coins += gain; if (!c.onc) overtakes++;
    nitro = Math.min(1, nitro + (close ? 0.12 : 0.06));
    popAt(c.x, 1.8, c.z, (c.onc ? 'Встречка +' : '+') + gain);
    if (close) popAt(player.x, 3.2, -6, 'Впритык!', 'sub');
    if (combo > 1) popAt(player.x, 4.2, -6, '×' + combo, 'sub');
    coinSound(close);
  }

  /* ---------- exhaust: flames, pops, shift bangs ---------- */
  var EX = { cr: 0, crT: 0, crTot: 1, limT: 0, burst: 0, flash: 0, wasNitro: false, wasBrake: false, gear: 1, lastBang: 0 };
  function exPop(s, all) {
    if (pCar && pCar.exh && (mode === 'play' || mode === 'crash')) recPop(pCar, s, all);
    EX.flash = Math.max(EX.flash, s * 0.6); sndPop(s);
  }
  function recPop(rec, s, all) {
    if (rec && rec.exh) rec.exh.forEach(function (tip) {
      if (!(all || Math.random() < 0.65)) return;
      tip.p = Math.max(tip.p, s * (0.75 + 0.25 * Math.random()));
      tip.fg.getWorldPosition(exV);
      var ns = 3 + Math.round(11 * s), q;
      for (q = 0; q < ns; q++) emitSpark(exV.x + rand(-0.05, 0.05), exV.y + rand(-0.05, 0.05), exV.z, rand(-1.8, 1.8), rand(0.2, 2.6), rand(0.5, 7), rand(0.25, 0.7));
      if (s > 0.5) emitSmoke(exV.x, exV.y, exV.z + 0.2, rand(0.35, 0.6), rand(0.5, 0.9), false, true);
      if (s > 0.7) emitBoom(exV.x, exV.y, exV.z + 0.4, 0.7 + 0.9 * s, 0.16, true);
    });
  }
  function exCrackle(n) { if (n > EX.cr) { EX.cr = n; EX.crTot = n; } if (EX.crT > 0.05) EX.crT = 0.02; }
  function exhaustEvents(dt) {
    var play = mode === 'play' && !CH.fin;
    if (play) {
      if (nitroOn && !EX.wasNitro) { EX.burst = 1; exPop(1, true); sndWhoosh(); }
      if (!nitroOn && EX.wasNitro) { sndBov(); exCrackle(4 + ((Math.random() * 4) | 0)); }
      if (keys.b && !EX.wasBrake && speed > 110) { sndBov(); exCrackle(3 + ((Math.random() * 4) | 0)); }
      if (keys.b && speed > 150 && rpm > 4200 && Math.random() < dt * 2.5) exCrackle(2);
      if (nitroOn && Math.random() < dt * 1.6) exPop(0.3, false);
    }
    EX.wasNitro = nitroOn; EX.wasBrake = !!keys.b;
    if (EX.cr > 0) {
      EX.crT -= dt;
      if (EX.crT <= 0) { var fall = EX.cr / Math.max(1, EX.crTot); exPop(0.22 + 0.55 * Math.pow(fall, 0.6) * (0.6 + 0.4 * Math.random()), false); EX.cr--; EX.crT = Math.random() < 0.3 ? 0.022 + 0.02 * Math.random() : 0.05 + 0.12 * Math.random(); }
    }
  }
  var exV = new T.Vector3();
  function tipsAnim(rec, dt, contBase, burst, vis, thr) {
    if (!rec || !rec.exh) return;
    rec.exh.forEach(function (tip) {
      var cont = contBase > 0 ? contBase + Math.random() * 0.45 + burst * 1.1 : 0;
      var pop = tip.p; tip.p = Math.max(0, tip.p - dt * 8);
      var len = Math.max(cont, pop * (0.55 + 0.9 * Math.random()));
      // faint exhaust gas in the headlights / soot burst when the flame lights
      if (vis && (thr > 0.2 || cont > 0) && Math.random() < dt * (cont > 0 ? 18 : 7 * thr)) {
        tip.fg.getWorldPosition(exV);
        emitSmoke(exV.x, exV.y, exV.z + 0.15, rand(0.22, 0.4), rand(0.5, 0.9), false, true);
      }
      var show = len > 0.05 && vis;
      tip.fg.visible = show;
      if (!show) return;
      var w = tip.r * (1.9 + 0.9 * Math.random()) * (0.7 + 0.5 * Math.min(1, len));
      tip.o.scale.set(w, w, len); tip.i.scale.set(w * 0.5, w * 0.5, len * 0.58);
      tip.fg.rotation.set((Math.random() - 0.5) * 0.06, (Math.random() - 0.5) * 0.06, 0);
      var gs = 0.4 + len * 0.6 + (pop > 0.6 ? 0.5 : 0); tip.gl.scale.set(gs, gs, 1); tip.gl.position.z = len * 0.12;
      var showD = cont > 0.6;
      tip.dm.forEach(function (d, k) {
        d.visible = showD;
        if (showD) { var ds = tip.r * (2.3 - k * 0.5) * (0.8 + 0.4 * Math.random()); d.scale.set(ds, ds, 1); d.position.z = len * (0.22 + k * 0.24); }
      });
    });
  }
  function exhaustUpdate(dt) {
    EX.burst = Math.max(0, EX.burst - dt * 2.2); EX.flash = Math.max(0, EX.flash - dt * 9);
    flameTex.offset.x = (flameTex.offset.x + dt * 3.1) % 1;
    if (pCar && pCar.exh) tipsAnim(pCar, dt, nitroOn ? 0.8 : 0, EX.burst, mode === 'play' || mode === 'crash', mode === 'play' ? throttle : 0);
    tailLight.color.setHex(EX.flash > 0.05 ? 0xff8a2a : 0xff2020);
  }

  /* ---------- drift mode ---------- */
  var DRF = { on: false, pts: 0, t: 0, pt: 0 };
  function endDrift(pay) {
    if (!DRF.on) return;
    DRF.on = false; var g = Math.round(DRF.pts); DRF.pts = 0;
    if (pay) driftScore += g;
    if (pay && g >= 3) { coins += g; popAt(player.x, 3.4, -6, 'Дрифт +' + g); coinSound(g > 40); nitro = Math.min(1, nitro + 0.04 + g * 0.0006); }
  }
  function driftUpdate(dt) {
    var ang = Math.abs(player.yaw + Math.atan2(player.vx, Math.max(10, speed / 3.6)));
    if (speed > 55 && ang > 0.22) {
      if (!DRF.on) { DRF.on = true; DRF.t = 0; DRF.pts = 0; DRF.pt = 0.4; exCrackle(2); }
      DRF.t += dt; DRF.pts += (ang - 0.1) * speed * dt * 0.08 * (1 + Math.min(3, DRF.t * 0.45));
      speed = Math.max(40, speed - ang * 16 * dt);
      if (Math.random() < dt * (32 + (nitroOn ? 40 : 0))) [-1, 1].forEach(function (sd) { emitSmoke(player.x + sd * PL.W * 0.38 + rand(-0.2, 0.2), 0.12, PL.L * 0.32 + rand(-0.3, 0.3), rand(1.0, 1.7), rand(0.9, 1.6), false, true); });
      if (Math.random() < dt * 3) exCrackle(2);
      shake = Math.max(shake, 0.08);
      DRF.pt -= dt; if (DRF.pt <= 0) { DRF.pt = 0.9; popAt(player.x, 3.4, -6, 'ДРИФТ ' + Math.round(DRF.pts), 'sub'); }
    } else if (DRF.on) endDrift(true);
  }
  function completeDrift() {
    endDrift(true);
    var wasBest = coins > save.best;
    save.total += coins;
    if (wasBest) save.best = coins;
    persist();
    mode = 'results';
    nitroOn = false;
    showOver();
  }

  /* ---------- simulation ---------- */
  var GEARS = [0, 50, 85, 120, 160, 200, 245, 420];
  function updateGear() {
    var g = 1, sp0 = save.drive === 'drift' && mode === 'play' ? speed * 1.5 : speed;
    while (g < 7 && sp0 >= GEARS[g]) g++;
    var lo = GEARS[g - 1], hi = GEARS[g], frac = clamp((sp0 - lo) / (hi - lo), 0, 1);
    if (g !== gearN && mode === 'play' && !CH.fin && speed > 40 && runT > 0.6) {
      sndShift();
      if (g > gearN) { exPop(0.85 + 0.15 * Math.random(), true); exCrackle(1 + ((Math.random() * 2) | 0)); EX.crT = 0.07; }
      else { rpm = Math.min(7500, rpm + 1100); exPop(0.45, false); exCrackle(2 + ((Math.random() * 3) | 0)); }
    }
    gearN = g;
    rpm += (2800 + frac * 4700 - rpm) * 0.25;
  }

  function step(dt) {
    if (mode === 'lan') { lanStep(dt); return; }
    time += dt;
    var st = steerValue(dt), isDr = save.drive === 'drift' && mode === 'play';
    steerVis += (st - steerVis) * Math.min(1, dt * 10);

    if (mode === 'play') {
      runT += dt;
      nitroOn = (nitroHold || keys.t) && nitro > 0.01 && !CH.fin;
      if (nitroOn) nitro = Math.max(0, nitro - dt * 0.28); else nitro = Math.min(1, nitro + dt * 0.04);
      var base = isDr ? Math.min(P.top * 0.62, 105 + Math.min(80, runT * 1.7 * P.accel)) : Math.min(P.top, 150 + Math.min(110, runT * 1.8 * P.accel));
      var target = base - (keys.a ? 0 : 38) + (nitroOn ? 35 : 0) - (keys.b ? (isDr ? 30 : 115) : 0);
      var k = (nitroOn ? 1.8 : keys.b ? 1.8 : 0.55) * Math.pow(P.accel, 0.8);
      speed += (target - speed) * Math.min(1, dt * k);
      distanceMeters += speed / 3.6 * dt;
      if (speed > maxSpeed) maxSpeed = speed;
      throttle = nitroOn ? 1 : keys.b ? 0.1 : 0.6;

      var latMax = (13 - 3.5 * clamp((speed - 100) / 180, 0, 1)) * P.agile * (isDr ? 1.3 : 1);
      player.vx += (steerVis * latMax - player.vx) * Math.min(1, dt * (isDr ? (keys.b ? 2.2 : 3.4) : 7));
      player.x += player.vx * dt;
      var limR = HALF - PL.W / 2 + 0.1, limL = ONC_EDGE + PL.W / 2 - 0.1;
      if (player.x > limR || player.x < limL) {
        player.x = clamp(player.x, limL, limR);
        if (Math.abs(player.vx) > 2) { shake = Math.max(shake, 0.25); speed -= 25 * dt; for (var wsI = 0; wsI < 3; wsI++) emitSpark(player.x + Math.sign(player.x) * PL.W / 2, rand(0.2, 0.6), rand(-1.5, 1.5), 0, rand(0.5, 2.5), rand(-5, 2), rand(0.3, 0.7)); }
        player.vx = 0;
      }
      comboT -= dt; if (comboT <= 0) combo = 0;
      if (isDr) driftUpdate(dt); else if (DRF.on) endDrift(true);
      if (gameType === 'drift') {
        driftTime = Math.max(0, 90 - runT);
        if (driftTime <= 0) { completeDrift(); return; }
      }
      if (gameType === 'test' && runT >= 60) { openGarage(); return; }
      if (player.x < -HALF + 0.6 && speed > 60) { onT += dt; if (onT > 1) { onT = 0; coins += 4; popAt(player.x, 3.6, -6, 'Встречка +4', 'sub'); } } else onT = 0;
    } else if (mode === 'crash') {
      crashT += dt;
      speed = Math.max(0, speed - (26 + 9 * crashT) * dt);
      shake = Math.max(0, shake - dt * 0.9);
      player.x += player.vx * dt * Math.max(0, 1 - crashT);
      player.x = clamp(player.x, ONC_EDGE + 1, HALF - 1);
      throttle = 0;
      player.hopV -= 16 * dt; player.hop += player.hopV * dt;
      if (player.hop < 0) { player.hop = 0; player.hopV = player.hopV < -2 ? -player.hopV * 0.28 : 0; }
      if (crashT < 1.1 && speed > 5) {
        for (var si = 0; si < 3; si++) emitSpark(player.x + impact.x + rand(-0.4, 0.4), rand(0.05, 0.3), impact.z * 0.6 + rand(-0.5, 0.5), rand(-3, 3), rand(0.5, 3), rand(-4, 6), rand(0.3, 0.8));
      }
      if (crashT < 5 && darkSmoke > 0.5 && Math.random() < dt * 22) emitSmoke(player.x + impact.x * 0.6 + rand(-0.25, 0.25), rand(0.45, 0.8), impact.z * 0.7 + rand(-0.3, 0.3), rand(0.6, 1.1), rand(0.35, 0.6), true);
      if (crashT < 5) {
        smokeT -= dt;
        if (smokeT <= 0) { smokeT = 0.09; emitSmoke(player.x + impact.x * 0.6 + rand(-0.3, 0.3), 0.8, impact.z * 0.7, rand(1.2, 2), rand(2, 3.2)); }
      }
      ambMat.emissiveIntensity = crashT > 0.5 && Math.floor(time * 3) % 2 === 0 ? 2.4 : 0.05;
      if (speed > 12) for (var ti = 0; ti < 2; ti++) if (Math.random() < dt * 14) emitSmoke(player.x + rand(-0.9, 0.9), 0.12, rand(-1.7, 1.7), rand(0.8, 1.4), rand(0.9, 1.5), false, true);
      if (crashT > (player.flipOn ? 2.9 : 2.3) && !overShown) showOver();
    } else {
      speed = 0; throttle = 0.1;
    }
    updateGear();
    if (isDr && DRF.on) {
      rpm = 7000 + 480 * Math.sin(time * 27);
      EX.limT -= dt;
      if (EX.limT <= 0) { EX.limT = (nitroOn ? 0.08 : 0.12) + 0.09 * Math.random(); if (nitroOn || keys.b) exPop(nitroOn ? 0.5 : 0.3, false); sndCut(); }
    }
    exhaustEvents(dt);
    var v = speed / 3.6;

    roadOff += v * dt / 12; roadTex.offset.y = roadOff; roadTex2.offset.y = roadOff;
    railTex.offset.x = roadOff * 3; railTexR.offset.x = -roadOff * 3;
    var i, c;
    for (i = 0; i < lamps.length; i++) { lamps[i].position.z += v * dt; if (lamps[i].position.z > 40) lamps[i].position.z -= LAMP_SPAN; }
    if (trk.scenery === 'city') updateBuildings(v, dt); else updateTrees(v, dt);
    updateSnow(v, dt);

    if (mode === 'play') {
      spawnT -= dt;
      if (spawnT <= 0) {
        var okS = spawnCar(-185);
        spawnT = okS ? (gameType === 'extreme' ? 0.55 : 1.1 - Math.min(0.35, runT / 150)) * rand(0.8, 1.3) * (CH.on ? CH.info.dens : 1) / graphics.traffic : 0.2;
      }
      oncT -= dt;
      if (oncT <= 0) { spawnOncoming(); oncT = rand(gameType === 'extreme' ? 0.7 : 1.3, gameType === 'extreme' ? 1.3 : 2.8) * (CH.on ? 1 / Math.max(0.5, CH.info.dens) : 1) / graphics.traffic; }
    }
    for (i = cars.length - 1; i >= 0; i--) {
      c = cars[i];
      c.z += (speed - c.spd) / 3.6 * dt;
      c.rec.group.position.z = c.z;
      if (mode === 'play' && gameType === 'extreme' && !c.onc && !c.hit) {
        c.shiftT -= dt;
        if (c.shiftT <= 0) { tryTrafficShift(c); c.shiftT = rand(3.5, 6); }
        if (c.shiftTo !== undefined) {
          var shift = c.shiftTo - c.x, step = Math.sign(shift) * Math.min(Math.abs(shift), 4.5 * dt);
          c.x += step; c.rec.group.position.x = c.x;
          c.rec.group.rotation.y = -Math.sign(shift) * Math.min(0.1, Math.abs(shift) * 0.05);
          if (Math.abs(c.shiftTo - c.x) < 0.01) { c.x = c.shiftTo; c.shiftTo = undefined; c.rec.group.rotation.y = 0; }
        }
      }
      if (c.hit) {
        c.x += c.vx * dt; c.vx *= Math.max(0, 1 - dt * 0.6);
        c.rec.group.position.x = c.x;
        c.rec.group.rotation.y += c.yawv * dt; c.yawv *= Math.max(0, 1 - dt * 0.5);
        if (mode === 'crash') c.spd = Math.max(0, c.spd - (26 + 9 * crashT) * dt);
        c.rec.body.rotation.z += (Math.sign(c.vx) * 0.12 - c.rec.body.rotation.z) * Math.min(1, dt * 3);
      }
      var cs = c.spd / 3.6 * dt;
      for (var s = 0; s < c.rec.spins.length; s++) c.rec.spins[s].g.rotation.x -= Math.abs(cs) / c.rec.spins[s].r;
      if (mode === 'play') {
        if (Math.abs(c.z) < (c.len + PL.L) / 2 - 0.2) {
          var gap = Math.abs(c.x - player.x) - (c.w + PL.W * 0.92) / 2;
          c.overlap = true; if (gap < c.minGap) c.minGap = gap;
          if (gap < -0.05 && !CH.fin) doCrash(c);
        }
        if (!c.passed && c.z > (c.len + PL.L) / 2 + 0.3) { c.passed = true; award(c); }
      }
      if (c.z > 45) { releaseTraffic(c); cars.splice(i, 1); }
    }

    if (CH.on && (mode === 'play' || mode === 'crash')) {
      if (mode === 'play') { CH.dist += v * dt; CH.time += dt; }
      updateBots(dt);
      if (mode === 'play') {
        if (!CH.fin && CH.time >= 180) finishChase();
        if (CH.fin) { CH.finT += dt; if (CH.finT > 1.7 && !overShown) showOver(); }
      }
    }

    // player car
    var inGarage = mode === 'garage';
    var wsT = 0;
    if (inGarage) wsT = window.__gs || 0;
    else if (mode === 'play') {
      if (isDr) wsT = clamp(-Math.atan2(player.vx, Math.max(10, v)) - player.yaw, -0.62, 0.62);
      else wsT = -steerVis * 0.6;
    } else if (mode === 'crash') wsT = clamp(player.spin * 0.12, -0.5, 0.5);
    pCar.steerA = (pCar.steerA || 0) + (wsT - (pCar.steerA || 0)) * Math.min(1, dt * 14);
    pCar.front.forEach(function (f) { f.rotation.y = pCar.steerA; });
    var rsp = isDr && DRF.on ? 1.3 + (nitroOn ? 1.6 : 0) : (nitroOn && speed < 170 ? 0.9 : 0);
    if (!inGarage) for (i = 0; i < pCar.spins.length; i++) { var spp = pCar.spins[i].g.parent; pCar.spins[i].g.rotation.x -= v * dt / pCar.spins[i].r * (spp && spp.position.z > 0 ? 1 + rsp : 1); }
    bobT += dt * (3 + v * 0.35);
    var bob = mode === 'menu' || inGarage ? 0 : Math.sin(bobT) * 0.004 * Math.min(1, v / 40);
    var yawT = -Math.atan2(player.vx, Math.max(10, v)) * 1.4;
    var rollT = player.vx * (isDr ? 0.011 : 0.006);
    var pitchT = nitroOn ? 0.025 : keys.b ? -0.03 : 0.005;
    if (mode === 'crash') {
      player.yaw += player.spin * dt * Math.max(0, 1 - crashT * 0.8);
      pGroup.rotation.y = player.yaw;
      if (player.flipOn) {
        var fu = clamp(crashT / player.flipDur, 0, 1), fe = 1 - Math.pow(1 - fu, 2.2), fa = player.flipT * fe, hc = (pCar.spec.H || 1.4) * 0.5;
        pCar.body.rotation.z = fa; pCar.body.position.set(hc * Math.sin(fa), hc * (1 - Math.cos(fa)), 0);
        pCar.body.rotation.x += (0.05 - pCar.body.rotation.x) * Math.min(1, dt * 4);
        if (fu >= 1 && speed > 8 && Math.abs(Math.sin(fa / 2)) > 0.3) {
          for (var fsI = 0; fsI < 2; fsI++) emitSpark(player.x + rand(-0.6, 0.6), rand(0.05, 0.3), rand(-1.8, 1.8), rand(-2, 2), rand(0.5, 2.5), rand(-5, 3), rand(0.3, 0.7));
        }
      } else {
        pCar.body.rotation.z += ((player.rollT || 0) - pCar.body.rotation.z) * Math.min(1, dt * 3);
        pCar.body.rotation.x += (0.05 - pCar.body.rotation.x) * Math.min(1, dt * 4);
      }
    } else if (inGarage) {
      pGroup.rotation.y = 0; pCar.body.rotation.set(0, 0, 0);
    } else {
      if (isDr) {
        // rear-wheel-drive slide: the nose sits beyond the velocity vector by a slip angle that power, handbrake and steering open up
        var hv = -Math.atan2(player.vx, Math.max(10, v)), sM = Math.abs(steerVis), kick = nitroOn ? 1 : 0, hb = keys.b ? 1 : 0;
        var gate = clamp((speed - 45) / 45, 0, 1) * sstep(0.12, 0.5, sM);
        var angT = (0.3 + 0.3 * kick + 0.14 * hb) * gate;
        if (sM > 0.12) player.yawSgn = Math.sign(steerVis);
        var yawD = hv - (player.yawSgn || 1) * angT;
        var dS = (steerVis - (player.ps || 0)) / Math.max(dt, 0.001); player.ps = steerVis;
        if (speed > 70 && Math.abs(dS) > 3.2 && sM > 0.2) player.yawV += clamp(dS, -9, 9) * 0.07;
        player.yawV += ((yawD - player.yaw) * (30 + 10 * gate) - player.yawV * 6.5) * dt; player.yaw += player.yawV * dt;
      } else { player.yawV = 0; player.ps = 0; player.yaw += (yawT - player.yaw) * Math.min(1, dt * 8); }
      // suspension as damped springs: squat / dive from real longitudinal accel, roll from lateral accel, road shimmer
      var axp = player.sp0 === undefined ? 0 : (speed - player.sp0) / 3.6 / Math.max(dt, 0.001); player.sp0 = speed;
      var ayp = player.vx0 === undefined ? 0 : (player.vx - player.vx0) / Math.max(dt, 0.001); player.vx0 = player.vx;
      var pT2 = pitchT + clamp(axp * 0.0035, -0.04, 0.04), rT2 = rollT + clamp(ayp * 0.0016, -0.05, 0.05);
      player.pitV = (player.pitV || 0) + ((pT2 - player.pitch) * 55 - (player.pitV || 0) * 6.5) * dt; player.pitch += player.pitV * dt;
      player.rolV = (player.rolV || 0) + ((rT2 - player.roll) * 50 - (player.rolV || 0) * 6) * dt; player.roll += player.rolV * dt;
      pGroup.rotation.y = player.yaw;
      pCar.body.rotation.z = player.roll; pCar.body.rotation.x = player.pitch;
    }
    pGroup.position.set(inGarage ? 0 : player.x, bob + (mode === 'crash' ? player.hop : 0), 0);
    fxUpdate(dt, v); skidStep(dt, v);
    pCar.flames.forEach(function (f) {
      f.visible = nitroOn;
      if (nitroOn) { var l = 0.8 + Math.random() * 0.9; f.scale.set(1, l, 1); f.position.z = PL.L / 2 + l / 2 + 0.05; }
    });
    exhaustUpdate(dt);
    tailLight.intensity = (nitroOn ? 1.6 : (keys.b ? 1.4 : 0.8)) + EX.flash * 5;
    if (pCar.tailMat) pCar.tailMat.emissiveIntensity = keys.b ? 3.4 : 1.3;
  }

  /* ---------- camera ---------- */
  var cPos = new T.Vector3(), cLook = new T.Vector3(), oPos = new T.Vector3(), oLook = new T.Vector3();
  function updateCamera(dt) {
    var portrait = camera.aspect < 1;
    if (mode === 'garage') {
      if (!gDrag) {
        gAng += gVel * dt; gVel *= Math.pow(0.04, dt);
        if (time - gLast > 2.5) gAng += dt * 0.22;
      }
      var R = (portrait ? 11.8 : 7.4) * (PL.L > 4.9 ? 1.04 : 1) * gZoom;
      camera.position.set(Math.sin(gAng) * R, gH, Math.cos(gAng) * R);
      camera.lookAt(0, 0.7, 0);
      camera.fov = baseFov * 0.66;
      var wpx = game.clientWidth, hpx = game.clientHeight, key = 'g' + wpx + 'x' + hpx;
      if (voKey !== key) {
        voKey = key; voOn = true;
        if (camera.aspect > 1.15) camera.setViewOffset(wpx, hpx, Math.round(wpx * 0.2), 0, wpx, hpx);
        else camera.setViewOffset(wpx, hpx, 0, Math.round(hpx * 0.2), wpx, hpx);
      }
      camera.updateProjectionMatrix();
      return;
    }
    if (voOn) { voOn = false; voKey = ''; camera.clearViewOffset(); }
    menuBlend += ((mode === 'menu' ? 1 : 0) - menuBlend) * Math.min(1, dt * 2.2);
    camX += (player.x * 0.92 - camX) * Math.min(1, dt * 5);
    var back = 8.6 + Math.min(1.3, speed / 220) + (nitroOn ? 0.7 : 0);
    var h = 3.4 + (portrait ? 0.7 : 0);
    cPos.set(camX, h, back);
    cLook.set(camX * 0.85 + player.x * 0.1, 1.2, -24);
    if (mode === 'play' && cameraMode === 'cockpit') {
      cPos.set(player.x, 1.22, -0.55);
      cLook.set(player.x + steerVis * 1.5, 1.3, -32);
    }
    if (mode === 'crash') {
      var ck = clamp(crashT / 1.4, 0, 1), ce = ck * ck * (3 - 2 * ck);
      cPos.x += (player.x + 2.2 * Math.sign(impact.x || 1) - cPos.x) * ce * 0.6;
      cPos.y -= ce * 1.1; cPos.z -= ce * 2.6;
      cLook.x += (player.x - cLook.x) * ce; cLook.y += (0.9 - cLook.y) * ce; cLook.z += (-3 - cLook.z) * ce;
    }
    var a = time * 0.28 + 0.6;
    oPos.set(player.x + Math.sin(a) * 7.4, 2.0 + Math.sin(time * 0.5) * 0.4, Math.cos(a) * 7.4);
    oLook.set(player.x, 0.75, 0);
    cPos.lerp(oPos, menuBlend); cLook.lerp(oLook, menuBlend);
    var sh = shake * 0.45 + (mode === 'play' ? Math.min(1, speed / 300) * 0.012 + (nitroOn ? 0.02 : 0) : 0);
    camera.position.set(cPos.x + rand(-sh, sh), cPos.y + rand(-sh, sh), cPos.z);
    camera.lookAt(cLook);
    camera.fov = baseFov + clamp(speed / 280, 0, 1) * 8 + (nitroOn ? 4 : 0);
    camera.updateProjectionMatrix();
  }

  /* ---------- HUD ---------- */
  var last = {};
  function setText(node, key, val) { if (last[key] !== val) { last[key] = val; node.textContent = val; } }
  function hud() {
    if ($('ui').hidden) return;
    setText($('spd'), 'spd', Math.round(speed));
    setText($('gear'), 'gear', gearN);
    setText($('ovt'), 'ovt', overtakes);
    setText($('coinsEl'), 'coins', coins);
    var pr = Math.round(clamp(speed / Math.max(260, P.top + 30), 0, 1) * 100);
    if (last.arc !== pr) { last.arc = pr; $('spdArc').style.strokeDasharray = (245 * pr / 100).toFixed(1) + ' 327'; $('spdArc').setAttribute('class', 'rfg' + (nitroOn ? ' hot' : '')); }
    var lit = Math.round(clamp((rpm - 2500) / 5300, 0, 1) * LEDS);
    if (last.led !== lit) {
      last.led = lit;
      for (var i = 0; i < LEDS; i++) ledsEl.children[i].className = i < lit ? (i >= LEDS - 3 ? 'on red' : 'on') : '';
    }
    var showCombo = combo > 1 && comboT > 0, cb = $('combo');
    if (cb.hidden === showCombo) cb.hidden = !showCombo;
    if (showCombo) {
      setText($('comboX'), 'cx', '×' + combo);
      $('comboBar').style.transform = 'scaleX(' + Math.max(0, comboT / COMBO_WINDOW).toFixed(3) + ')';
    }
    var pct = Math.round(nitro * 100) + '%';
    if (last.p !== pct) { last.p = pct; turboEl.style.setProperty('--p', pct); }
    turboEl.classList.toggle('on', nitroOn);
    turboEl.classList.toggle('empty', nitro < 0.05);
    if (CH.on) chaseHud();
    var wa = Math.round(wAng);
    if (last.wa !== wa) { last.wa = wa; wheelSvg.style.transform = 'rotate(' + wa + 'deg)'; }
    if (save.ctrl === 'tilt') $('tiltKnob').style.left = (50 + steerVis * 44) + '%';
  }

  function setPaused(value) {
    paused = !!value && mode === 'play';
    keys = {}; btnDir = 0; nitroHold = false; wDrag = null;
    if (AC) { try { if (paused) AC.suspend(); else if (save.sound) AC.resume(); } catch (e) {} }
  }
  function returnToMenu() {
    if (LAN.active) lanClear();
    setPaused(false); clearCars(); clearBots(); CH.on = false;
    $('over').hidden = true; $('levels').hidden = true; $('ui').hidden = true; $('chase').hidden = true;
    setPlayerCar(save.sel); enterMode('menu'); refreshMenu();
  }
  /* ---------- LAN rendering in the existing Three.js scene and frame loop ---------- */
  var LAN = { active: false, localId: null, spectatorId: null, prev: null, state: null,
    at: 0, viewD: 0, viewId: null, remotes: new Map(), traffic: new Map() };
  function lanLabel(name) {
    var canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 96;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(4,10,22,.78)'; ctx.fillRect(4, 8, 504, 76);
    ctx.strokeStyle = '#86c4ff'; ctx.strokeRect(4, 8, 504, 76);
    ctx.font = 'bold 40px Arial, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff'; ctx.fillText(name, 256, 48, 484);
    var texture = new T.CanvasTexture(canvas);
    var sprite = new T.Sprite(new T.SpriteMaterial({ map: texture, transparent: true, depthTest: false, depthWrite: false }));
    sprite.position.y = 3.4; sprite.scale.set(4.8, 0.9, 1);
    return sprite;
  }
  function lanRemote(p) {
    var source = getRec(p.car), group = source.group.clone(true), materials = [], copies = new Map();
    group.traverse(function (obj) {
      if (!obj.isMesh) return;
      function cloneMaterial(mat) {
        if (!copies.has(mat)) {
          var copy = mat.clone();
          if (mat === source.paint && !carById(p.car).fixedPaint) copy.color.set(p.color || '#ffffff');
          if (source.lampMats && source.lampMats.indexOf(mat) >= 0) copy.emissive.set(p.light || '#fff4dc');
          copies.set(mat, copy); materials.push(copy);
        }
        return copies.get(mat);
      }
      obj.material = Array.isArray(obj.material) ? obj.material.map(cloneMaterial) : cloneMaterial(obj.material);
    });
    var label = lanLabel(p.nickname); group.add(label); scene.add(group);
    return { group: group, label: label, materials: materials, car: p.car, nickname: p.nickname, ghost: false };
  }
  function lanRemoveRemote(rec) {
    scene.remove(rec.group);
    rec.materials.forEach(function (m) { m.dispose(); });
    rec.label.material.map.dispose(); rec.label.material.dispose();
  }
  function lanClear() {
    if (!LAN.active) return;
    for (var remote of LAN.remotes.values()) lanRemoveRemote(remote);
    for (var traffic of LAN.traffic.values()) releaseTraffic(traffic);
    LAN.remotes.clear(); LAN.traffic.clear(); LAN.active = false;
    LAN.state = LAN.prev = null; LAN.spectatorId = null;
    pGroup.position.z = 0; pGroup.visible = true;
    if (pCar && pCar.paint) pCar.paint.color.setHex(PAINT_COLORS[colorOf(curCar.id)]);
  }
  function lanEnter(state, localId) {
    lanClear(); clearCars(); clearBots();
    LAN.active = true; LAN.localId = localId; LAN.state = LAN.prev = state;
    LAN.at = performance.now(); LAN.spectatorId = null; LAN.viewId = localId;
    var local = state.players.find(function (p) { return p.id === localId; });
    LAN.viewD = local ? local.d : 0;
    if (local) { setPlayerCar(local.car); if (pCar.paint && !carById(local.car).fixedPaint) pCar.paint.color.set(local.color); }
    enterMode('lan'); $('ui').hidden = true; $('over').hidden = true;
    pGroup.visible = true; menuBlend = 0;
  }
  function lanUpdate(state, localId, spectatorId) {
    if (!LAN.active) lanEnter(state, localId);
    LAN.prev = LAN.state; LAN.state = state; LAN.at = performance.now();
    LAN.spectatorId = spectatorId;
  }
  function lanStep(dt) {
    time += dt;
    var current = LAN.state;
    if (!current) return;
    var st = steerValue(dt); steerVis += (st - steerVis) * Math.min(1, dt * 10);
    var alpha = clamp((performance.now() - LAN.at) / 67, 0, 1), prior = LAN.prev || current;
    var oldPlayers = new Map(prior.players.map(function (p) { return [p.id, p]; }));
    var oldTraffic = new Map(prior.traffic.map(function (t) { return [t.id, t]; }));
    function blend(old, now, key) { return old && Number.isFinite(old[key]) ? old[key] + (now[key] - old[key]) * alpha : now[key]; }
    var me = current.players.find(function (p) { return p.id === LAN.localId; });
    var focusId = me && me.alive ? LAN.localId : LAN.spectatorId;
    var focus = current.players.find(function (p) { return p.id === focusId && p.alive; }) || me;
    if (focus) {
      var oldFocus = oldPlayers.get(focus.id), focusD = blend(oldFocus, focus, 'd');
      if (LAN.viewId !== focus.id) {
        if (pCar && pCar.paint) pCar.paint.color.setHex(PAINT_COLORS[colorOf(curCar.id)]);
        setPlayerCar(focus.car);
        if (pCar.paint && !carById(focus.car).fixedPaint) pCar.paint.color.set(focus.color);
        LAN.viewId = focus.id;
      }
      LAN.viewD += (focusD - LAN.viewD) * Math.min(1, dt * 5);
      player.x = blend(oldFocus, focus, 'x'); speed = focus.speed;
      pGroup.position.set(player.x, 0, -(focusD - LAN.viewD)); pGroup.visible = !!focus.alive;
      for (var wheel of pCar.spins) wheel.g.rotation.x -= speed / 3.6 * dt / wheel.r;
      for (var front of pCar.front) front.rotation.y = focus.id === LAN.localId ? -steerVis * 0.4 : 0;
    }
    var v = speed / 3.6;
    roadOff += v * dt / 12; roadTex.offset.y = roadOff; roadTex2.offset.y = roadOff;
    railTex.offset.x = roadOff * 3; railTexR.offset.x = -roadOff * 3;
    for (var i = 0; i < lamps.length; i++) { lamps[i].position.z += v * dt; if (lamps[i].position.z > 40) lamps[i].position.z -= LAMP_SPAN; }
    if (trk.scenery === 'city') updateBuildings(v, dt); else updateTrees(v, dt);
    updateSnow(v, dt);
    var seenPlayers = new Set();
    for (var p of current.players) {
      if (p.id === LAN.localId || !p.alive) continue;
      seenPlayers.add(p.id);
      var rec = LAN.remotes.get(p.id);
      if (!rec || rec.car !== p.car || rec.nickname !== p.nickname) {
        if (rec) lanRemoveRemote(rec);
        rec = lanRemote(p); LAN.remotes.set(p.id, rec);
      }
      var before = oldPlayers.get(p.id), px = blend(before, p, 'x'), pd = blend(before, p, 'd');
      rec.group.position.set(px, 0, -(pd - LAN.viewD));
      rec.group.visible = p.id !== focusId;
      var ghost = Math.abs(px - player.x) < 2.2 && Math.abs(pd - focus.d) < 5;
      if (ghost !== rec.ghost) {
        rec.ghost = ghost;
        rec.materials.forEach(function (m) { m.transparent = ghost; m.opacity = ghost ? 0.48 : 1; m.depthWrite = !ghost; });
      }
    }
    for (var entry of LAN.remotes) if (!seenPlayers.has(entry[0])) { lanRemoveRemote(entry[1]); LAN.remotes.delete(entry[0]); }
    var seenTraffic = new Set(), drawRange = effectiveQuality() === 'low' ? 180 : 280;
    for (var t of current.traffic) {
      var beforeT = oldTraffic.get(t.id), td = blend(beforeT, t, 'd');
      if (td - LAN.viewD > drawRange || td - LAN.viewD < -60) continue;
      seenTraffic.add(t.id);
      var visual = LAN.traffic.get(t.id);
      if (!visual) {
        visual = { kind: t.kind, rec: takeTraffic(t.kind, parseInt(t.color.slice(1), 16)), hit: false };
        LAN.traffic.set(t.id, visual); scene.add(visual.rec.group);
      }
      visual.rec.group.position.set(t.x, 0, -(td - LAN.viewD));
      var wheelDistance = t.speed / 3.6 * dt;
      for (var spin of visual.rec.spins) spin.g.rotation.x -= wheelDistance / spin.r;
    }
    for (var trafficEntry of LAN.traffic) if (!seenTraffic.has(trafficEntry[0])) {
      releaseTraffic(trafficEntry[1]); LAN.traffic.delete(trafficEntry[0]);
    }
  }
  function snapshot() {
    var gc = CARS[gIndex];
    return {
      mode: mode, paused: paused, gameType: gameType, speed: Math.round(speed), gear: gearN,
      rpm: Math.round(rpm), nitro: nitro, coins: coins, total: save.total, best: save.best,
      overtakes: overtakes, nearMisses: nearMisses, combo: combo, maxSpeed: Math.round(maxSpeed),
      distance: Math.round(distanceMeters), runTime: runT,
      driftScore: driftScore + Math.round(DRF.pts), driftRemaining: Math.ceil(driftTime),
      chaseRemaining: Math.max(0, Math.ceil(180 - CH.time)), catches: CH.catches,
      chaseNeed: CH.info ? CH.info.need : 1, chaseWin: CH.win, chaseLevel: CH.lvl,
      testRemaining: Math.max(0, Math.ceil(60 - runT)), resultVisible: overShown,
      selected: save.sel, currentCar: curCar.id, garageIndex: gIndex, garageCar: gc.id,
      owned: save.owned.slice(), colors: Object.assign({}, save.colors), matte: Object.assign({}, save.matte),
      lights: Object.assign({}, save.lights), neon: Object.assign({}, save.neon), rims: Object.assign({}, save.rims),
      quality: save.quality, actualQuality: effectiveQuality(), control: save.ctrl,
      graphics: Object.assign({}, graphics),
      sound: save.sound, track: save.track, fpsCap: fpsCap, camera: cameraMode,
      steerSensitivity: steerSensitivity, audio: Object.assign({}, audioMix)
    };
  }
  window.__night = {
    cars: CARS.map(function (c) { return { id: c.id, brand: c.brand, name: c.name, gen: c.gen, engine: c.engine, price: c.price, hp: c.hp, nm: c.nm, t100: c.t100, vmax: c.vmax, kg: c.kg, drive: c.drive, fixedPaint: !!c.fixedPaint }; }),
    tracks: TRACKS.map(function (t) { return { id: t.id, name: t.name }; }),
    paints: PAINT_COLORS.map(function (c, i) { return { color: hex6(c), name: PAINT_NAMES[i] }; }),
    loadAllModels: function () { CARS.forEach(function (c) { loadModel(c.id); }); },
    modelsReady: function () { return CARS.every(function (c) { return !!modelCache[c.id]; }); },
    snapshot: snapshot,
    start: function (kind) { if (kind === 'chase') startChase(save.level); else startGame({ drift: kind === 'drift', extreme: kind === 'extreme' }); },
    restart: function () { if (gameType === 'chase') startChase(CH.lvl); else if (gameType === 'test') startGame({ testId: testId }); else startGame({ drift: gameType === 'drift', extreme: gameType === 'extreme' }); },
    garage: openGarage, menu: returnToMenu,
    nextCar: function (d) { garageStep(d); },
    selectCar: function (id) { if (!owned(id)) return false; save.sel = id; persist(); refreshGarage(); refreshMenu(); return true; },
    buyCar: function (id) { var c = carById(id); if (owned(id) || save.total < c.price) return false; save.total -= c.price; save.owned.push(id); save.sel = id; persist(); refreshGarage(); refreshMenu(); return true; },
    testDrive: function (id) { if (!CARS.some(function (c) { return c.id === id; })) return; startGame({ testId: id }); },
    paint: function (id, index) { var c = carById(id); if (c.fixedPaint || index < 0 || index >= PAINT_COLORS.length) return; save.colors[id] = index; persist(); getRec(id).paint.color.setHex(PAINT_COLORS[index]); refreshGarage(); },
    matte: function (id, value) { save.matte[id] = !!value; persist(); applyFinish(getRec(id).paint, !!value); refreshGarage(); },
    lights: function (id, color, intensity) { if (!/^#[0-9a-fA-F]{6}$/.test(color)) return; save.lights[id] = { color: color, intensity: clamp(+intensity || 1.7, 0.2, 4) }; persist(); if (curCar.id === id) applyLighting(id); },
    neon: function (id, color) { if (!/^#[0-9a-fA-F]{6}$/.test(color)) return; save.neon[id] = color; persist(); if (curCar.id === id) applyLighting(id); },
    rims: function (id, color) { if (!/^#[0-9a-fA-F]{6}$/.test(color)) return; save.rims[id] = color; persist(); var rec = getRec(id); if (rec.rimPaint) rec.rimPaint.color.set(color); },
    quality: setQuality, control: setCtrl,
    graphics: function (name, value) {
      if (name === 'resolution') graphics.resolution = clamp(+value || 1, 0.65, 1.25);
      else if (name === 'pixelRatioCap') graphics.pixelRatioCap = clamp(+value || 2.5, 0.75, 3);
      else if (name === 'particles') graphics.particles = clamp(+value || 1, 0.25, 1);
      else if (name === 'drawDistance') graphics.drawDistance = clamp(+value || 900, 300, 1500);
      else if (name === 'traffic') graphics.traffic = clamp(+value || 1, 0.8, 1.8);
      else if (name === 'lighting') graphics.lighting = !!value;
      else if (name === 'antialias') graphics.antialias = !!value;
      else if (name === 'shadows' && ['off', 'low', 'high'].includes(value)) graphics.shadows = value;
      else return;
      try { localStorage.setItem('night-graphics-v3', JSON.stringify(graphics)); } catch (e) {}
      if (name === 'antialias') { location.reload(); return; }
      if (name === 'resolution' || name === 'pixelRatioCap' || name === 'drawDistance') resize();
      if (name === 'lighting') { enterMode(mode); applyLighting(curCar.id); }
      if (name === 'shadows') applyShadows();
    },
    track: function (id) { if (!TRACKS.some(function (t) { return t.id === id; })) return; save.track = id; persist(); applyTrack(id); },
    sound: function (on) { save.sound = !!on; persist(); soundLabel(); if (save.sound) initAudio(); else if (AC) AC.suspend(); },
    audio: function (key, value) { if (!(key in audioMix)) return; audioMix[key] = clamp(+value || 0, 0, 1); try { localStorage.setItem('night-audio-v2', JSON.stringify(audioMix)); } catch (e) {} if (eng) eng.master.gain.value = 1.25 * audioMix.master; },
    fpsCap: function (value) { fpsCap = value === 30 || value === 60 ? value : 0; try { localStorage.setItem('night-fps-cap', String(fpsCap)); } catch (e) {} },
    steering: function (value) { steerSensitivity = clamp(+value || 1, 0.5, 1.7); try { localStorage.setItem('night-steer', String(steerSensitivity)); } catch (e) {} },
    camera: function () { cameraMode = cameraMode === 'chase' ? 'cockpit' : 'chase'; },
    lanEnter: lanEnter,
    lanUpdate: lanUpdate,
    lanSpectate: function (id) { LAN.spectatorId = id; },
    lanLeave: function () { if (LAN.active) { lanClear(); returnToMenu(); } },
    lanInput: function () { return { steering: clamp(steerVis, -1, 1), throttle: keys.a ? 1 : 0,
      brake: keys.b ? 1 : 0, nitro: !!(nitroHold || keys.t) }; },
    lanImpact: function () { crashSound(0.8); shake = 0.7; },
    orbit: function (dx, zoom) { gAng += dx || 0; gZoom = clamp(gZoom + (zoom || 0), 0.7, 1.5); gLast = time; },
    pause: function () { setPaused(true); }, resume: function () { setPaused(false); },
    input: function (name, down) { if (paused || (mode !== 'play' && mode !== 'lan')) return; if (name === 'left') keys.l = down; if (name === 'right') keys.r = down; if (name === 'accelerate') keys.a = down; if (name === 'brake' || name === 'handbrake') keys.b = down; if (name === 'nitro') nitroHold = down; },
    reset: function () { player.x = laneX(1); player.vx = 0; player.yaw = 0; speed = Math.min(speed, 90); },
    debug: import.meta.env.DEV ? {
      crash: function () { doCrash(null); showOver(); },
      step: function (seconds) { var n = Math.ceil(seconds / 0.05); for (var i = 0; i < n; i++) step(0.05); },
      chaseTime: function (seconds) { CH.time = seconds; },
      runTime: function (seconds) { runT = seconds; },
      traffic: function () { return cars.map(function (c) { return { lane: c.lane, x: c.x, z: c.z, oncoming: !!c.onc }; }); },
      inputs: function () { return { left: !!keys.l, right: !!keys.r, accelerate: !!keys.a, brake: !!keys.b, nitro: !!nitroHold }; }
    } : null
  };

  /* ---------- loop ---------- */
  var prev = 0;
  function frame(t) {
    if (fpsCap && t - lastRender < 1000 / fpsCap - 1) { requestAnimationFrame(frame); return; }
    lastRender = t;
    var dt = prev ? Math.min(0.05, (t - prev) / 1000) : 0.016;
    prev = t;
    if (paused || document.hidden) { requestAnimationFrame(frame); return; }
    if (save.quality === 'auto' && fpsCap !== 30) {
      fpsElapsed += dt; fpsSamples++;
      if (fpsElapsed >= 2.5) {
        var measured = fpsSamples / fpsElapsed, old = autoLevel;
        if (measured < 43) autoLevel = autoLevel === 'high' ? 'medium' : 'low';
        else if (measured > 57) autoLevel = autoLevel === 'low' ? 'medium' : 'high';
        fpsElapsed = 0; fpsSamples = 0;
        if (old !== autoLevel) { resize(); enterMode(mode); }
      }
    }
    if (mode === 'crash') {
      slowT += dt;
      dt *= clamp(0.14 + Math.max(0, slowT - 0.25) / 1.1 * 0.86, 0.14, 1);
    }
    step(dt);
    updateCamera(dt);
    renderer.render(scene, camera);
    hud();
    audioUpdate();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
