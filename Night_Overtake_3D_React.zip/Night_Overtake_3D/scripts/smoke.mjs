import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'
import { mkdir } from 'node:fs/promises'

const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: true,
  args: ['--enable-webgl', '--use-angle=swiftshader', '--disable-web-security'],
})
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const errors = []
page.on('pageerror', (error) => errors.push(error.message))
page.on('console', (message) => { if (message.type() === 'error') errors.push(`${message.text()} @ ${message.location().url}`) })
page.on('response', (response) => { if (response.status() >= 400) errors.push(`${response.status()} ${response.url()}`) })
await mkdir('test-output', { recursive: true })
try {
  await page.goto('http://localhost:5173/', { waitUntil: 'domcontentloaded' })
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).waitFor({ timeout: 60000 })
  assert.equal(await page.evaluate(() => window.__night.snapshot().mode), 'menu')
  await page.screenshot({ path: 'test-output/menu.png' })

  await page.getByRole('button', { name: /ГАРАЖ/ }).first().click()
  await page.locator('.garage-sheet h2').getByText('M4 Competition xDrive').waitFor()
  assert.equal(await page.evaluate(() => window.__night.snapshot().mode), 'garage')
  await page.waitForTimeout(800)
  await page.screenshot({ path: 'test-output/garage.png' })
  await page.getByRole('button', { name: 'Следующая машина' }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().garageCar), 'g63')
  await page.getByRole('button', { name: /ТЕСТ-ДРАЙВ/ }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'test')
  assert.equal(await page.evaluate(() => window.__night.snapshot().selected), 'm4')
  await page.getByRole('button', { name: 'Пауза' }).click()
  await page.getByRole('button', { name: 'В МЕНЮ' }).click()

  await page.getByRole('button', { name: /НАСТРОЙКИ/ }).click()
  await page.getByLabel('Качество').selectOption('low')
  assert.equal(await page.evaluate(() => window.__night.snapshot().quality), 'low')
  await page.getByRole('button', { name: /Назад/i }).click()

  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).click()
  await page.getByRole('button', { name: /КЛАССИКА/ }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'classic')
  const startX = await page.evaluate(() => window.__pl.x)
  await page.keyboard.down('ArrowRight')
  await page.waitForTimeout(1000)
  await page.keyboard.up('ArrowRight')
  const endX = await page.evaluate(() => window.__pl.x)
  console.log('steering', startX, endX)
  assert.ok(endX > startX, 'steering moves player')
  await page.keyboard.press('Escape')
  assert.equal(await page.evaluate(() => window.__night.snapshot().paused), true)
  await page.getByRole('button', { name: 'ПРОДОЛЖИТЬ' }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().paused), false)
  await page.screenshot({ path: 'test-output/classic.png' })
  await page.evaluate(() => window.__night.debug.crash())
  await page.getByRole('heading', { name: 'ЗАЕЗД ЗАВЕРШЁН' }).waitFor({ timeout: 15000 })
  await page.getByRole('button', { name: 'В МЕНЮ' }).click()

  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).click()
  await page.getByRole('button', { name: /ДРИФТ/ }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'drift')
  await page.getByText('90', { exact: false }).first().waitFor()
  await page.evaluate(() => { window.__night.debug.runTime(89.9); window.__night.debug.step(.2) })
  await page.getByRole('heading', { name: 'ДРИФТ ЗАВЕРШЁН' }).waitFor({ timeout: 10000 })
  await page.getByRole('button', { name: 'В МЕНЮ' }).click()

  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).click()
  await page.getByRole('button', { name: /ДОГОНЯЛКИ/ }).click()
  await page.waitForFunction(() => window.__night.snapshot().gameType === 'chase', null, { timeout: 15000 })
  assert.equal(await page.evaluate(() => window.__night.snapshot().chaseRemaining), 180)
  await page.screenshot({ path: 'test-output/chase.png' })
  await page.evaluate(() => { window.__night.debug.chaseTime(179.9); window.__night.debug.step(2) })
  await page.getByRole('heading', { name: 'ЦЕЛЬ УШЛА' }).waitFor({ timeout: 10000 })
  assert.deepEqual(errors, [])
  console.log('Smoke test passed: loading, menu, garage, test drive, settings, classic, pause, results, drift, chase.')
} finally {
  await browser.close()
}
