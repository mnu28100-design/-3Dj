import assert from 'node:assert/strict'
import { WebSocket } from 'ws'

const address = (process.env.LAN_TEST_URL || 'http://192.168.0.2:3000').replace(/^http/, 'ws') + '/ws'
const waitFor = (socket, predicate, timeout = 10000) => new Promise((resolve, reject) => {
  const received = socket.lanMessages?.find(predicate)
  if (received) { resolve(received); return }
  const timer = setTimeout(() => { socket.off('message', onMessage); reject(new Error('Timed out waiting for LAN message')) }, timeout)
  const onMessage = (raw) => {
    const data = JSON.parse(raw.toString())
    if (!predicate(data)) return
    clearTimeout(timer); socket.off('message', onMessage); resolve(data)
  }
  socket.on('message', onMessage)
})
const connect = (token = '') => new Promise((resolve, reject) => {
  const socket = new WebSocket(address + (token ? `?token=${token}` : ''))
  socket.lanMessages = []
  socket.on('message', (raw) => socket.lanMessages.push(JSON.parse(raw.toString())))
  socket.once('error', reject)
  socket.once('message', (raw) => resolve({ socket, welcome: JSON.parse(raw.toString()) }))
})

let host, guest, restored, raceRestored
try {
  host = await connect()
  const created = waitFor(host.socket, (data) => data.type === 'room')
  host.socket.send(JSON.stringify({ type: 'create', nickname: 'Хост LAN', name: 'Проверка' }))
  const code = (await created).room.code
  guest = await connect()
  const joined = waitFor(guest.socket, (data) => data.type === 'room' && data.room.code === code)
  guest.socket.send(JSON.stringify({ type: 'join', nickname: 'Гость LAN', code }))
  await joined

  const denied = await new Promise((resolve) => {
    const duplicate = new WebSocket(address + `?token=${host.welcome.token}`)
    duplicate.on('close', (code) => resolve(code))
  })
  assert.equal(denied, 4001, 'an active token cannot control a second session')

  const transferred = waitFor(guest.socket, (data) => data.type === 'room' && data.room.hostId === guest.welcome.id)
  host.socket.close()
  await transferred
  restored = await connect(host.welcome.token)
  assert.equal(restored.welcome.id, host.welcome.id)
  const room = await waitFor(restored.socket, (data) => data.type === 'room' && data.room.code === code)
  assert.equal(room.room.players.length, 2)
  assert.equal(room.room.hostId, guest.welcome.id)
  const bothReady = waitFor(guest.socket, (data) => data.type === 'room' && data.room.players.every((p) => p.ready), 10000)
  guest.socket.send(JSON.stringify({ type: 'ready', value: true }))
  restored.socket.send(JSON.stringify({ type: 'ready', value: true }))
  await bothReady
  guest.socket.send(JSON.stringify({ type: 'start' }))
  const race = await waitFor(restored.socket, (data) => data.type === 'raceStart', 10000)
  assert.equal(race.state.players.length, 2)
  const closing = new Promise((resolve) => restored.socket.once('close', resolve))
  restored.socket.close()
  await closing
  raceRestored = await connect(restored.welcome.token)
  assert.equal(raceRestored.welcome.id, restored.welcome.id)
  const resumedRace = await waitFor(raceRestored.socket, (data) => data.type === 'state' && data.state.stage === 'race', 10000)
  assert.equal(resumedRace.state.players.find((p) => p.id === restored.welcome.id)?.connected, true)
  console.log('LAN protocol test passed: lobby and race reconnect, duplicate session blocked, host transferred.')
} finally {
  for (const item of [host, guest, restored, raceRestored]) item?.socket.close()
}
