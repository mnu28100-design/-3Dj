import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'
import { mkdir } from 'node:fs/promises'

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: true, args: ['--enable-webgl', '--use-angle=swiftshader'] })
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true })
const page = await context.newPage()
const errors = []
page.on('pageerror', (error) => errors.push(error.message))
await mkdir('test-output', { recursive: true })
try {
  await page.goto('http://localhost:5173/', { waitUntil: 'domcontentloaded' })
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).waitFor({ timeout: 60000 })
  await page.screenshot({ path: 'test-output/mobile-menu.png' })
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1))
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).click()
  await page.getByRole('button', { name: /ЭКСТРИМ/ }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'extreme')
  await page.screenshot({ path: 'test-output/mobile-play.png' })
  const wheel = await page.locator('.steering-wheel').boundingBox()
  const gas = await page.getByRole('button', { name: 'ГАЗ' }).boundingBox()
  assert.ok(wheel && gas)
  const cdp = await context.newCDPSession(page)
  const left = { x: wheel.x + wheel.width * .2, y: wheel.y + wheel.height * .5, id: 1 }
  const accelerator = { x: gas.x + gas.width / 2, y: gas.y + gas.height / 2, id: 2 }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [left, accelerator] })
  assert.deepEqual(await page.evaluate(() => window.__night.debug.inputs()), { left: true, right: false, accelerate: true, brake: false, nitro: false })
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] })
  assert.deepEqual(await page.evaluate(() => window.__night.debug.inputs()), { left: false, right: false, accelerate: false, brake: false, nitro: false })
  assert.deepEqual(errors, [])
  console.log('Mobile test passed: extreme mode, layout, rendering, simultaneous steering and accelerator, release.')
} finally {
  await browser.close()
}
