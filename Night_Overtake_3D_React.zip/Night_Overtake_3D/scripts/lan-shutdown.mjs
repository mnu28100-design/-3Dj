import { spawn } from 'node:child_process'
import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'

const port = 3017
const server = spawn(process.execPath, ['server/index.js'], {
  cwd: process.cwd(), env: { ...process.env, PORT: String(port) }, windowsHide: true,
  stdio: ['ignore', 'pipe', 'pipe'],
})
let serverOutput = ''
server.stdout.on('data', (chunk) => { serverOutput += chunk.toString() })
server.stderr.on('data', (chunk) => { serverOutput += chunk.toString() })
let browser
try {
  const deadline = Date.now() + 10000
  while (!serverOutput.includes(`port ${port}`) && Date.now() < deadline) {
    if (server.exitCode !== null) throw new Error(`LAN server exited: ${serverOutput}`)
    await new Promise((resolve) => setTimeout(resolve, 100))
  }
  assert.ok(serverOutput.includes(`port ${port}`), `LAN server did not start: ${serverOutput}`)
  browser = await chromium.launch({
    executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: true, args: ['--enable-webgl', '--use-angle=swiftshader'],
  })
  const page = await browser.newPage()
  await page.goto(`http://127.0.0.1:${port}`, { waitUntil: 'domcontentloaded' })
  await page.getByRole('button', { name: /LAN MULTIPLAYER/ }).waitFor({ timeout: 150000 })
  await page.getByRole('button', { name: /LAN MULTIPLAYER/ }).click()
  await page.getByText('Сервер подключён').waitFor({ timeout: 15000 })
  await page.getByLabel('ВАШ НИК').fill('Тест сервер')
  await page.getByRole('button', { name: 'СОЗДАТЬ', exact: true }).click()
  await page.locator('.lan-lobby-main h1').waitFor({ timeout: 10000 })
  server.kill()
  await page.getByRole('heading', { name: 'СВЯЗЬ ПОТЕРЯНА' }).waitFor({ timeout: 45000 })
  console.log('LAN shutdown test passed: server loss shows the connection-lost screen.')
} finally {
  if (browser) await browser.close()
  if (server.exitCode === null) server.kill()
}
