import { chromium } from 'playwright-core'
import { WebSocket } from 'ws'
import assert from 'node:assert/strict'
import { mkdir } from 'node:fs/promises'

const address = process.env.LAN_TEST_URL || 'http://192.168.0.2:3000'
const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: true, args: ['--enable-webgl', '--use-angle=swiftshader'] })
const pages = []
const frames = []
const errors = []
await mkdir('test-output', { recursive: true })

async function newPlayer(name, mobile = false) {
  console.log('Loading browser client:', name)
  const context = await browser.newContext({ viewport: mobile ? { width: 844, height: 390 } : { width: 1024, height: 700 },
    deviceScaleFactor: 1, isMobile: mobile, hasTouch: mobile })
  const page = await context.newPage()
  const received = []
  const sent = []
  page.on('pageerror', (error) => errors.push(`${name}: ${error.message}`))
  page.on('response', (response) => { if (response.status() >= 400) errors.push(`${name}: HTTP ${response.status()} ${response.url()}`) })
  page.on('websocket', (socket) => {
    socket.on('framereceived', (frame) => {
      try { const data = JSON.parse(frame.payload); if (data.type === 'state') received.push(data.state) } catch {}
    })
    socket.on('framesent', (frame) => { try { sent.push(JSON.parse(frame.payload)) } catch {} })
  })
  await page.goto(address, { waitUntil: 'domcontentloaded' })
  try { await page.getByRole('button', { name: /LAN MULTIPLAYER/ }).waitFor({ timeout: 150000 }) }
  catch (error) { console.error(name, (await page.locator('body').innerText()).slice(0, 500), errors); throw error }
  await page.getByRole('button', { name: /LAN MULTIPLAYER/ }).click()
  await page.getByText('Сервер подключён').waitFor({ timeout: 15000 })
  await page.getByLabel('ВАШ НИК').fill(name)
  pages.push({ context, page, received, sent })
  console.log('Ready browser client:', name)
  return page
}

try {
  const host = await newPlayer('Пилот')
  await host.getByRole('button', { name: 'СОЗДАТЬ', exact: true }).click()
  await host.locator('.lan-lobby-main h1').waitFor()
  await host.evaluate(() => Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }))
  const code = (await host.locator('.lan-lobby-main h1').textContent()).match(/[A-Z2-9]{6}/)?.[0]
  assert.ok(code)

  const guest = await newPlayer('Пилот')
  await guest.getByRole('button', { name: 'ПРИСОЕДИНИТЬСЯ' }).click()
  await guest.getByLabel('КОД КОМНАТЫ').fill(code)
  await guest.getByRole('button', { name: 'ВОЙТИ', exact: true }).click()
  await guest.locator('.lan-player-row').filter({ hasText: 'Пилот (2)' }).waitFor()
  await guest.evaluate(() => Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }))

  const third = await newPlayer('Третий', true)
  await third.getByRole('button', { name: 'ПРИСОЕДИНИТЬСЯ' }).click()
  await third.getByLabel('КОД КОМНАТЫ').fill(code)
  await third.getByRole('button', { name: 'ВОЙТИ', exact: true }).click()
  await third.locator('.lan-player-row').filter({ hasText: 'Третий' }).waitFor()
  await third.evaluate(() => Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }))

  const fourth = await newPlayer('Четвёртый')
  await fourth.getByRole('button', { name: 'ПРИСОЕДИНИТЬСЯ' }).click()
  await fourth.getByLabel('КОД КОМНАТЫ').fill(code)
  await fourth.getByRole('button', { name: 'ВОЙТИ', exact: true }).click()
  await fourth.locator('.lan-player-row').filter({ hasText: 'Четвёртый' }).waitFor()
  await fourth.evaluate(() => Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }))
  assert.equal(await host.locator('.lan-player-row:not(.empty)').count(), 4)
  assert.equal(await host.locator('.lan-cars button').count(), 4)

  await guest.locator('.lan-cars button').filter({ hasText: 'BMW M4' }).click()
  await guest.locator('.lan-cars button').filter({ hasText: 'BMW M4' }).waitFor()
  assert.equal(await host.locator('.lan-player-row').filter({ hasText: 'Пилот (2)' }).locator('span').textContent(), 'BMW M4',
    'players may choose the same vehicle')
  await guest.locator('.lan-cars button').filter({ hasText: 'Mercedes G 63' }).click()
  await third.locator('.lan-cars button').filter({ hasText: 'Nissan R34' }).click()
  await fourth.locator('.lan-cars button').filter({ hasText: 'Porsche 911' }).click()
  await fourth.reload({ waitUntil: 'domcontentloaded' })
  await fourth.locator('.lan-lobby-main h1').waitFor({ timeout: 150000 })
  assert.ok((await fourth.locator('.lan-lobby-main h1').textContent()).includes(code),
    'reloaded browser returns to its existing lobby seat')

  const fifthMessage = await new Promise((resolve, reject) => {
    const socket = new WebSocket(address.replace(/^http/, 'ws') + '/ws')
    socket.on('message', (raw) => {
      const data = JSON.parse(raw.toString())
      if (data.type === 'welcome') socket.send(JSON.stringify({ type: 'join', nickname: 'Пятый', code }))
      if (data.type === 'error') { socket.close(); resolve(data.message) }
    })
    socket.on('error', reject)
  })
  assert.match(fifthMessage, /заполнена/)

  for (const { page } of pages) await page.getByRole('button', { name: 'Я ГОТОВ' }).click()
  for (const { page } of pages) await page.evaluate(() => { delete document.hidden })
  await host.getByRole('button', { name: 'НАЧАТЬ ЗАЕЗД' }).click()
  for (const { page } of pages) await page.getByText('LAN SURVIVAL', { exact: false }).first().waitFor({ timeout: 20000 })
  await host.screenshot({ path: 'test-output/lan-four-player.png' })
  await host.waitForTimeout(1000)

  const first = frames[0] || pages[0].received
  const second = pages[1].received
  const matching = first.find((a) => a.traffic.length && second.some((b) => b.elapsed === a.elapsed))
  assert.ok(matching, 'both clients receive the same traffic tick')
  const matchingGuest = second.find((b) => b.elapsed === matching.elapsed)
  assert.deepEqual(matching.traffic, matchingGuest.traffic, 'traffic is server-synchronized')
  assert.ok(pages[3].received.at(-1)?.players.find((p) => p.nickname === 'Четвёртый')?.connected,
    'reloaded browser reconnects to its existing vehicle')
  await host.bringToFront()
  await host.keyboard.down('w')
  const outcome = await Promise.any([
    host.locator('.lan-spectator').waitFor({ timeout: 90000 }).then(() => 'spectator'),
    host.locator('.lan-results').waitFor({ timeout: 90000 }).then(() => 'results'),
  ])
  await host.keyboard.up('w')
  if (outcome === 'spectator') {
    const spectator = host.locator('.lan-spectator strong')
    const beforeSwitch = await spectator.textContent()
    await host.getByRole('button', { name: /СЛЕДУЮЩИЙ/ }).click()
    const afterSwitch = await spectator.textContent()
    assert.notEqual(afterSwitch, beforeSwitch, 'spectator can switch living players')
  } else assert.equal(await host.locator('.lan-ranking > div').count(), 4, 'results include all players')
  await host.waitForTimeout(1000)
  const previousInputs = pages[0].sent.filter((message) => message.type === 'input').length
  await host.keyboard.down('w')
  await host.waitForTimeout(1000)
  await host.keyboard.up('w')
  assert.equal(pages[0].sent.filter((message) => message.type === 'input').length, previousInputs,
    'eliminated player does not send driving input')
  assert.deepEqual(errors, [])
  console.log(`LAN browser test passed: four clients, lobby reconnect, models, capacity, synchronized traffic, ${outcome} and inactive controls.`)
} finally {
  await Promise.all(pages.map(({ context }) => context.close()))
  await browser.close()
}
