import assert from 'node:assert/strict'
import { GameRoom, validateNickname } from '../server/game.js'
import { TICK, trafficDifficulty, spectatorTarget } from '../src/multiplayer/shared.js'

const fake = (id, nickname = `Игрок ${id}`) => ({ id, nickname, room: null, car: 'm4', connected: true,
  ws: { readyState: 1, send() {} } })

assert.equal(validateNickname('  Алексей  '), 'Алексей')
assert.equal(validateNickname('A'), null)
assert.equal(validateNickname('А\u0000Б'), null)
const host = fake('a', 'Гонщик')
const room = new GameRoom('ABC234', host)
for (const id of ['b', 'c', 'd']) assert.equal(room.add(fake(id, 'Гонщик')), null)
assert.equal(room.players.size, 4)
assert.equal(room.add(fake('e')), 'Комната заполнена')
assert.equal(new Set([...room.players.values()].map((p) => p.nickname)).size, 4)
for (const [player, car] of [...room.players.values()].map((p, i) => [p, ['m4', 'g63', 'r34', '911'][i]])) {
  assert.ok(room.select(player, car, '#ffffff', '#fff4dc'))
  assert.ok(room.ready(player, true))
}
assert.ok(room.start(host, 1000))
room.advance(TICK, 5000)
assert.equal(room.stage, 'race')
room.spawnIn = 100
room.traffic = []
const players = [...room.players.values()]
for (const p of players) { p.vehicle.x = 0; p.vehicle.d = 0 }
room.advance(TICK, 5034)
assert.ok(players.every((p) => p.vehicle.alive), 'overlapping players do not collide')
assert.ok(room.input(host, { sequence: 1, steering: 0.5, throttle: 1, brake: 0, nitro: false }))
assert.equal(room.input(host, { sequence: 1, steering: 0.5, throttle: 1, brake: 0, nitro: false }), false)
assert.equal(room.input(host, { sequence: 2, steering: NaN, throttle: 1, brake: 0, nitro: false }), false)
for (let i = 1; i < players.length; i++) players[i].vehicle.x = 5.4
room.traffic = [{ id: 1, lane: 1, x: 0, d: host.vehicle.d, speed: 80, kind: 'sedan', color: '#ffffff', width: 1.9, length: 4.5, passed: new Set() }]
room.advance(TICK, 5067)
assert.equal(host.vehicle.alive, false, 'server traffic collision eliminates player')
assert.ok(players.slice(1).every((p) => p.vehicle.alive))
room.eliminate(players[1])
room.eliminate(players[2])
room.finish()
assert.equal(room.results.winnerId, players[3].id)
assert.ok(room.rematch(host))
assert.equal(room.stage, 'lobby')
assert.ok(players.every((p) => p.vehicle === null && !p.ready))

const a = fake('one'), b = fake('two')
const draw = new GameRoom('XYZ345', a)
draw.add(b)
draw.startRace()
draw.spawnIn = 100
draw.traffic = [
  { id: 1, lane: 0, x: a.vehicle.x, d: 1, speed: 80, width: 1.9, length: 4.5, passed: new Set() },
  { id: 2, lane: 1, x: b.vehicle.x, d: 1, speed: 80, width: 1.9, length: 4.5, passed: new Set() },
]
draw.advance(TICK)
assert.equal(draw.stage, 'results')
assert.equal(draw.results.draw, true)
assert.equal(draw.results.winnerId, null)
assert.ok(trafficDifficulty(185).stage > trafficDifficulty(20).stage)
assert.ok(trafficDifficulty(10000).maxTraffic <= 24)
const spectators = [{ id: 'a', alive: false }, { id: 'b', alive: true }, { id: 'c', alive: true }]
assert.equal(spectatorTarget(spectators, null), 'b', 'eliminated player follows first survivor')
assert.equal(spectatorTarget(spectators, 'b', 1), 'c', 'spectator can switch forward')
assert.equal(spectatorTarget(spectators, 'b', -1), 'c', 'spectator can switch backward')
spectators[1].alive = false
assert.equal(spectatorTarget(spectators, 'b'), 'c', 'spectator follows another survivor after target elimination')
spectators[2].alive = false
assert.equal(spectatorTarget(spectators, 'c'), null, 'spectator ends when nobody survives')

const nearMiss = new GameRoom('NEAR23', fake('near'))
nearMiss.startRace()
nearMiss.players.get('near').vehicle.x = 0
nearMiss.spawnIn = 100
nearMiss.traffic = [{ id: 1, lane: 1, x: 2, d: -5.5, speed: 80, kind: 'sedan', color: '#ffffff',
  width: 1.9, length: 4.5, passed: new Set() }]
for (let i = 0; i < 10 && nearMiss.players.get('near').vehicle.nearMisses === 0; i++) nearMiss.advance(TICK)
assert.equal(nearMiss.players.get('near').vehicle.nearMisses, 1, 'near miss is detected by authoritative positions')
assert.equal(nearMiss.players.get('near').vehicle.score, 350, 'near miss awards an overtake and bonus points')
console.log('LAN unit tests passed: capacity, names, cars, collision filtering, elimination, draw, rematch and bounded difficulty.')
