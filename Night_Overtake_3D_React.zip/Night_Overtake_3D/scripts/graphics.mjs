import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: true, args: ['--enable-webgl', '--use-angle=swiftshader'] })
const page = await browser.newPage()
const errors = []
page.on('pageerror', (error) => errors.push(error.message))
try {
  await page.goto('http://localhost:5173/')
  await page.getByRole('button', { name: /НАСТРОЙКИ/ }).waitFor({ timeout: 60000 })
  await page.getByRole('button', { name: /НАСТРОЙКИ/ }).click()
  await page.getByLabel('Тени').selectOption('low')
  assert.equal(await page.evaluate(() => window.__night.snapshot().graphics.shadows), 'low')
  await page.getByLabel('Тени').selectOption('off')
  assert.equal(await page.evaluate(() => window.__night.snapshot().graphics.shadows), 'off')
  await page.getByLabel('Световые эффекты').uncheck()
  assert.equal(await page.evaluate(() => window.__night.snapshot().graphics.lighting), false)
  assert.deepEqual(errors, [])
  console.log('Graphics test passed: live shadows and lighting options.')
} finally {
  await browser.close()
}
