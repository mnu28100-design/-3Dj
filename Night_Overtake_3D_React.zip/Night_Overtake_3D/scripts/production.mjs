import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: true, args: ['--enable-webgl', '--use-angle=swiftshader'] })
const page = await browser.newPage()
const errors = []
page.on('pageerror', (error) => errors.push(error.message))
page.on('response', (response) => { if (response.status() >= 400) errors.push(`${response.status()} ${response.url()}`) })
try {
  await page.goto('http://localhost:4173/')
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).waitFor({ timeout: 60000 })
  assert.equal(await page.evaluate(() => window.__night.snapshot().mode), 'menu')
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).click()
  await page.getByRole('button', { name: /КЛАССИКА/ }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'classic')
  assert.equal(await page.evaluate(() => window.__night.debug), null)
  assert.deepEqual(errors, [])
  console.log('Production test passed: built assets load and classic race starts.')
} finally {
  await browser.close()
}
