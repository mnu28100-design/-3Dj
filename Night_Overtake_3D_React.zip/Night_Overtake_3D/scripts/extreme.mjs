import { chromium } from 'playwright-core'
import assert from 'node:assert/strict'

const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: true,
  args: ['--enable-webgl', '--use-angle=swiftshader'],
})
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const errors = []
page.on('pageerror', (error) => errors.push(error.message))

try {
  await page.goto('http://localhost:5173/', { waitUntil: 'domcontentloaded' })
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).waitFor({ timeout: 60000 })
  await page.evaluate(() => window.__night.quality('high'))
  await page.getByRole('button', { name: /ГОНКА \/ ПОЕХАЛИ/ }).click()
  await page.getByRole('button', { name: /ЭКСТРИМ/ }).click()

  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'extreme')
  const first = await page.evaluate(() => window.__night.debug.traffic())
  const sameDirection = first.filter((car) => !car.oncoming)
  assert.ok(sameDirection.length >= 7, `expected dense traffic, got ${sameDirection.length}`)

  await page.evaluate(() => window.__night.debug.step(0.5))
  const moved = await page.evaluate(() => window.__night.debug.traffic())
  assert.ok(Math.abs(moved[0].z - first[0].z) > 1, 'traffic moves during the race')

  await page.getByRole('button', { name: 'Пауза' }).click()
  await page.getByRole('button', { name: 'ЗАНОВО' }).click()
  assert.equal(await page.evaluate(() => window.__night.snapshot().gameType), 'extreme')
  assert.ok((await page.evaluate(() => window.__night.debug.traffic().length)) >= 7)
  assert.deepEqual(errors, [])
  console.log('Extreme mode passed: dense moving traffic and restart.')
} finally {
  await browser.close()
}
